"""
Analyse des tâches avec SQL.

À chaque synchronisation, les tâches (qui sont des blocs dans un document JSON) sont
« aplaties » dans une vraie table SQL `taches`, une ligne par tâche. On peut alors les
interroger avec du SQL classique (GROUP BY, jointures, fonctions de date…), les exporter
en CSV ou les charger dans pandas (voir analyse/analyse_pandas.py).
"""

import csv
import io
import sqlite3
import time
from typing import Any, Dict, List

SCHEMA = """
CREATE TABLE IF NOT EXISTS taches (
    user_id    INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    bloc_id    TEXT    NOT NULL,
    page_id    TEXT    NOT NULL,
    page_titre TEXT    NOT NULL,
    texte      TEXT    NOT NULL,
    fait       INTEGER NOT NULL,          -- 0 ou 1
    encours    INTEGER NOT NULL,          -- 0 ou 1
    echeance   TEXT,                      -- AAAA-MM-JJ
    heure      TEXT,                      -- HH:MM
    niveau     INTEGER NOT NULL,          -- 0 = tâche, 1+ = sous-tâche
    tags       TEXT    NOT NULL,          -- séparés par des espaces
    repete     TEXT,
    cree_le    INTEGER,                   -- millisecondes depuis 1970
    fait_le    INTEGER,
    PRIMARY KEY (user_id, bloc_id)
);
CREATE INDEX IF NOT EXISTS idx_taches_page ON taches(user_id, page_id);
CREATE TABLE IF NOT EXISTS jours (
    user_id   INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    jour      TEXT    NOT NULL,           -- AAAA-MM-JJ
    faits     INTEGER NOT NULL DEFAULT 0,
    pomodoros INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, jour)
);
"""


def _texte(valeur: Any, defaut: str = "") -> str:
    return valeur if isinstance(valeur, str) else defaut


def _entier(valeur: Any):
    return int(valeur) if isinstance(valeur, (int, float)) and not isinstance(valeur, bool) else None


def aplatir(base: sqlite3.Connection, user_id: int, donnees: Dict[str, Any]) -> None:
    """Remplace les lignes de l'utilisateur par l'état actuel de ses pages (à appeler dans la transaction d'écriture)."""
    base.execute("DELETE FROM taches WHERE user_id = ?", (user_id,))
    lignes = []
    for page in donnees.get("pages", []):
        if not isinstance(page, dict):
            continue
        for bloc in page.get("blocs", []) or []:
            if not isinstance(bloc, dict) or bloc.get("type") != "tache" or not isinstance(bloc.get("id"), str):
                continue
            tags = bloc.get("tags") if isinstance(bloc.get("tags"), list) else []
            lignes.append((
                user_id, bloc["id"], _texte(page.get("id")), _texte(page.get("titre"), "Sans titre") or "Sans titre",
                _texte(bloc.get("texte")), 1 if bloc.get("fait") else 0, 1 if bloc.get("encours") else 0,
                _texte(bloc.get("echeance")) or None, _texte(bloc.get("heure")) or None,
                _entier(bloc.get("niveau")) or 0, " ".join(str(t) for t in tags if isinstance(t, str)),
                _texte(bloc.get("repete")) or None, _entier(bloc.get("creeLe")), _entier(bloc.get("faitLe")),
            ))
    base.executemany("INSERT OR REPLACE INTO taches VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", lignes)

    base.execute("DELETE FROM jours WHERE user_id = ?", (user_id,))
    stats = donnees.get("stats") if isinstance(donnees.get("stats"), dict) else {}
    faits = stats.get("faits") if isinstance(stats.get("faits"), dict) else {}
    pomos = stats.get("pomodoros") if isinstance(stats.get("pomodoros"), dict) else {}
    jours = []
    for jour in sorted(set(faits) | set(pomos)):
        jours.append((user_id, str(jour), _entier(faits.get(jour)) or 0, _entier(pomos.get(jour)) or 0))
    base.executemany("INSERT OR REPLACE INTO jours VALUES (?,?,?,?)", jours)


def _lignes(base: sqlite3.Connection, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    return [dict(r) for r in base.execute(sql, params).fetchall()]


def resume(base: sqlite3.Connection, user_id: int, aujourdhui: str = "") -> Dict[str, Any]:
    """Les chiffres du tableau de bord, tous calculés par des requêtes SQL."""
    aujourdhui = aujourdhui or time.strftime("%Y-%m-%d")
    u = (user_id,)

    total = _lignes(base, """
        SELECT COUNT(*)                                        AS total,
               COALESCE(SUM(fait), 0)                          AS faites,
               COALESCE(SUM(encours AND NOT fait), 0)          AS en_cours,
               COALESCE(SUM(NOT fait AND echeance IS NOT NULL AND echeance < ?), 0) AS en_retard,
               COALESCE(SUM(NOT fait AND echeance IS NULL), 0) AS sans_date
        FROM taches WHERE user_id = ?""", (aujourdhui, user_id))[0]
    total["taux_reussite"] = round(100 * total["faites"] / total["total"], 1) if total["total"] else 0.0

    par_page = _lignes(base, """
        SELECT page_titre AS page, COUNT(*) AS total, SUM(fait) AS faites,
               ROUND(100.0 * SUM(fait) / COUNT(*), 1) AS taux
        FROM taches WHERE user_id = ? GROUP BY page_id ORDER BY total DESC, page LIMIT 20""", u)

    # strftime('%w') : 0 = dimanche … 6 = samedi ; on renvoie lundi → dimanche
    par_jour_semaine = _lignes(base, """
        SELECT CAST(strftime('%w', fait_le / 1000, 'unixepoch') AS INTEGER) AS jour, COUNT(*) AS faites
        FROM taches WHERE user_id = ? AND fait = 1 AND fait_le IS NOT NULL GROUP BY jour""", u)
    semaine = {r["jour"]: r["faites"] for r in par_jour_semaine}
    noms = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"]
    semaine_ordonnee = [{"jour": noms[i], "faites": semaine.get((i + 1) % 7, 0)} for i in range(7)]

    delai = _lignes(base, """
        SELECT ROUND(AVG((fait_le - cree_le) / 3600000.0), 1) AS heures_moyennes
        FROM taches WHERE user_id = ? AND fait = 1 AND fait_le >= cree_le AND cree_le IS NOT NULL""", u)[0]

    derniers_jours = _lignes(base, """
        SELECT jour, faits, pomodoros FROM jours WHERE user_id = ? ORDER BY jour DESC LIMIT 14""", u)[::-1]

    top_tags = _lignes(base, """
        WITH RECURSIVE morceaux(tag, reste) AS (
            SELECT '', tags || ' ' FROM taches WHERE user_id = ? AND tags <> ''
            UNION ALL
            SELECT substr(reste, 1, instr(reste, ' ') - 1), substr(reste, instr(reste, ' ') + 1)
            FROM morceaux WHERE reste <> ''
        )
        SELECT tag, COUNT(*) AS nombre FROM morceaux WHERE tag <> '' GROUP BY tag ORDER BY nombre DESC, tag LIMIT 10""", u)

    serie = _lignes(base, """
        SELECT jour FROM jours WHERE user_id = ? AND faits > 0 ORDER BY jour DESC""", u)
    return {
        "genere": aujourdhui,
        "global": total,
        "par_page": par_page,
        "par_jour_semaine": semaine_ordonnee,
        "delai_moyen_heures": delai["heures_moyennes"],
        "derniers_jours": derniers_jours,
        "tags": top_tags,
        "jours_actifs": len(serie),
    }


COLONNES_CSV = ["page_titre", "texte", "fait", "encours", "echeance", "heure", "niveau", "tags", "repete", "cree_le", "fait_le"]


def _protege(valeur: Any) -> Any:
    # Évite qu'Excel interprète un texte comme une formule (=, +, -, @)
    if isinstance(valeur, str) and valeur[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + valeur
    return valeur


def exporter_csv(base: sqlite3.Connection, user_id: int) -> str:
    sortie = io.StringIO()
    ecrivain = csv.writer(sortie, delimiter=";", lineterminator="\r\n")
    ecrivain.writerow(COLONNES_CSV)
    for r in base.execute(f"SELECT {', '.join(COLONNES_CSV)} FROM taches WHERE user_id = ? ORDER BY page_titre, rowid", (user_id,)):
        ecrivain.writerow([_protege(r[c]) if r[c] is not None else "" for c in COLONNES_CSV])
    return "﻿" + sortie.getvalue()
