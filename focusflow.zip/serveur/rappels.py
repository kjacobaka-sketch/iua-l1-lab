"""
Rappels « push » : une notification arrive sur le téléphone même quand l'appli est fermée.

Fonctionnement :
  1. le navigateur s'abonne (Push API) et envoie son abonnement au serveur ;
  2. une boucle en arrière-plan regarde chaque minute les tâches arrivées à échéance ;
  3. le serveur envoie la notification au service push du navigateur (protocole Web Push + clés VAPID).

Les clés VAPID identifient ton serveur auprès des services push. Elles sont créées au premier
démarrage et gardées dans la base ; pour qu'elles survivent à un hébergement sans disque
persistant, tu peux les fournir par la variable d'environnement MES_BLOCS_VAPID_PEM.
"""

import base64
import json
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS config (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS push_abos (
    endpoint  TEXT PRIMARY KEY,
    user_id   INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    p256dh    TEXT NOT NULL,
    auth      TEXT NOT NULL,
    decalage  INTEGER NOT NULL DEFAULT 0,     -- Date.getTimezoneOffset() du navigateur (minutes)
    cree      REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS rappels_envoyes (
    user_id  INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
    bloc_id  TEXT NOT NULL,
    echeance TEXT NOT NULL,
    heure    TEXT NOT NULL,
    envoye   REAL NOT NULL,
    PRIMARY KEY (user_id, bloc_id, echeance, heure)
);
"""

HEURE_PAR_DEFAUT = "08:00"      # une tâche sans heure sonne à 8 h, comme dans l'appli (heure de la personne)
FENETRE = 12 * 3600             # on ne rappelle plus une tâche échue depuis plus de 12 h
SUJET_VAPID = os.environ.get("MES_BLOCS_VAPID_SUJET", "mailto:contact@focusflow.invalid")


# ---------------------------------------------------------------- clés VAPID

def _pem(base: sqlite3.Connection) -> Optional[str]:
    from py_vapid import Vapid

    pem = os.environ.get("MES_BLOCS_VAPID_PEM")
    if pem:
        return pem.replace("\\n", "\n")
    ligne = base.execute("SELECT valeur FROM config WHERE cle = 'vapid_pem'").fetchone()
    if ligne:
        return ligne[0]
    vapid = Vapid()
    vapid.generate_keys()
    pem = vapid.private_pem().decode()
    base.execute("INSERT OR IGNORE INTO config (cle, valeur) VALUES ('vapid_pem', ?)", (pem,))
    return pem


def cle_publique(base: sqlite3.Connection) -> str:
    """La clé publique (base64url) que le navigateur doit connaître pour s'abonner."""
    from cryptography.hazmat.primitives import serialization
    from py_vapid import Vapid

    vapid = Vapid.from_pem(_pem(base).encode())
    brut = vapid.public_key.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    return base64.urlsafe_b64encode(brut).rstrip(b"=").decode()


def envoyer_push(base: sqlite3.Connection, abo: sqlite3.Row, message: Dict[str, Any]) -> bool:
    """Envoie une notification. Renvoie False si l'abonnement est mort (à supprimer)."""
    from py_vapid import Vapid
    from pywebpush import WebPushException, webpush

    try:
        webpush(
            subscription_info={"endpoint": abo["endpoint"], "keys": {"p256dh": abo["p256dh"], "auth": abo["auth"]}},
            data=json.dumps(message, ensure_ascii=False),
            vapid_private_key=Vapid.from_pem(_pem(base).encode()),
            vapid_claims={"sub": SUJET_VAPID},
            ttl=3600,
        )
        return True
    except WebPushException as erreur:
        statut = getattr(erreur.response, "status_code", None)
        if statut in (404, 410):
            return False
        raise


# ---------------------------------------------------------------- recherche des tâches à rappeler

def _echeance_utc(echeance: str, heure: Optional[str], decalage: int) -> Optional[datetime]:
    try:
        local = datetime.strptime(echeance + " " + (heure or HEURE_PAR_DEFAUT), "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    # getTimezoneOffset() = UTC − heure locale (en minutes) : UTC = local + décalage
    return (local + timedelta(minutes=decalage)).replace(tzinfo=timezone.utc)


def verifier_rappels(base: sqlite3.Connection, maintenant: Optional[datetime] = None,
                     envoyer: Callable[..., bool] = envoyer_push) -> int:
    """Envoie les rappels dus. Renvoie le nombre de notifications envoyées."""
    maintenant = maintenant or datetime.now(timezone.utc)
    envoyes = 0
    abos = base.execute("SELECT * FROM push_abos").fetchall()
    par_utilisateur: Dict[int, list] = {}
    for abo in abos:
        par_utilisateur.setdefault(abo["user_id"], []).append(abo)

    for user_id, liste in par_utilisateur.items():
        decalage = liste[0]["decalage"]
        taches = base.execute(
            "SELECT bloc_id, texte, page_titre, echeance, heure FROM taches "
            "WHERE user_id = ? AND fait = 0 AND echeance IS NOT NULL AND niveau >= 0", (user_id,)).fetchall()
        for t in taches:
            quand = _echeance_utc(t["echeance"], t["heure"], decalage)
            if quand is None or not (quand <= maintenant < quand + timedelta(seconds=FENETRE)):
                continue
            cle = (user_id, t["bloc_id"], t["echeance"], t["heure"] or "")
            if base.execute("SELECT 1 FROM rappels_envoyes WHERE user_id=? AND bloc_id=? AND echeance=? AND heure=?", cle).fetchone():
                continue
            # on note d'abord : mieux vaut rater un rappel que l'envoyer deux fois
            base.execute("INSERT OR IGNORE INTO rappels_envoyes VALUES (?,?,?,?,?)", cle + (time.time(),))
            message = {"titre": "⏰ " + (t["texte"] or "Tâche sans titre"), "corps": t["page_titre"], "tag": t["bloc_id"]}
            for abo in liste:
                try:
                    vivant = envoyer(base, abo, message)
                except Exception:
                    continue
                if vivant:
                    envoyes += 1
                else:
                    base.execute("DELETE FROM push_abos WHERE endpoint = ?", (abo["endpoint"],))
    # ménage : on oublie les rappels de plus de 3 jours
    base.execute("DELETE FROM rappels_envoyes WHERE envoye < ?", (time.time() - 3 * 86400,))
    return envoyes


def demarrer_boucle(ouvrir_base, intervalle: int = 60) -> threading.Thread:
    """Lance la vérification en arrière-plan (un fil qui s'arrête avec le serveur)."""

    def boucle():
        while True:
            time.sleep(intervalle)
            try:
                with ouvrir_base() as base:
                    verifier_rappels(base)
            except Exception:
                pass  # un souci ponctuel (base verrouillée, réseau) ne doit pas arrêter les rappels

    fil = threading.Thread(target=boucle, name="rappels", daemon=True)
    fil.start()
    return fil
