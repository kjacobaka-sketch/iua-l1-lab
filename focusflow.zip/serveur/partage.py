"""
Liens de partage en lecture seule.

Le lien (/p/<jeton>) montre la dernière version synchronisée d'UNE page, sans compte
et sans pouvoir la modifier. La personne qui l'a créé peut le révoquer à tout moment.
Tout le texte est échappé : aucune balise venue des données n'est jamais interprétée.
"""

import html
import re
from typing import Any, Dict, Optional

IMAGE_OK = re.compile(r"^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$")
COULEURS = {"violet": "#6366f1", "bleu": "#3b82f6", "vert": "#10b981", "orange": "#f59e0b", "rose": "#ec4899", "turquoise": "#14b8a6"}

CSS = """
:root{--fond:#f7f6fb;--carte:#fff;--texte:#1b1b2f;--doux:#6b6b85;--trait:#e4e3ef;--accent:%(accent)s}
@media(prefers-color-scheme:dark){:root{--fond:#13132b;--carte:#1c1c3a;--texte:#ececf8;--doux:#a3a3c2;--trait:#2d2d52}}
*{box-sizing:border-box}body{margin:0;background:var(--fond);color:var(--texte);font:17px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:720px;margin:0 auto;padding:28px 18px 60px}
header{border-top:5px solid var(--accent);background:var(--carte);border-radius:16px;padding:22px;margin-bottom:18px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
h1{margin:0;font-size:1.7rem;line-height:1.25}.ico{font-size:2.2rem;display:block;margin-bottom:6px}
.meta{color:var(--doux);font-size:.85rem;margin-top:8px}
article{background:var(--carte);border-radius:16px;padding:12px 22px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
article p,article li,article blockquote{margin:.45em 0;overflow-wrap:anywhere}
h2{font-size:1.35rem;margin:1.1em 0 .3em}h3{font-size:1.1rem;margin:1em 0 .2em;color:var(--doux)}
blockquote{border-left:4px solid var(--accent);padding-left:14px;color:var(--doux);font-style:italic}
hr{border:0;border-top:1px solid var(--trait);margin:1em 0}
.tache{display:flex;gap:10px;align-items:flex-start;margin:.45em 0}
.case{flex:none;width:20px;height:20px;border-radius:50%%;border:2px solid var(--doux);margin-top:5px;display:grid;place-items:center;font-size:12px;color:#fff}
.fait .case{background:var(--accent);border-color:var(--accent)}.fait .t{text-decoration:line-through;color:var(--doux)}
.date{font-size:.8rem;color:var(--doux);margin-left:6px}
figure{margin:.8em 0}figure img{max-width:100%%;border-radius:12px;display:block}figcaption{color:var(--doux);font-size:.85rem;margin-top:4px}
footer{text-align:center;color:var(--doux);font-size:.8rem;margin-top:22px}
"""


def _e(texte: Any) -> str:
    return html.escape(texte if isinstance(texte, str) else "", quote=True)


def trouver_page(donnees: Optional[Dict[str, Any]], page_id: str) -> Optional[Dict[str, Any]]:
    for page in (donnees or {}).get("pages", []):
        if isinstance(page, dict) and page.get("id") == page_id:
            return page
    return None


def rendre(page: Dict[str, Any], auteur: str) -> str:
    accent = COULEURS.get(page.get("couleur"), COULEURS["violet"])
    morceaux = []
    ouvert = None  # "ul" ou "ol" en cours

    def fermer():
        nonlocal ouvert
        if ouvert:
            morceaux.append("</%s>" % ouvert)
            ouvert = None

    for bloc in page.get("blocs", []) or []:
        if not isinstance(bloc, dict):
            continue
        type_, t = bloc.get("type"), _e(bloc.get("texte"))
        marge = min(int(bloc.get("niveau") or 0), 4) * 22 if isinstance(bloc.get("niveau"), int) else 0
        if type_ in ("liste", "numerotee"):
            balise = "ul" if type_ == "liste" else "ol"
            if ouvert != balise:
                fermer()
                morceaux.append("<%s>" % balise)
                ouvert = balise
            morceaux.append('<li style="margin-left:%dpx">%s</li>' % (marge, t))
            continue
        fermer()
        if type_ == "titre":
            morceaux.append("<h2>%s</h2>" % t)
        elif type_ == "sous_titre":
            morceaux.append("<h3>%s</h3>" % t)
        elif type_ == "tache":
            date = ""
            if bloc.get("echeance"):
                date = '<span class="date">📅 %s%s</span>' % (_e(bloc["echeance"]), " " + _e(bloc.get("heure")) if bloc.get("heure") else "")
            morceaux.append('<div class="tache%s" style="margin-left:%dpx"><span class="case">%s</span><span class="t">%s%s</span></div>'
                            % (" fait" if bloc.get("fait") else "", marge, "✓" if bloc.get("fait") else "", t, date))
        elif type_ == "citation":
            morceaux.append("<blockquote>%s</blockquote>" % t)
        elif type_ == "separateur":
            morceaux.append("<hr>")
        elif type_ == "image":
            src = bloc.get("src")
            if isinstance(src, str) and IMAGE_OK.match(src):
                morceaux.append('<figure><img src="%s" alt="%s">%s</figure>' % (src, t, "<figcaption>%s</figcaption>" % t if t else ""))
        else:
            morceaux.append("<p>%s</p>" % (t or "&nbsp;"))
    fermer()

    taches = [b for b in page.get("blocs", []) if isinstance(b, dict) and b.get("type") == "tache"]
    faites = sum(1 for b in taches if b.get("fait"))
    resume = "%d / %d tâche%s terminée%s" % (faites, len(taches), "s" if len(taches) > 1 else "", "s" if faites > 1 else "") if taches else ""
    titre = page.get("titre") or "Sans titre"
    return (
        '<!doctype html><html lang="fr"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer">'
        "<title>%s · FocusFlow</title><style>%s</style></head><body><main>"
        '<header><span class="ico">%s</span><h1>%s</h1><div class="meta">Partagé par %s · lecture seule%s</div></header>'
        "<article>%s</article><footer>Page partagée avec FocusFlow</footer></main></body></html>"
    ) % (_e(titre), CSS % {"accent": accent}, _e(page.get("icone") or "📝"), _e(titre), _e(auteur),
         " · " + resume if resume else "", "".join(morceaux))


PAGE_INTROUVABLE = (
    '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    '<meta name="robots" content="noindex"><title>Lien indisponible</title></head>'
    '<body style="font-family:system-ui;text-align:center;padding:15vh 20px;color:#444">'
    "<h1>🔒 Ce lien n'est plus disponible</h1><p>Il a été désactivé, ou la page n'existe plus.</p></body></html>"
)
