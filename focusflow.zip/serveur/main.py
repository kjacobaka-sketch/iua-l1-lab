"""
Serveur de synchronisation pour « FocusFlow » (FastAPI + SQLite).

Il fait six choses :
  1. créer des comptes et connecter les utilisateurs ;
  2. stocker les pages de chaque utilisateur dans une base SQLite ;
  3. analyser les tâches en SQL (/api/analyse, /api/export.csv) ;
  4. envoyer des rappels push (rappels.py) ;
  5. publier des pages en lecture seule via un lien révocable (partage.py) ;
  6. servir l'appli elle-même (pratique en local : un seul serveur à lancer).

Lancer (depuis le dossier du projet, celui qui contient index.html) :
    pip install -r serveur/requirements.txt
    python -m uvicorn serveur.main:app --port 8000
"""

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import analyse, partage, rappels

DOSSIER = Path(__file__).resolve().parent
RACINE = DOSSIER.parent
BASE = Path(os.environ.get("MES_BLOCS_DB", DOSSIER / "donnees.db"))
# Adresses autorisées à appeler l'API depuis un autre site (ex. l'appli sur Netlify).
# Par défaut tout est autorisé : l'accès se fait par jeton, pas par cookie.
ORIGINES = [o.strip() for o in os.environ.get("MES_BLOCS_ORIGINES", "*").split(",") if o.strip()]
TAILLE_MAX = 5 * 1024 * 1024          # 5 Mo de données par utilisateur
DUREE_SESSION = 90 * 24 * 3600        # une connexion reste valable 90 jours


# ---------------------------------------------------------------- base de données

@contextmanager
def connexion():
    base = sqlite3.connect(BASE, timeout=10, isolation_level=None)  # isolation_level=None : on gère les transactions
    base.row_factory = sqlite3.Row
    base.execute("PRAGMA foreign_keys = ON")
    try:
        yield base
    finally:
        base.close()


def initialiser() -> None:
    BASE.parent.mkdir(parents=True, exist_ok=True)
    with connexion() as base:
        base.execute("PRAGMA journal_mode = WAL")
        base.executescript(
            """
            CREATE TABLE IF NOT EXISTS utilisateurs (
                id      INTEGER PRIMARY KEY,
                nom     TEXT NOT NULL UNIQUE COLLATE NOCASE,
                sel     BLOB NOT NULL,
                hash    BLOB NOT NULL,
                cree    REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                jeton_hash TEXT PRIMARY KEY,
                user_id    INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
                cree       REAL NOT NULL,
                expire     REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS donnees (
                user_id INTEGER PRIMARY KEY REFERENCES utilisateurs(id) ON DELETE CASCADE,
                contenu TEXT NOT NULL,
                version INTEGER NOT NULL,
                maj     REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS partages (
                jeton   TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES utilisateurs(id) ON DELETE CASCADE,
                page_id TEXT NOT NULL,
                cree    REAL NOT NULL
            );
            """
        )
        base.executescript(analyse.SCHEMA)
        base.executescript(rappels.SCHEMA)


# ---------------------------------------------------------------- mots de passe et jetons

def hacher(mot_de_passe: str, sel: bytes) -> bytes:
    # scrypt est volontairement lent : cela décourage les attaques par essais répétés
    return hashlib.scrypt(mot_de_passe.encode("utf-8"), salt=sel, n=2**14, r=8, p=1, dklen=32)


def hacher_jeton(jeton: str) -> str:
    return hashlib.sha256(jeton.encode("utf-8")).hexdigest()


def creer_session(base: sqlite3.Connection, user_id: int) -> str:
    jeton = secrets.token_urlsafe(32)
    maintenant = time.time()
    base.execute("DELETE FROM sessions WHERE expire < ?", (maintenant,))
    base.execute(
        "INSERT INTO sessions (jeton_hash, user_id, cree, expire) VALUES (?, ?, ?, ?)",
        (hacher_jeton(jeton), user_id, maintenant, maintenant + DUREE_SESSION),
    )
    return jeton


# Limite les essais pour freiner les attaques (en mémoire : se remet à zéro au redémarrage)
_essais: Dict[str, list] = {}


def limiter(cle: str, maximum: int, fenetre: int) -> None:
    maintenant = time.time()
    liste = [t for t in _essais.get(cle, []) if maintenant - t < fenetre]
    if len(liste) >= maximum:
        raise HTTPException(429, "Trop d'essais. Réessaie dans quelques minutes.")
    liste.append(maintenant)
    _essais[cle] = liste


# ---------------------------------------------------------------- modèles

class Identifiants(BaseModel):
    nom: str = Field(min_length=3, max_length=40, pattern=r"^[\w.\-@]+$")
    mot_de_passe: str = Field(min_length=8, max_length=200)


class Envoi(BaseModel):
    base_version: int = Field(ge=0)
    donnees: Dict[str, Any]


class Cles(BaseModel):
    p256dh: str = Field(min_length=10, max_length=300)
    auth: str = Field(min_length=10, max_length=100)


class Abonnement(BaseModel):
    endpoint: str = Field(min_length=10, max_length=1000, pattern=r"^https://")
    keys: Cles
    decalage: int = Field(default=0, ge=-840, le=840)    # Date.getTimezoneOffset()


class Desabonnement(BaseModel):
    endpoint: str = Field(min_length=10, max_length=1000)


class NouveauPartage(BaseModel):
    page_id: str = Field(min_length=1, max_length=100)


# ---------------------------------------------------------------- application

app = FastAPI(title="FocusFlow : API", description="Synchronisation, analyse, rappels push et partage de pages.",
              docs_url="/api/docs", redoc_url=None, openapi_url="/api/openapi.json")
app.add_middleware(
    CORSMiddleware,
    allow_origins=ORIGINES,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
    allow_credentials=False,
)


@app.on_event("startup")
def au_demarrage() -> None:
    initialiser()
    if not os.environ.get("MES_BLOCS_SANS_RAPPELS"):   # les tests coupent la boucle d'arrière-plan
        rappels.demarrer_boucle(connexion)


@app.middleware("http")
async def entetes_securite(request: Request, appel):
    reponse = await appel(request)
    reponse.headers["X-Content-Type-Options"] = "nosniff"
    if request.url.path.startswith("/api"):
        reponse.headers["Cache-Control"] = "no-store"
    return reponse


def utilisateur_courant(authorization: Optional[str] = Header(default=None)) -> sqlite3.Row:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Connexion requise")
    jeton = authorization[7:].strip()
    with connexion() as base:
        ligne = base.execute(
            """SELECT u.id, u.nom FROM sessions s JOIN utilisateurs u ON u.id = s.user_id
               WHERE s.jeton_hash = ? AND s.expire > ?""",
            (hacher_jeton(jeton), time.time()),
        ).fetchone()
    if ligne is None:
        raise HTTPException(401, "Session expirée, reconnecte-toi")
    return ligne


@app.get("/api/sante")
def sante():
    return {"ok": True}


@app.post("/api/inscription")
def inscription(identifiants: Identifiants, requete: Request):
    ip = requete.client.host if requete.client else "?"
    limiter("inscription:" + ip, maximum=10, fenetre=3600)
    sel = secrets.token_bytes(16)
    empreinte = hacher(identifiants.mot_de_passe, sel)
    with connexion() as base:
        try:
            curseur = base.execute(
                "INSERT INTO utilisateurs (nom, sel, hash, cree) VALUES (?, ?, ?, ?)",
                (identifiants.nom, sel, empreinte, time.time()),
            )
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Ce nom d'utilisateur est déjà pris")
        jeton = creer_session(base, curseur.lastrowid)
    return {"token": jeton, "nom": identifiants.nom}


@app.post("/api/connexion")
def connexion_utilisateur(identifiants: Identifiants, requete: Request):
    ip = requete.client.host if requete.client else "?"
    limiter("connexion:" + ip + ":" + identifiants.nom.lower(), maximum=8, fenetre=600)
    with connexion() as base:
        ligne = base.execute("SELECT id, nom, sel, hash FROM utilisateurs WHERE nom = ?", (identifiants.nom,)).fetchone()
        # On calcule toujours un hachage, pour ne pas révéler si le nom existe
        sel = ligne["sel"] if ligne else b"\x00" * 16
        attendu = ligne["hash"] if ligne else b"\x00" * 32
        correct = hmac.compare_digest(hacher(identifiants.mot_de_passe, sel), attendu)
        if not ligne or not correct:
            raise HTTPException(401, "Nom ou mot de passe incorrect")
        jeton = creer_session(base, ligne["id"])
    return {"token": jeton, "nom": ligne["nom"]}


@app.post("/api/deconnexion")
def deconnexion(authorization: Optional[str] = Header(default=None), _: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        base.execute("DELETE FROM sessions WHERE jeton_hash = ?", (hacher_jeton(authorization[7:].strip()),))
    return {"ok": True}


@app.get("/api/donnees")
def lire_donnees(utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        ligne = base.execute("SELECT contenu, version FROM donnees WHERE user_id = ?", (utilisateur["id"],)).fetchone()
    if ligne is None:
        return {"version": 0, "donnees": None}
    return {"version": ligne["version"], "donnees": json.loads(ligne["contenu"])}


@app.put("/api/donnees")
def ecrire_donnees(envoi: Envoi, utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    if not isinstance(envoi.donnees.get("pages"), list):
        raise HTTPException(422, "Données invalides : il manque la liste des pages")
    contenu = json.dumps(envoi.donnees, ensure_ascii=False, separators=(",", ":"))
    if len(contenu.encode("utf-8")) > TAILLE_MAX:
        raise HTTPException(413, "Données trop volumineuses (5 Mo maximum)")

    with connexion() as base:
        base.execute("BEGIN IMMEDIATE")  # verrou : deux appareils ne peuvent pas écrire en même temps
        try:
            ligne = base.execute("SELECT contenu, version FROM donnees WHERE user_id = ?", (utilisateur["id"],)).fetchone()
            version = ligne["version"] if ligne else 0
            if version != envoi.base_version:
                # Un autre appareil a écrit entre-temps : le client doit refaire la fusion
                base.execute("ROLLBACK")
                return JSONResponse(
                    status_code=409,
                    content={"detail": "Conflit de version", "version": version,
                             "donnees": json.loads(ligne["contenu"]) if ligne else None},
                )
            nouvelle = version + 1
            base.execute(
                """INSERT INTO donnees (user_id, contenu, version, maj) VALUES (?, ?, ?, ?)
                   ON CONFLICT(user_id) DO UPDATE SET contenu = excluded.contenu,
                                                       version = excluded.version, maj = excluded.maj""",
                (utilisateur["id"], contenu, nouvelle, time.time()),
            )
            analyse.aplatir(base, utilisateur["id"], envoi.donnees)   # tâches -> table SQL, dans la même transaction
            base.execute("COMMIT")
        except HTTPException:
            raise
        except Exception:
            base.execute("ROLLBACK")
            raise
    return {"version": nouvelle}


# ---------------------------------------------------------------- analyse (SQL)

@app.get("/api/analyse")
def lire_analyse(utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        return analyse.resume(base, utilisateur["id"])


@app.get("/api/export.csv")
def exporter_csv(utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        contenu = analyse.exporter_csv(base, utilisateur["id"])
    return Response(contenu, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="focusflow-taches.csv"'})


# ---------------------------------------------------------------- rappels push

@app.get("/api/push/cle")
def cle_push():
    try:
        with connexion() as base:
            return {"cle": rappels.cle_publique(base)}
    except ImportError:
        raise HTTPException(503, "Les notifications push ne sont pas installées sur ce serveur (pip install pywebpush)")


@app.post("/api/push/abonner")
def abonner(abo: Abonnement, utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        base.execute(
            """INSERT INTO push_abos (endpoint, user_id, p256dh, auth, decalage, cree) VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh,
                                                   auth = excluded.auth, decalage = excluded.decalage""",
            (abo.endpoint, utilisateur["id"], abo.keys.p256dh, abo.keys.auth, abo.decalage, time.time()))
    return {"ok": True}


@app.post("/api/push/desabonner")
def desabonner(d: Desabonnement, utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        base.execute("DELETE FROM push_abos WHERE endpoint = ? AND user_id = ?", (d.endpoint, utilisateur["id"]))
    return {"ok": True}


# ---------------------------------------------------------------- liens de partage (lecture seule)

@app.post("/api/partages")
def creer_partage(demande: NouveauPartage, utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        ligne = base.execute("SELECT contenu FROM donnees WHERE user_id = ?", (utilisateur["id"],)).fetchone()
        page = partage.trouver_page(json.loads(ligne["contenu"]) if ligne else None, demande.page_id)
        if page is None:
            raise HTTPException(404, "Cette page n'est pas encore synchronisée : synchronise d'abord, puis réessaie")
        existant = base.execute("SELECT jeton FROM partages WHERE user_id = ? AND page_id = ?",
                                (utilisateur["id"], demande.page_id)).fetchone()
        if existant:
            return {"jeton": existant["jeton"], "chemin": "/p/" + existant["jeton"]}
        nb = base.execute("SELECT COUNT(*) FROM partages WHERE user_id = ?", (utilisateur["id"],)).fetchone()[0]
        if nb >= 50:
            raise HTTPException(429, "Trop de liens actifs (50 maximum) : désactive-en quelques-uns")
        jeton = secrets.token_urlsafe(16)
        base.execute("INSERT INTO partages (jeton, user_id, page_id, cree) VALUES (?, ?, ?, ?)",
                     (jeton, utilisateur["id"], demande.page_id, time.time()))
    return {"jeton": jeton, "chemin": "/p/" + jeton}


@app.get("/api/partages")
def lister_partages(utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        liens = base.execute("SELECT jeton, page_id, cree FROM partages WHERE user_id = ? ORDER BY cree DESC",
                             (utilisateur["id"],)).fetchall()
        ligne = base.execute("SELECT contenu FROM donnees WHERE user_id = ?", (utilisateur["id"],)).fetchone()
    donnees = json.loads(ligne["contenu"]) if ligne else None
    resultat = []
    for lien in liens:
        page = partage.trouver_page(donnees, lien["page_id"])
        resultat.append({"jeton": lien["jeton"], "page_id": lien["page_id"], "cree": lien["cree"],
                         "titre": (page or {}).get("titre") or ("(page supprimée)" if page is None else "Sans titre")})
    return {"partages": resultat}


@app.delete("/api/partages/{jeton}")
def revoquer_partage(jeton: str, utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        base.execute("DELETE FROM partages WHERE jeton = ? AND user_id = ?", (jeton, utilisateur["id"]))
    return {"ok": True}


@app.get("/p/{jeton}", include_in_schema=False)
def voir_page_partagee(jeton: str, requete: Request):
    ip = requete.client.host if requete.client else "?"
    limiter("partage:" + ip, maximum=120, fenetre=60)
    entetes = {
        "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'",
        "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex, nofollow", "Cache-Control": "no-store",
    }
    with connexion() as base:
        lien = base.execute(
            "SELECT p.page_id, p.user_id, u.nom FROM partages p JOIN utilisateurs u ON u.id = p.user_id WHERE p.jeton = ?",
            (jeton,)).fetchone()
        ligne = base.execute("SELECT contenu FROM donnees WHERE user_id = ?", (lien["user_id"],)).fetchone() if lien else None
    page = partage.trouver_page(json.loads(ligne["contenu"]), lien["page_id"]) if ligne else None
    if page is None:
        return HTMLResponse(partage.PAGE_INTROUVABLE, status_code=404, headers=entetes)
    return HTMLResponse(partage.rendre(page, lien["nom"]), headers=entetes)


@app.delete("/api/compte")
def supprimer_compte(utilisateur: sqlite3.Row = Depends(utilisateur_courant)):
    with connexion() as base:
        base.execute("DELETE FROM utilisateurs WHERE id = ?", (utilisateur["id"],))  # sessions et données suivent
    return {"ok": True}


# ---------------------------------------------------------------- l'appli elle-même
# On ne sert que les fichiers de l'appli (jamais le dossier serveur/ ni la base de données).

FICHIERS = ["index.html", "style.css", "blocs.css", "extras.css", "design.css", "app.js", "sw.js", "manifest.json"]


def _servir(nom: str):
    chemin = RACINE / nom

    def reponse():
        if not chemin.is_file():
            raise HTTPException(404, "Introuvable")
        return FileResponse(chemin, headers={"Cache-Control": "no-cache"})

    return reponse


for _nom in FICHIERS:
    app.add_api_route("/" + _nom, _servir(_nom), methods=["GET", "HEAD"], include_in_schema=False)
app.add_api_route("/", _servir("index.html"), methods=["GET", "HEAD"], include_in_schema=False)

for _dossier in ("js", "icons"):
    if (RACINE / _dossier).is_dir():
        app.mount("/" + _dossier, StaticFiles(directory=RACINE / _dossier), name=_dossier)
