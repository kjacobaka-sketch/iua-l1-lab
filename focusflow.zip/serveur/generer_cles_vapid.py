"""
Génère une clé privée VAPID (pour les rappels push) à mettre dans la variable d'environnement
MES_BLOCS_VAPID_PEM de ton hébergeur. Utile quand le disque du serveur n'est pas conservé :
sans cela, une nouvelle clé serait créée à chaque redémarrage et les abonnements push cesseraient de marcher.

    python serveur/generer_cles_vapid.py
"""
from py_vapid import Vapid

vapid = Vapid()
vapid.generate_keys()
pem = vapid.private_pem().decode().strip()
print("Copie cette valeur dans MES_BLOCS_VAPID_PEM (les retours à la ligne peuvent être écrits \\n) :\n")
print(pem.replace("\n", "\\n"))
