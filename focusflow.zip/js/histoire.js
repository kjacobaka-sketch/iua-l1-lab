"use strict";

/* =====================================================
   histoire.js : annuler (Ctrl+Z) et rétablir (Ctrl+Y)
   On garde des « photos » successives des pages.
   ===================================================== */

App.Histoire = (function () {
  const MAX = 100;
  let pile = [];        // photos passées
  let futur = [];       // photos annulées (pour rétablir)
  let minuteur = null;
  let bloque = false;   // vrai pendant qu'on restaure une photo

  // La date de modification ("maj") n'est pas comparée : annuler ne doit pas créer une nouvelle photo
  const photo = () => JSON.stringify({ pages: App.etat.pages, courante: App.etat.courante }, (cle, valeur) => (cle === "maj" ? undefined : valeur));
  let courant = photo();

  function majBoutons() {
    document.querySelectorAll("[data-action='annuler']").forEach((b) => { b.disabled = pile.length === 0; });
    document.querySelectorAll("[data-action='retablir']").forEach((b) => { b.disabled = futur.length === 0; });
  }

  // Enregistre une nouvelle photo si quelque chose a changé
  function noter() {
    if (bloque) return;
    clearTimeout(minuteur);
    const s = photo();
    if (s === courant) return;
    pile.push(courant);
    if (pile.length > MAX) pile.shift();
    courant = s;
    futur = [];
    majBoutons();
  }

  // Pendant la frappe, on attend une pause pour ne pas faire une photo par lettre
  function differe() {
    if (bloque) return;
    clearTimeout(minuteur);
    minuteur = setTimeout(noter, 600);
  }

  function restaurer(instantane) {
    const donnees = JSON.parse(instantane);
    const avant = new Set(App.etat.pages.map((p) => p.id));
    const n = App.normaliser({ pages: donnees.pages, courante: donnees.courante, __sansDemo: true });
    const apres = new Set(n.pages.map((p) => p.id));

    // Les pages qui disparaissent (ou reviennent) sont notées pour la synchronisation
    avant.forEach((id) => { if (!apres.has(id)) App.etat.supprimees[id] = Date.now(); });
    apres.forEach((id) => { if (!avant.has(id)) delete App.etat.supprimees[id]; });

    bloque = true;
    App.etat.pages = n.pages.length ? n.pages : [App.nouvellePage()];
    App.etat.courante = App.etat.pages.some((p) => p.id === n.courante) ? n.courante : App.etat.pages[0].id;
    App.sauver();
    App.ouvrirPage(App.etat.courante, false);
    bloque = false;
    majBoutons();
  }

  function annuler() {
    noter();
    if (!pile.length) { App.Toast.afficher("Rien à annuler"); return; }
    futur.push(courant);
    courant = pile.pop();
    restaurer(courant);
  }

  function retablir() {
    noter();
    if (!futur.length) { App.Toast.afficher("Rien à rétablir"); return; }
    pile.push(courant);
    courant = futur.pop();
    restaurer(courant);
  }

  App.ecouteurs.push(differe);

  // Raccourcis clavier (sauf dans les champs de formulaire, qui ont leur propre annulation)
  document.addEventListener("keydown", (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
    const cible = e.target;
    if (cible && /^(INPUT|TEXTAREA|SELECT)$/.test(cible.tagName)) return;
    if (document.querySelector("dialog[open]")) return;
    const touche = e.key.toLowerCase();
    if (touche === "z") { e.preventDefault(); e.shiftKey ? retablir() : annuler(); }
    else if (touche === "y") { e.preventDefault(); retablir(); }
  });

  document.addEventListener("click", (e) => {
    const bouton = e.target.closest("[data-action]");
    if (!bouton) return;
    if (bouton.dataset.action === "annuler") annuler();
    if (bouton.dataset.action === "retablir") retablir();
  });

  return { annuler, retablir, noter, majBoutons };
})();
