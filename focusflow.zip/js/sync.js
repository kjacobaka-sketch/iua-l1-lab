"use strict";

/* =====================================================
   sync.js : synchronisation entre appareils avec le serveur (serveur/main.py)
   Principe : on télécharge la version du serveur, on la fusionne avec la nôtre
   (la page modifiée en dernier gagne), puis on renvoie le résultat.
   ===================================================== */

App.Sync = (function () {
  const CLE = "mes-blocs-sync";
  const $ = (id) => document.getElementById(id);

  let config = lireConfig();
  let enCours = false;
  let encore = false;          // une nouvelle synchro est demandée pendant qu'une autre tourne
  let minuteur = null;
  let applique = false;        // vrai pendant qu'on applique des données venues du serveur
  let etat = { code: config.token ? "attente" : "deconnecte", message: "" };

  function lireConfig() {
    const defaut = { url: "", token: "", nom: "", version: 0, auto: true };
    try { return Object.assign(defaut, JSON.parse(localStorage.getItem(CLE) || "{}")); } catch (erreur) { return defaut; }
  }
  function ecrireConfig() {
    try { localStorage.setItem(CLE, JSON.stringify(config)); } catch (erreur) { /* ignoré */ }
  }

  const base = () => String(config.url || "").trim().replace(/\/+$/, ""); // "" = le serveur qui a servi l'appli

  async function requete(methode, chemin, corps, avecJeton, delaiMs) {
    const entetes = { "Content-Type": "application/json" };
    if (avecJeton !== false && config.token) entetes.Authorization = "Bearer " + config.token;
    const ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), delaiMs || 35000) : null;
    try {
      const reponse = await fetch(base() + "/api" + chemin, {
        method: methode,
        headers: entetes,
        body: corps ? JSON.stringify(corps) : undefined,
        signal: ctrl ? ctrl.signal : undefined,
      });
      let donnees = null;
      try { donnees = await reponse.json(); } catch (erreur) { /* pas de JSON */ }
      return { statut: reponse.status, donnees: donnees };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  const messageErreur = (r) => (r.donnees && typeof r.donnees.detail === "string" ? r.donnees.detail
    : r.donnees && Array.isArray(r.donnees.detail) ? "Nom (3 caractères minimum, sans espace) ou mot de passe (8 caractères minimum) invalide"
    : "Erreur du serveur (" + r.statut + ")");


  /* ---------- État affiché ---------- */

  function majEtat(code, message) {
    etat = { code: code, message: message || "" };
    const point = $("etat-sync");
    if (point) {
      point.dataset.etat = code;
      point.title = message || "";
    }
    const texte = $("texte-sync");
    if (texte) texte.textContent = config.token ? (code === "sync" ? "Synchronisation…" : code === "ok" ? "Synchronisé" : code === "hors-ligne" ? "Hors ligne" : code === "erreur" ? "Erreur" : "Synchronisation") : "Synchronisation";
    const dansFeuille = $("sync-statut");
    if (dansFeuille) dansFeuille.textContent = message || "";
  }

  const heure = () => new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });


  /* ---------- Comparaison et application ---------- */

  // Empreinte d'un ensemble de données, indépendante de l'ordre des pages
  function empreinte(d) {
    return JSON.stringify([
      [...d.pages].sort((a, b) => (a.id < b.id ? -1 : 1)),
      d.corbeille.map((e) => e.id).sort(),
      Object.keys(d.supprimees).sort().map((k) => [k, d.supprimees[k]]),
      d.stats,
    ]);
  }

  const copieLocale = () => App.normaliser(Object.assign(JSON.parse(JSON.stringify(App.donneesExportables())), { __sansDemo: true }));
  const versServeur = (d) => ({ format: "mes-blocs", version: 3, pages: d.pages, corbeille: d.corbeille, supprimees: d.supprimees, stats: d.stats });

  // Applique des données venues du serveur sans perdre le curseur de l'utilisateur
  function appliquer(fusion) {
    const curseur = App.curseurActuel();
    applique = true;
    App.appliquerDonnees(fusion, { sansMaj: true, afficher: false });
    if (App.afficherEntete) {
      App.afficherEntete();
      App.afficherBlocs(null);
      App.afficherPages();
      App.Vues.afficherBoutons();
      if (curseur) App.focaliser(curseur.id, curseur.pos);
    }
    applique = false;
  }


  /* ---------- Synchronisation ---------- */

  async function synchroniser(manuel) {
    if (!config.token) return;
    if (enCours) { encore = true; return; }
    enCours = true;
    majEtat("sync", "Synchronisation…");
    try {
      if (App.ImagesDB) await App.ImagesDB.pret();
      for (let essai = 0; essai < 4; essai++) {
        const lu = await requete("GET", "/donnees");
        if (lu.statut === 401) { deconnecterLocalement("Session expirée : reconnecte-toi"); return; }
        if (lu.statut !== 200) throw new Error(messageErreur(lu));

        const distant = lu.donnees.donnees
          ? App.normaliser(Object.assign({}, lu.donnees.donnees, { __sansDemo: true })) : null;
        const local = copieLocale();
        const fusion = distant ? App.fusionner(local, distant) : local;
        if (empreinte(fusion) !== empreinte(local)) appliquer(fusion);

        if (distant && empreinte(fusion) === empreinte(distant)) { // le serveur est déjà à jour
          config.version = lu.donnees.version;
          ecrireConfig();
          break;
        }
        const envoi = await requete("PUT", "/donnees", { base_version: lu.donnees.version, donnees: versServeur(fusion) });
        if (envoi.statut === 200) { config.version = envoi.donnees.version; ecrireConfig(); break; }
        if (envoi.statut === 409) continue; // un autre appareil a écrit entre-temps : on recommence
        if (envoi.statut === 401) { deconnecterLocalement("Session expirée : reconnecte-toi"); return; }
        throw new Error(messageErreur(envoi));
      }
      majEtat("ok", "Synchronisé à " + heure());
      if (manuel) App.Toast.afficher("Synchronisé ✅");
    } catch (erreur) {
      const horsLigne = erreur instanceof TypeError; // fetch échoue : pas de réseau ou serveur injoignable
      majEtat(horsLigne ? "hors-ligne" : "erreur", horsLigne ? "Serveur injoignable (hors ligne ?)" : erreur.message);
      if (manuel) App.Toast.afficher(horsLigne ? "Serveur injoignable" : erreur.message);
    } finally {
      enCours = false;
      if (encore) { encore = false; planifier(1500); }
    }
  }

  function planifier(delai) {
    if (!config.token || !config.auto) return;
    clearTimeout(minuteur);
    minuteur = setTimeout(() => synchroniser(false), delai);
  }

  function deconnecterLocalement(message) {
    config.token = "";
    config.nom = "";
    config.version = 0;
    ecrireConfig();
    majEtat("deconnecte", message || "");
    if (message) App.Toast.afficher(message);
  }

  // À chaque sauvegarde locale, on synchronise 3 secondes après la dernière modification
  App.ecouteurs.push(() => { if (!applique) planifier(3000); });
  setInterval(() => { if (!document.hidden) planifier(100); }, 60000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) planifier(300); });
  window.addEventListener("online", () => planifier(300));


  /* ---------- Fenêtre de connexion ---------- */

  function ouvrir() {
    document.body.classList.remove("menu-ouvert");
    if (config.token) ouvrirConnecte();
    else ouvrirConnexion();
  }

  function ouvrirConnexion() {
    const url = App.el("input", { type: "url", value: config.url, placeholder: "ex. https://focusflow-sync.onrender.com (ou vide si même serveur)", autocomplete: "off", "aria-label": "Adresse du serveur" });
    const nom = App.el("input", { type: "text", placeholder: "ex. manou", autocomplete: "username", autocapitalize: "none", "aria-label": "Nom d'utilisateur" });
    const mdp = App.el("input", { type: "password", placeholder: "8 caractères minimum", autocomplete: "current-password", "aria-label": "Mot de passe" });
    const message = App.el("p", { class: "erreur-form", id: "sync-statut", role: "alert" });
    const infoTest = App.el("p", { class: "aide petit" });

    function verifierAdresse() {
      const adresse = url.value.trim();
      if (adresse && !/^https?:\/\//i.test(adresse)) { message.textContent = "L'adresse doit commencer par http:// ou https://"; return null; }
      if (adresse.startsWith("http://") && location.protocol === "https:" && !/^http:\/\/(localhost|127\.)/.test(adresse)) {
        message.textContent = "Cette appli est en https : le serveur doit l'être aussi.";
        return null;
      }
      return adresse;
    }

    async function testerServeur() {
      message.textContent = "";
      const adresse = verifierAdresse();
      if (adresse === null) return;
      config.url = adresse;
      infoTest.textContent = "⏳ Contact du serveur en cours… (peut prendre 20-30 s si Render sort de veille)";
      try {
        const r = await requete("GET", "/sante", null, false, 35000);
        if (r.statut === 200) {
          ecrireConfig();
          infoTest.textContent = "✅ Serveur en ligne et prêt !";
        } else {
          infoTest.textContent = "";
          message.textContent = "Le serveur a répondu avec le code " + r.statut + ".";
        }
      } catch (e) {
        infoTest.textContent = "";
        message.textContent = "Serveur injoignable. Vérifie l'URL ou lance main.py.";
      }
    }

    async function valider(chemin) {
      message.textContent = "";
      const adresse = verifierAdresse();
      if (adresse === null) return;
      config.url = adresse;
      infoTest.textContent = "⏳ Connexion au serveur…";
      try {
        const r = await requete("POST", chemin, { nom: nom.value.trim(), mot_de_passe: mdp.value }, false, 35000);
        infoTest.textContent = "";
        if (r.statut !== 200) { message.textContent = messageErreur(r); return; }
        config.token = r.donnees.token;
        config.nom = r.donnees.nom;
        config.version = 0;
        ecrireConfig();
        await premiereSynchro();
      } catch (erreur) {
        infoTest.textContent = "";
        message.textContent = "Serveur injoignable. Vérifie l'adresse et que le serveur FastAPI est lancé.";
      }
    }

    App.Feuille.ouvrir("Synchronisation", [
      App.el("p", { class: "aide" }, "Retrouve tes pages sur tous tes appareils (PC + téléphone en 4G) grâce au serveur FastAPI (main.py)."),
      App.el("div", { class: "champ-form" }, App.el("label", null, "Adresse du serveur (Render ou local)"), url),
      App.el("div", { class: "champ-form" }, App.el("label", null, "Nom d'utilisateur"), nom),
      App.el("div", { class: "champ-form" }, App.el("label", null, "Mot de passe"), mdp),
      infoTest,
      message,
      App.el("div", { class: "actions" },
        App.el("button", { type: "button", class: "btn-primaire", onclick: () => valider("/connexion") }, "Se connecter"),
        App.el("button", { type: "button", class: "btn-secondaire", onclick: () => valider("/inscription") }, "Créer un compte"),
        App.el("button", { type: "button", class: "btn-secondaire", onclick: testerServeur }, "Tester le serveur")),
    ]);
  }

  // Première connexion : on demande quoi faire si le serveur contient déjà des données
  async function premiereSynchro() {
    const lu = await requete("GET", "/donnees");
    if (lu.statut !== 200) { await synchroniser(true); ouvrirConnecte(); return; }
    if (!lu.donnees.donnees) { await synchroniser(true); ouvrirConnecte(); return; }

    const distant = App.normaliser(Object.assign({}, lu.donnees.donnees, { __sansDemo: true }));
    App.Feuille.ouvrir("Ce compte contient déjà des pages", [
      App.el("p", null, "Le serveur a " + distant.pages.length + " page" + (distant.pages.length > 1 ? "s" : "") + ". Que faire des pages de cet appareil ?"),
      App.el("div", { class: "actions colonne" },
        App.el("button", { type: "button", class: "btn-primaire", onclick: async () => { await synchroniser(true); ouvrirConnecte(); } }, "Fusionner les deux"),
        App.el("button", { type: "button", class: "btn-secondaire", onclick: async () => {
          App.appliquerDonnees(distant, { sansMaj: true });
          config.version = lu.donnees.version;
          ecrireConfig();
          majEtat("ok", "Synchronisé à " + heure());
          ouvrirConnecte();
        } }, "Utiliser celles du serveur (efface cet appareil)")),
    ]);
  }

  function ouvrirConnecte() {
    const auto = App.el("input", { type: "checkbox", checked: !!config.auto, onchange: () => { config.auto = auto.checked; ecrireConfig(); if (config.auto) planifier(300); } });
    const statut = App.el("p", { class: "aide", id: "sync-statut" }, etat.message);

    App.Feuille.ouvrir("Synchronisation", [
      App.el("p", null, "Connecté en tant que ", App.el("strong", null, config.nom), config.url ? " sur " + config.url : " (ce serveur)"),
      statut,
      App.el("label", { class: "case-form" }, auto, " Synchroniser automatiquement"),
      App.el("div", { class: "actions" },
        App.el("button", { type: "button", class: "btn-primaire", onclick: () => synchroniser(true) }, "Synchroniser maintenant"),
        App.el("button", { type: "button", class: "btn-secondaire", onclick: async () => {
          try { await requete("POST", "/deconnexion"); } catch (erreur) { /* hors ligne : on se déconnecte quand même ici */ }
          deconnecterLocalement("Déconnecté");
          App.Feuille.fermer();
        } }, "Se déconnecter")),
      App.el("p", { class: "aide petit" }, "Tes pages restent sur cet appareil après la déconnexion. Seul le lien avec le serveur est coupé."),
      App.el("details", { class: "zone-danger" },
        App.el("summary", null, "Supprimer mon compte"),
        App.el("p", { class: "aide" }, "Supprime le compte et les données du serveur. Les pages de cet appareil ne sont pas touchées."),
        App.el("button", { type: "button", class: "btn-danger", onclick: async () => {
          if (!(await App.Confirmer("Supprimer définitivement ton compte et tes données sur le serveur ?", "Supprimer"))) return;
          try {
            const r = await requete("DELETE", "/compte");
            if (r.statut !== 200) { App.Toast.afficher(messageErreur(r)); return; }
            deconnecterLocalement("Compte supprimé");
            App.Feuille.fermer();
          } catch (erreur) { App.Toast.afficher("Serveur injoignable"); }
        } }, "Supprimer mon compte")),
    ]);
  }

  majEtat(etat.code, "");
  if (config.token) setTimeout(() => synchroniser(false), 1200);

  return { synchroniser: synchroniser, ouvrir: ouvrir, appel: requete, jeton: () => config.token, adresse: () => base() || location.origin, connecte: () => !!config.token, infos: () => ({ connecte: !!config.token, nom: config.nom, etat: etat }) };
})();
