"use strict";

/* =====================================================
   push.js : rappels « push » (la notification arrive même appli fermée)
   Il faut : être connecté à un serveur (Synchronisation), une adresse https
   (ou localhost) et avoir autorisé les notifications.
   Le serveur envoie la notification à l'heure de la tâche (serveur/rappels.py).
   ===================================================== */

App.Push = (function () {
  const CLE = "focusflow-push";

  const disponible = () =>
    "serviceWorker" in navigator && "PushManager" in window && "Notification" in window &&
    (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1");

  const actif = () => { try { return localStorage.getItem(CLE) === "1"; } catch (e) { return false; } };
  const memoriser = (v) => { try { v ? localStorage.setItem(CLE, "1") : localStorage.removeItem(CLE); } catch (e) { /* ignoré */ } };

  // La clé publique du serveur arrive en base64url ; l'API veut des octets
  function enOctets(b64) {
    const rempli = (b64 + "=".repeat((4 - (b64.length % 4)) % 4)).replace(/-/g, "+").replace(/_/g, "/");
    const brut = atob(rempli);
    return Uint8Array.from(brut, (c) => c.charCodeAt(0));
  }

  async function enregistrer(abonnement) {
    const cles = abonnement.toJSON().keys || {};
    return App.Sync.appel("POST", "/push/abonner", {
      endpoint: abonnement.endpoint, keys: { p256dh: cles.p256dh, auth: cles.auth },
      decalage: new Date().getTimezoneOffset(),
    });
  }

  async function activer() {
    if (!App.Sync.connecte()) { App.Toast.afficher("Connecte d'abord la synchronisation (Paramètres)"); return false; }
    if (!disponible()) { App.Toast.afficher("Les rappels push demandent une adresse https (ou localhost)"); return false; }
    if (!(await App.Rappels.activer())) return false;           // demande la permission des notifications
    try {
      const reg = await navigator.serviceWorker.ready;
      const cle = await App.Sync.appel("GET", "/push/cle");
      if (cle.statut !== 200) { App.Toast.afficher((cle.donnees && cle.donnees.detail) || "Rappels push indisponibles sur ce serveur"); return false; }
      let abonnement = await reg.pushManager.getSubscription();
      if (!abonnement) abonnement = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: enOctets(cle.donnees.cle) });
      const r = await enregistrer(abonnement);
      if (r.statut !== 200) { App.Toast.afficher("Le serveur a refusé l'abonnement (" + r.statut + ")"); return false; }
      memoriser(true);
      App.Sync.synchroniser(false);                              // les tâches doivent être sur le serveur pour qu'il les rappelle
      App.Toast.afficher("Rappels push activés 🔔 (même appli fermée)");
      return true;
    } catch (erreur) {
      App.Toast.afficher("Impossible d'activer les rappels push sur cet appareil");
      return false;
    }
  }

  async function desactiver() {
    memoriser(false);
    try {
      const reg = await navigator.serviceWorker.ready;
      const abonnement = await reg.pushManager.getSubscription();
      if (abonnement) {
        await App.Sync.appel("POST", "/push/desabonner", { endpoint: abonnement.endpoint }).catch(() => {});
        await abonnement.unsubscribe();
      }
    } catch (erreur) { /* ignoré */ }
    App.Toast.afficher("Rappels push désactivés");
  }

  // Au démarrage : on met à jour le fuseau horaire (voyage, heure d'été) et on vérifie que l'abonnement existe encore
  async function entretenir() {
    if (!actif() || !disponible() || !App.Sync.connecte()) return;
    try {
      const reg = await navigator.serviceWorker.ready;
      const abonnement = await reg.pushManager.getSubscription();
      if (abonnement) await enregistrer(abonnement);
      else memoriser(false);
    } catch (erreur) { /* hors ligne : on réessaiera */ }
  }
  setTimeout(entretenir, 4000);

  return { disponible: disponible, actif: actif, activer: activer, desactiver: desactiver };
})();
