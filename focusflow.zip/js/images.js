"use strict";

/* =====================================================
   images.js : les blocs « Image »
   La photo est réduite (1280 px au plus, JPEG) puis rangée dans la page,
   pour que l'appli marche hors ligne et se synchronise comme le reste.
   ===================================================== */

// Réduit une image et renvoie ses données (« data URL »)
App.lireImage = function (fichier) {
  return new Promise((resolve, reject) => {
    if (!fichier || !/^image\//.test(fichier.type)) { reject(new Error("Ce fichier n'est pas une image")); return; }
    const url = URL.createObjectURL(fichier);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const LIMITE = 450000;   // ~330 Ko par image : on évite de remplir le stockage de l'appareil
      let resultat = "";
      for (const [cote, qualite] of [[1280, .82], [1100, .72], [900, .65], [720, .55], [560, .5]]) {
        const echelle = Math.min(1, cote / Math.max(img.naturalWidth, img.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.naturalWidth * echelle));
        canvas.height = Math.max(1, Math.round(img.naturalHeight * echelle));
        const c = canvas.getContext("2d");
        c.fillStyle = "#fff";                      // les fonds transparents deviennent blancs
        c.fillRect(0, 0, canvas.width, canvas.height);
        c.drawImage(img, 0, 0, canvas.width, canvas.height);
        resultat = canvas.toDataURL("image/jpeg", qualite);
        if (resultat.length <= LIMITE) break;
      }
      resolve(resultat);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Image illisible")); };
    img.src = url;
  });
};

// Ouvre le sélecteur de fichier pour le bloc image donné
App.choisirImage = function (id) {
  const bloc = App.page().blocs.find((b) => b.id === id);
  if (!bloc) return;
  const champ = document.createElement("input");
  champ.type = "file";
  champ.accept = "image/*";
  champ.hidden = true;
  champ.addEventListener("change", async () => {
    const fichier = champ.files && champ.files[0];
    champ.remove();
    if (!fichier) return;
    try {
      const dataUrl = await App.lireImage(fichier);
      bloc.src = App.ImagesDB ? await App.ImagesDB.enregistrer(dataUrl) : dataUrl;
      if (!bloc.texte) bloc.texte = "";
      App.afficherBlocs(id, "fin", id);
    } catch (erreur) {
      App.Toast.afficher("Impossible d'ajouter cette image : " + erreur.message);
    }
  });
  document.body.append(champ);
  champ.click();
};

// Télécharge l'image d'un bloc
App.telechargerImageBloc = async function (bloc) {
  const src = App.ImagesDB ? await App.ImagesDB.obtenir(bloc.src) : bloc.src;
  if (!src) return;
  const nom = ((bloc.texte || "image-focusflow").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase() || "image-focusflow") + ".jpg";
  const lien = App.el("a", { href: src, download: nom });
  document.body.append(lien);
  lien.click();
  lien.remove();
};

// Affiche l'image en grand avec actions rapides
App.agrandirImage = async function (bloc) {
  const src = App.ImagesDB ? await App.ImagesDB.obtenir(bloc.src) : bloc.src;
  if (!src) return;
  const img = App.el("img", { class: "image-grande", src: src, alt: bloc.texte || "Image" });
  const barre = App.el("div", { class: "actions", style: "margin-top:12px" },
    App.el("button", { type: "button", class: "btn-secondaire", onclick: () => { App.Feuille.fermer(); App.choisirImage(bloc.id); } }, "🖼 Changer l'image"),
    App.el("button", { type: "button", class: "btn-secondaire", onclick: () => App.telechargerImageBloc(bloc) }, "⬇️ Télécharger"));
  App.Feuille.ouvrir(bloc.texte || "Image", [img, barre], { large: true });
};
