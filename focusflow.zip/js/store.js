"use strict";

/* =====================================================
   store.js : les données de l'appli
   Une appli = plusieurs pages. Une page = une liste de blocs.
   ===================================================== */

// Espace de noms partagé par tous les fichiers
const App = {};

App.CLE = "gestionnaire-blocs-v2";   // même clé qu'avant : tes données restent
App.ANCIENNE_CLE = "gestionnaire-blocs-v1";

App.COULEURS_PAGE = ["violet", "bleu", "vert", "orange", "rose", "turquoise"];
App.COULEURS_BLOC = ["jaune", "vert", "bleu", "rose", "violet"];
App.ICONES = ["📝", "📚", "💡", "🎯", "🏠", "💼", "🎓", "🛒", "🎮", "🚀"];
App.REPETITIONS = { "": "Jamais", jour: "Chaque jour", semaine: "Chaque semaine", mois: "Chaque mois" };

// Tous les types de blocs disponibles (menu "/" et menu du bloc)
App.TYPES = {
  paragraphe: { nom: "Texte", icone: "¶", aide: "Du texte simple", cles: ["texte", "paragraphe", "text"], placeholder: "Écris, ou tape « / » pour les blocs" },
  titre: { nom: "Titre 1", icone: "H1", aide: "Un grand titre", cles: ["titre", "h1", "heading"], placeholder: "Titre 1" },
  sous_titre: { nom: "Titre 2", icone: "H2", aide: "Un titre de section", cles: ["titre", "sous", "h2"], placeholder: "Titre 2" },
  tache: { nom: "Tâche", icone: "☑", aide: "Avec une case à cocher", cles: ["tache", "todo", "cocher", "checkbox"], placeholder: "À faire…" },
  liste: { nom: "Liste à puces", icone: "•", aide: "Une liste simple", cles: ["liste", "puces", "bullet"], placeholder: "Élément de liste" },
  numerotee: { nom: "Liste numérotée", icone: "1.", aide: "Une liste ordonnée", cles: ["liste", "numero", "numerotee", "number"], placeholder: "Élément numéroté" },
  citation: { nom: "Citation", icone: "❝", aide: "Pour mettre une idée en avant", cles: ["citation", "quote"], placeholder: "Citation…" },
  image: { nom: "Image", icone: "🖼", aide: "Une photo ou une capture d'écran", cles: ["image", "photo", "img", "capture"], placeholder: "Ajouter une légende…" },
  separateur: { nom: "Séparateur", icone: "—", aide: "Une ligne de séparation", cles: ["separateur", "ligne", "divider", "hr"], placeholder: "" },
};

// Ces types gardent leur forme quand on appuie sur Entrée
App.TYPES_LISTE = ["tache", "liste", "numerotee"];


/* ---------- Dates (en heure locale, format AAAA-MM-JJ) ---------- */

App.iso = function (date) {
  const z = (n) => String(n).padStart(2, "0");
  return date.getFullYear() + "-" + z(date.getMonth() + 1) + "-" + z(date.getDate());
};
App.aujourdhui = function () { return App.iso(new Date()); };


/* ---------- Texte enrichi : on ne garde que gras, italique, etc. ---------- */

// Nettoie un morceau de HTML : seules quelques balises sûres sont conservées
App.assainir = function (html) {
  const modele = document.createElement("template"); // contenu inerte : rien ne s'exécute
  modele.innerHTML = html;
  const AUTORISES = { B: "b", STRONG: "b", I: "i", EM: "i", U: "u", S: "s", STRIKE: "s", DEL: "s", CODE: "code", A: "a" };

  function copier(source, destination) {
    source.childNodes.forEach((n) => {
      if (n.nodeType === 3) {
        destination.append(document.createTextNode(n.nodeValue));
      } else if (n.nodeType === 1) {
        const balise = AUTORISES[n.tagName];
        if (n.tagName === "BR" || n.tagName === "SCRIPT" || n.tagName === "STYLE") return;
        if (!balise) { copier(n, destination); return; }
        const el = document.createElement(balise);
        if (balise === "a") {
          const lien = n.getAttribute("href") || "";
          if (!/^(https?:|mailto:)/i.test(lien)) { copier(n, destination); return; }
          el.setAttribute("href", lien);
          el.setAttribute("target", "_blank");
          el.setAttribute("rel", "noopener noreferrer");
        }
        copier(n, el);
        destination.append(el);
      }
    });
  }
  const sortie = document.createElement("div");
  copier(modele.content, sortie);
  // Retire les balises de mise en forme vides éventuellement laissées après un découpage
  sortie.querySelectorAll("b,i,u,s,code,a").forEach((el) => {
    if (!el.textContent) el.remove();
  });
  return sortie.innerHTML;
};

App.nettoyerTag = function (tag) {
  return String(tag).toLowerCase().trim().replace(/^#/, "").replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_-]/gu, "").slice(0, 24);
};


/* ---------- Fabriques ---------- */

App.id = function () {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
};

App.nouveauBloc = function (type, texte) {
  const bloc = {
    id: App.id(), type: type || "paragraphe", texte: texte || "", html: "", niveau: 0, couleur: "",
    echeance: "", heure: "", tags: [], repete: "", replie: false, rappele: "",
    creeLe: Date.now(), faitLe: 0,
  };
  if (bloc.type === "tache") { bloc.fait = false; bloc.encours = false; }
  if (bloc.type === "image") bloc.src = "";
  return bloc;
};

App.nouvellePage = function (titre, couleur, icone) {
  return {
    id: App.id(),
    titre: titre || "",
    icone: icone || "📝",
    couleur: couleur || "violet",
    maj: Date.now(),
    blocs: [App.nouveauBloc("paragraphe")],
  };
};


/* ---------- Pages d'exemple (premier lancement) ---------- */

App.demo = function () {
  const aujourdhui = App.aujourdhui();
  const demain = new Date(); demain.setDate(demain.getDate() + 1);
  const b = (type, texte, extra) => Object.assign(App.nouveauBloc(type, texte), extra || {});

  const accueil = {
    id: App.id(), titre: "Bienvenue", icone: "👋", couleur: "violet", maj: Date.now(),
    blocs: [
      b("paragraphe", "Chaque ligne est un bloc. Appuie sur Entrée pour en créer un, ou tape « / » pour choisir son type."),
      b("sous_titre", "Essaie ces gestes"),
      b("tache", "Cocher cette tâche (regarde la barre de progression)"),
      b("tache", "Taper « / » pour changer le type d'un bloc"),
      b("tache", "Décaler un bloc avec Tab (ou le menu ⋮⋮)", { niveau: 1 }),
      b("tache", "Glisser un bloc avec les points ⋮⋮ à gauche"),
      b("tache", "Replier ce bloc avec la flèche à gauche", { replie: false }),
      b("tache", "Un détail caché dans le bloc replié", { niveau: 1 }),
      b("tache", "Écrire une tâche avec une date limite (bouton 📅)", { echeance: aujourdhui, tags: ["demo"] }),
      b("tache", "Une tâche qui se répète chaque semaine", { echeance: App.iso(demain), repete: "semaine", tags: ["demo"] }),
      b("citation", "Astuce : « - », « [] », « # », « > » et « 1. » en début de ligne créent des blocs. Sélectionne du texte pour le mettre en gras ou en italique."),
      b("separateur", ""),
      b("liste", "Tout est sauvegardé automatiquement sur ton appareil"),
      b("liste", "Ctrl + Z annule, et la corbeille garde 30 jours"),
    ],
  };

  const projets = {
    id: App.id(), titre: "Mes projets", icone: "🚀", couleur: "bleu", maj: Date.now(),
    blocs: [
      b("tache", "Finir mon gestionnaire de blocs", { fait: true }),
      b("tache", "Le publier sur GitHub Pages", { tags: ["projet"] }),
      b("tache", "L'installer sur mon téléphone", { tags: ["projet"] }),
    ],
  };

  return App.normaliser({ pages: [accueil, projets], courante: accueil.id });
};


/* ---------- Vérification des données (anciennes versions, import…) ---------- */

function normBloc(bloc) {
  bloc.id = bloc.id || App.id();
  if (!App.TYPES[bloc.type]) bloc.type = "paragraphe";
  bloc.texte = typeof bloc.texte === "string" ? bloc.texte : "";
  bloc.niveau = Math.max(0, Math.min(3, Number(bloc.niveau) || 0));
  if (!App.COULEURS_BLOC.includes(bloc.couleur)) bloc.couleur = "";
  if (bloc.type === "tache") {
    bloc.fait = !!bloc.fait;
    bloc.encours = !bloc.fait && bloc.encours === true;     // statut « en cours » (vue Tableau)
  } else { delete bloc.fait; delete bloc.encours; }
  bloc.creeLe = Number(bloc.creeLe) > 0 ? Number(bloc.creeLe) : 0;
  bloc.faitLe = bloc.fait && Number(bloc.faitLe) > 0 ? Number(bloc.faitLe) : 0;
  if (bloc.type === "image") {
    // l'image est stockée dans IndexedDB ("idb:...") ou en Data URL ; on refuse tout ce qui n'est pas valide
    const okData = typeof bloc.src === "string" && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(bloc.src);
    const okIdb = typeof bloc.src === "string" && /^idb:[A-Za-z0-9_-]+$/.test(bloc.src);
    bloc.src = (okData || okIdb) ? bloc.src : "";
  } else delete bloc.src;
  bloc.echeance = /^\d{4}-\d{2}-\d{2}$/.test(bloc.echeance) ? bloc.echeance : "";
  bloc.heure = /^\d{2}:\d{2}$/.test(bloc.heure) ? bloc.heure : "";
  bloc.tags = Array.isArray(bloc.tags) ? [...new Set(bloc.tags.map(App.nettoyerTag).filter(Boolean))].slice(0, 8) : [];
  bloc.repete = Object.prototype.hasOwnProperty.call(App.REPETITIONS, bloc.repete) ? bloc.repete : "";
  bloc.replie = !!bloc.replie;
  bloc.rappele = typeof bloc.rappele === "string" ? bloc.rappele : "";
  // Texte enrichi : on le garde seulement s'il correspond bien au texte brut
  let html = typeof bloc.html === "string" && bloc.html ? App.assainir(bloc.html) : "";
  if (html) {
    const essai = document.createElement("div");
    essai.innerHTML = html;
    if (essai.textContent.replace(/\u00a0/g, " ") !== bloc.texte.replace(/\u00a0/g, " ")) html = "";
  }
  bloc.html = html;
  return bloc;
}

function normPage(p) {
  p.id = p.id || App.id();
  p.titre = typeof p.titre === "string" ? p.titre : "";
  p.icone = p.icone || "📝";
  if (!App.COULEURS_PAGE.includes(p.couleur)) p.couleur = "violet";
  p.favori = p.favori === true;
  p.maj = Number(p.maj) || Date.now();
  if (!Array.isArray(p.blocs) || p.blocs.length === 0) p.blocs = [App.nouveauBloc("paragraphe")];
  p.blocs.forEach(normBloc);
  return p;
}

App.normaliser = function (etat) {
  etat = etat || {};
  const pages = (Array.isArray(etat.pages) ? etat.pages : []).filter((p) => p && typeof p === "object").map(normPage);
  const stats = { faits: {}, pomodoros: {} };
  ["faits", "pomodoros"].forEach((t) => {
    const source = etat.stats && etat.stats[t];
    if (source && typeof source === "object") {
      Object.keys(source).forEach((jour) => {
        if (/^\d{4}-\d{2}-\d{2}$/.test(jour) && Number(source[jour]) > 0) stats[t][jour] = Math.floor(Number(source[jour]));
      });
    }
  });
  const supprimees = {};
  if (etat.supprimees && typeof etat.supprimees === "object") {
    Object.keys(etat.supprimees).forEach((id) => { if (Number(etat.supprimees[id])) supprimees[id] = Number(etat.supprimees[id]); });
  }
  const corbeille = (Array.isArray(etat.corbeille) ? etat.corbeille : [])
    .filter((e) => e && e.id && (e.kind === "page" || e.kind === "bloc") && e.data)
    .map((e) => {
      if (e.kind === "page") e.data = normPage(e.data);
      else e.data = (Array.isArray(e.data) ? e.data : [e.data]).map(normBloc);
      e.date = Number(e.date) || Date.now();
      return e;
    });

  const reglages = Object.assign({ rappels: false, animations: true, palette: "neutre", police: "systeme", compact: false }, etat.reglages && typeof etat.reglages === "object" ? etat.reglages : {});
  reglages.rappels = !!reglages.rappels;
  if (!["neutre", "ardoise", "chaud", "noir"].includes(reglages.palette)) reglages.palette = "neutre";
  if (!["systeme", "arrondie", "serif", "mono"].includes(reglages.police)) reglages.police = "systeme";
  reglages.compact = reglages.compact === true;
  reglages.animations = reglages.animations !== false;

  if (pages.length === 0) {
    if (etat.__sansDemo) return { pages: [], courante: "", theme: "auto", corbeille, supprimees, stats, reglages };
    const d = App.demo();
    d.stats = stats; d.corbeille = corbeille; d.supprimees = supprimees; d.reglages = reglages;
    return d;
  }
  return {
    pages,
    courante: pages.some((p) => p.id === etat.courante) ? etat.courante : pages[0].id,
    theme: ["auto", "clair", "sombre"].includes(etat.theme) ? etat.theme : "auto",
    corbeille, supprimees, stats, reglages,
  };
};


/* ---------- Fusion de deux versions (import, synchronisation) ----------
   Pour chaque page, la plus récemment modifiée gagne.
   Une page supprimée plus récemment que sa dernière modification reste supprimée. */

App.fusionner = function (local, distant) {
  const pages = new Map();
  local.pages.forEach((p) => pages.set(p.id, p));
  distant.pages.forEach((p) => {
    const l = pages.get(p.id);
    if (!l || p.maj > l.maj) pages.set(p.id, p);
  });

  const supprimees = Object.assign({}, distant.supprimees);
  Object.keys(local.supprimees).forEach((id) => { supprimees[id] = Math.max(supprimees[id] || 0, local.supprimees[id]); });
  [...pages.keys()].forEach((id) => {
    if (!supprimees[id]) return;
    if (supprimees[id] > pages.get(id).maj) pages.delete(id);
    else delete supprimees[id]; // restaurée depuis : on oublie la suppression
  });

  const stats = { faits: {}, pomodoros: {} };
  ["faits", "pomodoros"].forEach((t) => {
    [local.stats[t], distant.stats[t]].forEach((s) => {
      Object.keys(s).forEach((j) => { stats[t][j] = Math.max(stats[t][j] || 0, s[j]); });
    });
  });

  const vus = new Set();
  const corbeille = [...local.corbeille, ...distant.corbeille]
    .filter((e) => (vus.has(e.id) ? false : vus.add(e.id)))
    .sort((a, b) => b.date - a.date)
    .slice(0, 100);

  const liste = [...pages.values()];
  return {
    pages: liste.length ? liste : [App.nouvellePage()],
    courante: local.courante, theme: local.theme, reglages: local.reglages,
    corbeille, supprimees, stats,
  };
};


/* ---------- Chargement et sauvegarde ---------- */

function charger() {
  try {
    const brut = localStorage.getItem(App.CLE);
    if (brut) return App.normaliser(JSON.parse(brut));

    // Migration : on récupère la page de la version 1 si elle existe
    const ancien = localStorage.getItem(App.ANCIENNE_CLE);
    if (ancien) {
      const v1 = JSON.parse(ancien);
      return App.normaliser({ pages: [{ titre: v1.titre, blocs: v1.blocs }] });
    }
  } catch (erreur) {
    // données absentes ou abîmées : on repart des pages d'exemple
  }
  return App.demo();
}

/* ---------- Stockage des images dans IndexedDB ----------
   Évite de saturer le quota de localStorage (5-10 Mo) avec des photos Base64. */
App.ImagesDB = (function () {
  const NOM_DB = "focusflow-medias";
  const STORE = "images";
  const cache = new Map();
  let dbPromise = null;
  let initPromise = null;

  const estRef = (src) => typeof src === "string" && /^idb:[A-Za-z0-9_-]+$/.test(src);

  function ouvrir() {
    if (dbPromise) return dbPromise;
    if (!("indexedDB" in window)) return Promise.resolve(null);
    dbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(NOM_DB, 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
        req.onblocked = () => resolve(null);
      } catch (e) {
        resolve(null);
      }
    });
    return dbPromise;
  }

  async function enregistrer(dataUrl) {
    if (!dataUrl || estRef(dataUrl)) return dataUrl || "";
    const ref = "idb:" + App.id();
    cache.set(ref, dataUrl);
    const db = await ouvrir();
    if (!db) return dataUrl; // repli en Data URL si IndexedDB indisponible
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).put({ id: ref, data: dataUrl, maj: Date.now() });
        tx.oncomplete = () => resolve(ref);
        tx.onerror = () => resolve(dataUrl);
      } catch (e) {
        resolve(dataUrl);
      }
    });
  }

  async function obtenir(src) {
    if (!src) return "";
    if (!estRef(src)) return src;
    if (cache.has(src)) return cache.get(src);
    const db = await ouvrir();
    if (!db) return "";
    return new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE, "readonly");
        const req = tx.objectStore(STORE).get(src);
        req.onsuccess = () => {
          const data = req.result && req.result.data ? req.result.data : "";
          if (data) cache.set(src, data);
          resolve(data);
        };
        req.onerror = () => resolve("");
      } catch (e) {
        resolve("");
      }
    });
  }

  function obtenirSync(src) {
    if (!src) return "";
    if (!estRef(src)) return src;
    return cache.get(src) || "";
  }

  function actualiserDom() {
    document.querySelectorAll("img[data-idb-ref]").forEach((img) => {
      const ref = img.dataset.idbRef;
      const data = cache.get(ref);
      if (data && img.src !== data) img.src = data;
    });
  }

  async function prechargerTout() {
    const db = await ouvrir();
    if (!db) return;
    await new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE, "readonly");
        const req = tx.objectStore(STORE).getAll();
        req.onsuccess = () => {
          (req.result || []).forEach((item) => {
            if (item && item.id && item.data) cache.set(item.id, item.data);
          });
          actualiserDom();
          resolve();
        };
        req.onerror = () => resolve();
      } catch (e) {
        resolve();
      }
    });
  }

  function listerBlocsEtat(etat) {
    const liste = [];
    if (!etat) return liste;
    (etat.pages || []).forEach((p) => (p.blocs || []).forEach((b) => liste.push(b)));
    (etat.corbeille || []).forEach((e) => {
      if (e.kind === "page" && e.data && Array.isArray(e.data.blocs)) e.data.blocs.forEach((b) => liste.push(b));
      else if (e.kind === "bloc" && Array.isArray(e.data)) e.data.forEach((b) => liste.push(b));
    });
    return liste;
  }

  async function migrerEtat(etat, preserverMaj) {
    if (!etat) return false;
    let modifie = false;
    for (const b of listerBlocsEtat(etat)) {
      if (b && b.type === "image" && typeof b.src === "string" && b.src.startsWith("data:image/")) {
        const ref = await enregistrer(b.src);
        if (ref !== b.src) {
          b.src = ref;
          modifie = true;
        }
      }
    }
    if (modifie && etat === App.etat) {
      const ancienSansMaj = App._sansMaj;
      if (preserverMaj) App._sansMaj = true;
      App.sauver();
      if (preserverMaj) {
        App._sansMaj = ancienSansMaj;
        App.initEmpreintes();
      }
      actualiserDom();
    }
    return modifie;
  }

  async function nettoyerOrphelines() {
    const db = await ouvrir();
    if (!db || !App.etat || !Array.isArray(App.etat.pages) || App.etat.pages.length === 0) return;
    const actives = new Set();
    listerBlocsEtat(App.etat).forEach((b) => {
      if (b && b.type === "image" && estRef(b.src)) actives.add(b.src);
    });
    await new Promise((resolve) => {
      try {
        const tx = db.transaction(STORE, "readwrite");
        const store = tx.objectStore(STORE);
        const req = store.getAllKeys();
        req.onsuccess = () => {
          (req.result || []).forEach((cle) => {
            if (!actives.has(cle)) {
              store.delete(cle);
              cache.delete(cle);
            }
          });
        };
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch (e) {
        resolve();
      }
    });
  }

  function initialiser() {
    if (initPromise) return initPromise;
    initPromise = (async () => {
      await prechargerTout();
      await migrerEtat(App.etat, true);
      await nettoyerOrphelines();
    })();
    return initPromise;
  }

  return {
    estRef,
    enregistrer,
    obtenir,
    obtenirSync,
    migrerEtat,
    initialiser,
    pret: () => initialiser(),
  };
})();

App.etat = charger();
App.ImagesDB.initialiser();
App.ecouteurs = [];      // fonctions appelées à chaque sauvegarde (historique, synchronisation…)
App._empreintes = {};
App._sansMaj = false;    // vrai pendant qu'on applique des données venues d'ailleurs

App.empreinte = function (p) { return JSON.stringify([p.titre, p.icone, p.couleur, p.favori === true, p.blocs]); };
App.initEmpreintes = function () {
  App._empreintes = {};
  App.etat.pages.forEach((p) => { App._empreintes[p.id] = App.empreinte(p); });
};
App.initEmpreintes();

App.sauver = function () {
  // Une page dont le contenu a changé reçoit une nouvelle date de modification
  App.etat.pages.forEach((p) => {
    const e = App.empreinte(p);
    if (App._empreintes[p.id] !== e) {
      App._empreintes[p.id] = e;
      if (!App._sansMaj) p.maj = Date.now();
    }
  });
  try {
    localStorage.setItem(App.CLE, JSON.stringify(App.etat));
  } catch (erreur) {
    // stockage indisponible (navigation privée, par exemple) : on ignore.
    // Mais s'il est simplement plein (trop d'images), on prévient pour éviter de perdre du travail.
    if (erreur && (erreur.name === "QuotaExceededError" || erreur.code === 22) && App.Toast && !App._avertiPlein) {
      App._avertiPlein = true;
      setTimeout(() => { App._avertiPlein = false; }, 15000);
      App.Toast.afficher("⚠️ Stockage plein : supprime des images ou exporte une sauvegarde");
    }
  }
  App.ecouteurs.forEach((f) => { try { f(); } catch (erreur) { /* un écouteur ne doit jamais casser la sauvegarde */ } });
};

App.page = function () {
  return App.etat.pages.find((p) => p.id === App.etat.courante) || App.etat.pages[0];
};

// Compte une action dans les statistiques du jour (delta = +1 ou -1)
App.compter = function (type, delta) {
  const stats = App.etat.stats[type];
  const jour = App.aujourdhui();
  const valeur = Math.max(0, (stats[jour] || 0) + delta);
  if (valeur) stats[jour] = valeur;
  else delete stats[jour];
};

// La corbeille garde les éléments 30 jours
App.purgerCorbeille = function () {
  const limite = Date.now() - 30 * 864e5;
  App.etat.corbeille = App.etat.corbeille.filter((e) => e.date > limite).slice(0, 100);
};
App.purgerCorbeille();
