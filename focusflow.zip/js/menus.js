"use strict";

/* =====================================================
   menus.js : le menu des types (« / ») et le menu d'un bloc (⋮⋮)
   ===================================================== */

/* ---------- Menu des types de blocs ---------- */

App.MenuTypes = (function () {
  const el = document.getElementById("menu-types");
  const etat = { ouvert: false, origine: "slash", index: 0, items: [], rappel: null, filtre: "" };

  function construire() {
    const f = App.simplifier(etat.filtre);
    etat.items = Object.keys(App.TYPES)
      .map((cle) => Object.assign({ cle: cle }, App.TYPES[cle]))
      .filter((t) => !f || App.simplifier(t.nom + " " + t.cles.join(" ")).includes(f));

    if (etat.index >= etat.items.length) etat.index = 0;

    el.replaceChildren(...etat.items.map((t, i) => {
      const bouton = document.createElement("button");
      bouton.type = "button";
      bouton.className = "menu-item" + (i === etat.index ? " actif" : "");
      bouton.innerHTML = '<span class="menu-icone"></span><span class="menu-texte"><strong></strong><small></small></span>';
      bouton.querySelector(".menu-icone").textContent = t.icone;
      bouton.querySelector("strong").textContent = t.nom;
      bouton.querySelector("small").textContent = t.aide;
      // Garde le curseur dans le bloc pendant qu'on choisit
      bouton.addEventListener("mousedown", (e) => e.preventDefault());
      bouton.addEventListener("click", () => choisir(i));
      return bouton;
    }));
  }

  function positionner(ancre) {
    if (window.innerWidth <= 640) { // petit écran : le CSS en fait une feuille en bas
      el.style.left = "";
      el.style.top = "";
      return;
    }
    const r = ancre.getBoundingClientRect();
    const h = el.offsetHeight;
    let haut = r.bottom + 6;
    if (haut + h > window.innerHeight - 10) haut = Math.max(10, r.top - h - 6);
    const gauche = Math.max(10, Math.min(r.left + 36, window.innerWidth - el.offsetWidth - 10));
    el.style.top = haut + "px";
    el.style.left = gauche + "px";
  }

  function ouvrir(ancre, filtre, rappel, origine) {
    const nouvelle = !etat.ouvert || etat.origine !== (origine || "slash");
    if (nouvelle || (filtre || "") !== etat.filtre) etat.index = 0;
    etat.origine = origine || "slash";
    etat.rappel = rappel;
    etat.filtre = filtre || "";
    construire();
    if (etat.items.length === 0) { fermer(); return; }
    el.hidden = false;
    etat.ouvert = true;
    positionner(ancre);
  }

  function fermer() {
    el.hidden = true;
    etat.ouvert = false;
  }

  function bouger(delta) {
    const n = etat.items.length;
    if (!n) return;
    etat.index = (etat.index + delta + n) % n;
    [...el.children].forEach((b, i) => b.classList.toggle("actif", i === etat.index));
    const actif = el.children[etat.index];
    if (actif && actif.scrollIntoView) actif.scrollIntoView({ block: "nearest" });
  }

  function choisir(i) {
    const type = etat.items[i];
    const rappel = etat.rappel;
    fermer();
    if (type && rappel) rappel(type.cle);
  }

  // Clavier pour les menus ouverts depuis un bouton (le menu "/" est géré par l'éditeur)
  document.addEventListener("keydown", (e) => {
    if (!etat.ouvert || etat.origine === "slash") return;
    if (e.key === "ArrowDown") { e.preventDefault(); bouger(1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); bouger(-1); }
    else if (e.key === "Enter") { e.preventDefault(); choisir(etat.index); }
    else if (e.key === "Escape") { fermer(); }
  });

  // Un toucher en dehors du menu le ferme
  document.addEventListener("pointerdown", (e) => {
    if (etat.ouvert && !el.contains(e.target) && e.target.id !== "plus-types") fermer();
  });

  return {
    ouvrir: ouvrir,
    fermer: fermer,
    bouger: bouger,
    valider: () => choisir(etat.index),
    ouvert: () => etat.ouvert,
    origine: () => etat.origine,
  };
})();


/* ---------- Menu d'un bloc (ouvert par la poignée ⋮⋮) ---------- */

App.MenuBloc = (function () {
  const el = document.getElementById("menu-bloc");

  function fermer() {
    el.hidden = true;
  }

  function item(icone, texte, action, options) {
    options = options || {};
    const bouton = document.createElement("button");
    bouton.type = "button";
    bouton.className = "menu-item" + (options.danger ? " danger" : "");
    bouton.disabled = !!options.desactive;
    bouton.innerHTML = '<span class="menu-icone"></span><span class="menu-texte"><strong></strong></span>';
    bouton.querySelector(".menu-icone").textContent = icone;
    bouton.querySelector("strong").textContent = texte;
    bouton.addEventListener("click", () => {
      fermer();
      action();
    });
    return bouton;
  }

  function ouvrir(id, ancre) {
    const bl = App.page().blocs;
    const i = bl.findIndex((b) => b.id === id);
    const bloc = bl[i];
    if (!bloc) return;
    App.MenuTypes.fermer();

    const maxNiveau = i === 0 ? 0 : Math.min(3, bl[i - 1].niveau + 1);
    const aEnfants = !!bl[i + 1] && bl[i + 1].niveau > bloc.niveau;

    // Rangée de couleurs
    const couleurs = document.createElement("div");
    couleurs.className = "menu-couleurs";
    ["", ...App.COULEURS_BLOC].forEach((c) => {
      const p = document.createElement("button");
      p.type = "button";
      p.className = "pastille-bloc" + ((bloc.couleur || "") === c ? " choisie" : "");
      p.dataset.c = c || "aucune";
      p.title = c ? "Couleur " + c : "Sans couleur";
      p.setAttribute("aria-label", p.title);
      p.addEventListener("click", () => { fermer(); App.colorer(id, c); });
      couleurs.append(p);
    });

    el.replaceChildren(
      item("↑", "Monter", () => App.deplacer(id, -1), { desactive: i === 0 }),
      item("↓", "Descendre", () => App.deplacer(id, 1), { desactive: i === bl.length - 1 }),
      item("→", "Décaler à droite", () => App.decaler(id, 1), { desactive: bloc.niveau >= maxNiveau }),
      item("←", "Décaler à gauche", () => App.decaler(id, -1), { desactive: bloc.niveau === 0 }),
      item("⇄", "Transformer en…", () => {
        App.MenuTypes.ouvrir(ancre, "", (type) => App.convertir(id, type), "convertir");
      }),
      bloc.type === "tache" ? item("📅", "Date, rappel, tags…", () => App.ouvrirDetails(id)) : "",
      bloc.type === "image" ? item("🖼", bloc.src ? "Changer l'image" : "Choisir une image", () => App.choisirImage(id)) : "",
      bloc.type === "image" && bloc.src ? item("⬇️", "Télécharger l'image", () => App.telechargerImageBloc(bloc)) : "",
      aEnfants ? item("▾", bloc.replie ? "Déplier" : "Replier", () => App.basculerRepli(id)) : "",
      item("⧉", "Dupliquer", () => App.dupliquer(id)),
      couleurs,
      item("🗑", "Supprimer", () => App.supprimerBloc(id), { danger: true })
    );

    el.hidden = false;
    if (window.innerWidth <= 640) {
      el.style.left = "";
      el.style.top = "";
    } else {
      const r = ancre.getBoundingClientRect();
      const h = el.offsetHeight;
      let haut = r.top;
      if (haut + h > window.innerHeight - 10) haut = Math.max(10, window.innerHeight - h - 10);
      el.style.top = haut + "px";
      el.style.left = r.right + 8 + "px";
    }
  }

  document.addEventListener("pointerdown", (e) => {
    if (!el.hidden && !el.contains(e.target) && !e.target.closest(".poignee")) fermer();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") fermer();
  });

  return { ouvrir: ouvrir, fermer: fermer };
})();
