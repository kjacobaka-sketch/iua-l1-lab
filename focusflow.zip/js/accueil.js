"use strict";

/* =====================================================
   accueil.js : écran de bienvenue (une seule fois) et raccourcis de l'écran d'accueil
   Les raccourcis (appui long sur l'icône) ouvrent l'appli avec ?action=…
   ===================================================== */

App.Accueil = (function () {
  const CLE = "focusflow-accueil-vu";

  const lu = () => { try { return localStorage.getItem(CLE) === "1"; } catch (e) { return false; } };
  const ecrire = () => { try { localStorage.setItem(CLE, "1"); } catch (e) { /* tant pis : on reverra l'accueil */ } };

  const ASTUCES = [
    ["⌨️", "Tape « / » dans un bloc", "pour choisir son type : titre, tâche, liste, image…"],
    ["📅", "Ajoute une date aux tâches", "et retrouve-les dans Aujourd'hui, le Tableau et le Calendrier"],
    ["↳", "Décale une tâche sous une autre", "pour en faire une sous-tâche, avec sa progression"],
    ["⋯", "Le menu Options de chaque page", "couleur, favori, partage, copie…"],
    ["⚙️", "Paramètres", "thème, palettes, sauvegarde, synchronisation, rappels"],
    ["🔎", "Ctrl + K", "cherche dans tous tes blocs de toutes tes pages"],
  ];

  function ouvrir() {
    App.Feuille.ouvrir("Bienvenue sur FocusFlow", [
      App.el("p", { class: "aide" }, "Tes tâches et tes idées dans de simples blocs. Quelques repères pour bien démarrer :"),
      App.el("ul", { class: "astuces" }, ASTUCES.map(([icone, titre, texte]) =>
        App.el("li", null,
          App.el("span", { class: "ligne-icone", "aria-hidden": "true" }, icone),
          App.el("span", { class: "ligne-texte" }, App.el("strong", null, titre), App.el("small", null, texte))))),
      App.el("button", { type: "button", id: "accueil-ok", class: "btn-primaire", onclick: () => App.Feuille.fermer() }, "C'est parti"),
    ], { surFermeture: ecrire });
  }

  function raccourci() {
    let action = null;
    try { action = new URLSearchParams(location.search).get("action"); } catch (e) { return false; }
    if (!action) return false;
    try { history.replaceState(null, "", location.pathname); } catch (e) { /* pas grave */ }

    if (action === "aujourdhui") {
      App.Vues.ouvrir({ type: "aujourdhui" });
    } else if (action === "tache") {
      const page = App.page();
      const bloc = App.nouveauBloc("tache");
      page.blocs.push(bloc);
      App.afficherBlocs(bloc.id, "fin", bloc.id);
    } else {
      return false;
    }
    return true;
  }

  // Après le démarrage de l'appli (app.js s'exécute juste après ce fichier)
  setTimeout(() => {
    const parRaccourci = raccourci();
    if (!parRaccourci && !lu()) setTimeout(ouvrir, 500);
  }, 0);

  return { ouvrir: ouvrir };
})();
