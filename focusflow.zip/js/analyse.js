"use strict";

/* =====================================================
   analyse.js : l'écran « Mon analyse »
   Les chiffres viennent du serveur, qui les calcule en SQL (serveur/analyse.py).
   Il faut être connecté à la synchronisation.
   ===================================================== */

App.Analyse = (function () {
  const nombre = (n) => String(n == null ? 0 : n);

  function kpi(valeur, libelle, classe) {
    return App.el("div", { class: "kpi" + (classe ? " " + classe : "") }, App.el("strong", null, valeur), App.el("small", null, libelle));
  }

  // Un petit diagramme en barres, fait en HTML/CSS
  function barres(titre, donnees, cle, etiquette, unite) {
    const max = Math.max(1, ...donnees.map((d) => d[cle]));
    return App.el("section", { class: "param-section" },
      App.el("h3", { class: "titre-section" }, titre),
      App.el("div", { class: "hist", role: "img", "aria-label": titre },
        donnees.map((d) => App.el("div", { class: "hist-col", title: etiquette(d) + " : " + d[cle] + (unite || "") },
          App.el("span", { class: "hist-val" }, d[cle] ? String(d[cle]) : ""),
          App.el("span", { class: "hist-barre" + (d[cle] ? "" : " zero"), style: "height:" + Math.round((100 * d[cle]) / max) + "%" }),
          App.el("span", { class: "hist-etiq" }, etiquette(d))))));
  }

  function rendu(r) {
    const g = r.global;
    if (!g.total) {
      return [App.el("p", { class: "aide" }, "Aucune tâche sur le serveur pour l'instant. Ajoute des tâches puis reviens ici : l'analyse se met à jour à chaque synchronisation.")];
    }
    const jours = r.derniers_jours.map((j) => ({ etiq: j.jour.slice(8) + "/" + j.jour.slice(5, 7), faits: j.faits }));
    return [
      App.el("div", { class: "kpis" },
        kpi(g.taux_reussite + " %", "de tâches terminées"),
        kpi(nombre(g.faites) + " / " + nombre(g.total), "terminées / total"),
        kpi(nombre(g.en_retard), "en retard", g.en_retard ? "alerte" : ""),
        kpi(r.delai_moyen_heures == null ? "—" : r.delai_moyen_heures < 48 ? r.delai_moyen_heures + " h" : Math.round(r.delai_moyen_heures / 24) + " j", "délai moyen avant de finir")),
      jours.length ? barres("Tâches terminées, derniers jours", jours, "faits", (d) => d.etiq) : null,
      barres("Quel jour de la semaine je termine le plus ?", r.par_jour_semaine, "faites", (d) => d.jour),
      r.par_page.length ? App.el("section", { class: "param-section" },
        App.el("h3", { class: "titre-section" }, "Par page"),
        r.par_page.map((p) => App.el("div", { class: "ligne-progression" },
          App.el("span", { class: "lp-nom" }, p.page),
          App.el("span", { class: "mini-barre" }, App.el("i", { style: "width:" + p.taux + "%" })),
          App.el("small", null, p.faites + "/" + p.total)))) : null,
      r.tags.length ? App.el("section", { class: "param-section" },
        App.el("h3", { class: "titre-section" }, "Tags les plus utilisés"),
        App.el("div", { class: "meta" }, r.tags.map((t) => App.el("span", { class: "chip" }, "#" + t.tag + " · " + t.nombre)))) : null,
      App.el("p", { class: "aide petit" }, "Calculé par le serveur avec des requêtes SQL sur tes " + g.total + " tâches. Pour aller plus loin : export CSV ou script pandas (dossier « analyse » du projet)."),
      App.el("div", { class: "actions" },
        App.el("button", { type: "button", class: "btn-secondaire", onclick: telechargerCsv }, "⬇️ Exporter en CSV (serveur)")),
    ];
  }

  async function telechargerCsv() {
    try {
      const reponse = await fetch(App.Sync.adresse() + "/api/export.csv", { headers: { Authorization: "Bearer " + jeton() } });
      if (!reponse.ok) throw new Error(String(reponse.status));
      App.telecharger("focusflow-taches-serveur.csv", await reponse.text(), "text/csv;charset=utf-8");
    } catch (erreur) { App.Toast.afficher("Export impossible pour l'instant"); }
  }
  // Le jeton reste dans le module de synchronisation : on passe par son interface
  const jeton = () => App.Sync.jeton();

  async function ouvrir() {
    if (!App.Sync.connecte()) {
      App.Toast.afficher("Connecte d'abord la synchronisation (Paramètres)");
      return;
    }
    App.Feuille.ouvrir("Mon analyse", [App.el("p", { class: "aide" }, "⏳ Calcul en cours…")], { large: true });
    try {
      await App.Sync.synchroniser(false);          // des chiffres à jour
      const r = await App.Sync.appel("GET", "/analyse");
      if (r.statut !== 200) throw new Error((r.donnees && r.donnees.detail) || "Erreur " + r.statut);
      App.Feuille.ouvrir("Mon analyse", rendu(r.donnees), { large: true });
    } catch (erreur) {
      App.Feuille.ouvrir("Mon analyse", [App.el("p", { class: "erreur-form" }, erreur instanceof TypeError ? "Serveur injoignable (hors ligne ?)" : erreur.message)]);
    }
  }

  return { ouvrir: ouvrir };
})();
