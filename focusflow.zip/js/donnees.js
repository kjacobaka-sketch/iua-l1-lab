"use strict";

/* =====================================================
   donnees.js : sauvegarde (export/import), CSV, corbeille, statistiques
   ===================================================== */

(function () {
  const $ = (id) => document.getElementById(id);
  const pluriel = (n, mot) => n + " " + mot + (n > 1 ? "s" : "");

  function resoudreBlocsImages(blocs) {
    return (blocs || []).map((b) => (b && b.type === "image" && App.ImagesDB && App.ImagesDB.estRef(b.src)
      ? Object.assign({}, b, { src: App.ImagesDB.obtenirSync(b.src) })
      : b));
  }

  // Ce qui est sauvegardé ou envoyé au serveur (pas le thème ni les réglages de cet appareil)
  App.donneesExportables = function () {
    const pages = App.etat.pages.map((p) => Object.assign({}, p, { blocs: resoudreBlocsImages(p.blocs) }));
    const corbeille = App.etat.corbeille.map((e) => {
      if (e.kind === "page" && e.data && Array.isArray(e.data.blocs)) {
        return Object.assign({}, e, { data: Object.assign({}, e.data, { blocs: resoudreBlocsImages(e.data.blocs) }) });
      }
      if (e.kind === "bloc" && Array.isArray(e.data)) {
        return Object.assign({}, e, { data: resoudreBlocsImages(e.data) });
      }
      return e;
    });
    return {
      format: "mes-blocs", version: 3,
      pages: pages, corbeille: corbeille,
      supprimees: App.etat.supprimees, stats: App.etat.stats,
    };
  };

  // Remplace (ou fusionne) les données de l'appli puis réaffiche
  App.appliquerDonnees = function (n, options) {
    options = options || {};
    const idsAvant = App.etat.pages.map((p) => p.id);
    App._sansMaj = !!options.sansMaj;
    App.etat.pages = n.pages;
    App.etat.corbeille = n.corbeille;
    App.etat.supprimees = n.supprimees;
    App.etat.stats = n.stats;
    if (options.remplacer) {
      const maintenant = Date.now();
      n.pages.forEach((p) => { p.maj = maintenant; delete App.etat.supprimees[p.id]; });
      idsAvant.forEach((id) => { if (!n.pages.some((p) => p.id === id)) App.etat.supprimees[id] = maintenant; });
    }
    if (!App.etat.pages.some((p) => p.id === App.etat.courante)) App.etat.courante = App.etat.pages[0].id;
    App.sauver();
    App._sansMaj = false;
    if (options.sansMaj) App.initEmpreintes();
    if (App.ImagesDB) App.ImagesDB.migrerEtat(App.etat, true);
    if (options.afficher !== false) App.ouvrirPage(App.etat.courante, false);
  };


  /* ---------- Export / import ---------- */

  async function exporter() {
    App.Feuille.fermer();
    if (App.ImagesDB) await App.ImagesDB.pret();
    const jour = App.aujourdhui();
    App.telecharger("focusflow-" + jour + ".json", JSON.stringify(App.donneesExportables(), null, 2), "application/json");
    App.Toast.afficher("Sauvegarde téléchargée 💾");
  }

  function importer(fichier) {
    if (!fichier) return;
    if (fichier.size > 10 * 1024 * 1024) { App.Toast.afficher("Fichier trop gros (10 Mo maximum)"); return; }
    const lecteur = new FileReader();
    lecteur.onerror = () => App.Toast.afficher("Impossible de lire ce fichier");
    lecteur.onload = () => {
      let brut;
      try { brut = JSON.parse(lecteur.result); } catch (erreur) { brut = null; }
      if (!brut || typeof brut !== "object" || !Array.isArray(brut.pages)) {
        App.Toast.afficher("Ce fichier n'est pas une sauvegarde de FocusFlow");
        return;
      }
      const importe = App.normaliser(Object.assign({}, brut, { __sansDemo: true }));
      if (importe.pages.length === 0) { App.Toast.afficher("Cette sauvegarde ne contient aucune page"); return; }
      const nbTaches = importe.pages.reduce((n, p) => n + p.blocs.filter((b) => b.type === "tache").length, 0);

      App.Feuille.ouvrir("Importer une sauvegarde", [
        App.el("p", null, "Cette sauvegarde contient " + pluriel(importe.pages.length, "page") + " et " + pluriel(nbTaches, "tâche") + "."),
        App.el("p", { class: "aide" }, "Fusionner garde tes pages actuelles et y ajoute celles du fichier (la version la plus récente de chaque page l'emporte). Remplacer efface tout ce qui est sur cet appareil."),
        App.el("div", { class: "actions" },
          App.el("button", { type: "button", class: "btn-primaire", onclick: () => {
            App.appliquerDonnees(App.fusionner(App.normaliser(JSON.parse(JSON.stringify(App.donneesExportables()))), importe));
            App.Feuille.fermer();
            App.Toast.afficher("Sauvegarde fusionnée ✅");
          } }, "Fusionner"),
          App.el("button", { type: "button", class: "btn-danger", onclick: () => {
            App.appliquerDonnees(importe, { remplacer: true });
            App.Feuille.fermer();
            App.Toast.afficher("Données remplacées ✅");
          } }, "Remplacer tout"),
          App.el("button", { type: "button", class: "btn-secondaire", onclick: () => App.Feuille.fermer() }, "Annuler")),
      ]);
    };
    lecteur.readAsText(fichier);
  }


  /* ---------- CSV (pour Excel, pandas…) ---------- */

  function cellule(valeur, texteLibre) {
    let s = String(valeur == null ? "" : valeur);
    // Évite qu'Excel prenne un texte pour une formule
    if (texteLibre && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }
  const ligneCsv = (cases) => cases.join(";");

  function exporterTaches() {
    App.Feuille.fermer();
    const lignes = [ligneCsv(["page", "tache", "fait", "echeance", "heure", "repetition", "tags", "niveau"])];
    App.toutesLesTaches().forEach(({ page, bloc }) => {
      lignes.push(ligneCsv([
        cellule(page.titre || "Sans titre", true), cellule(bloc.texte, true), bloc.fait ? 1 : 0,
        cellule(bloc.echeance), cellule(bloc.heure), cellule(bloc.repete), cellule(bloc.tags.join(" "), true), bloc.niveau,
      ]));
    });
    App.telecharger("mes-taches-" + App.aujourdhui() + ".csv", "\uFEFF" + lignes.join("\r\n"), "text/csv;charset=utf-8");
    App.Toast.afficher("Tâches exportées en CSV 📄");
  }

  function exporterStats() {
    App.Feuille.fermer();
    const { faits, pomodoros } = App.etat.stats;
    const jours = [...new Set([...Object.keys(faits), ...Object.keys(pomodoros)])].sort();
    const lignes = [ligneCsv(["date", "taches_terminees", "pomodoros"])];
    jours.forEach((j) => lignes.push(ligneCsv([j, faits[j] || 0, pomodoros[j] || 0])));
    App.telecharger("mes-statistiques-" + App.aujourdhui() + ".csv", "\uFEFF" + lignes.join("\r\n"), "text/csv;charset=utf-8");
    App.Toast.afficher("Statistiques exportées en CSV 📊");
  }

  /* ---------- Export calendrier (.ics) ---------- */

  function echapperIcs(texte) {
    return String(texte || "")
      .replace(/\\/g, "\\\\")
      .replace(/;/g, "\\;")
      .replace(/,/g, "\\,")
      .replace(/\r?\n/g, "\\n");
  }

  function horodatageIcs(date) {
    const z = (n) => String(n).padStart(2, "0");
    return date.getUTCFullYear()
      + z(date.getUTCMonth() + 1)
      + z(date.getUTCDate())
      + "T"
      + z(date.getUTCHours())
      + z(date.getUTCMinutes())
      + z(date.getUTCSeconds())
      + "Z";
  }

  App.exporterICS = function () {
    if (App.Feuille && App.Feuille.ouverte()) App.Feuille.fermer();
    const taches = App.toutesLesTaches().filter(({ bloc }) => !!bloc.echeance);
    if (!taches.length) {
      App.Toast.afficher("Aucune tâche avec date limite à exporter");
      return;
    }

    const stamp = horodatageIcs(new Date());
    const lignes = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//FocusFlow//Calendrier Taches//FR",
      "CALSCALE:GREGORIAN",
      "METHOD:PUBLISH",
      "X-WR-CALNAME:FocusFlow",
    ];

    const REGLE_REP = { jour: "FREQ=DAILY", semaine: "FREQ=WEEKLY", mois: "FREQ=MONTHLY" };

    taches.forEach(({ page, bloc }) => {
      const dateCompacte = bloc.echeance.replace(/-/g, "");
      const titre = (bloc.fait ? "✅ " : "") + (bloc.texte || "Tâche sans titre");
      const descParts = ["Page : " + (page.icone || "📝") + " " + (page.titre || "Sans titre")];
      if (bloc.tags && bloc.tags.length) descParts.push("Tags : " + bloc.tags.map((t) => "#" + t).join(", "));

      lignes.push("BEGIN:VEVENT");
      lignes.push("UID:focusflow-" + bloc.id + "@focusflow.app");
      lignes.push("DTSTAMP:" + stamp);

      if (bloc.heure && /^\d{2}:\d{2}$/.test(bloc.heure)) {
        const [hh, mm] = bloc.heure.split(":").map(Number);
        const z = (n) => String(n).padStart(2, "0");
        const debut = dateCompacte + "T" + z(hh) + z(mm) + "00";
        const finDate = new Date(bloc.echeance + "T00:00:00");
        finDate.setHours(hh, mm + 30, 0, 0);
        const fin = App.iso(finDate).replace(/-/g, "") + "T" + z(finDate.getHours()) + z(finDate.getMinutes()) + "00";
        lignes.push("DTSTART:" + debut);
        lignes.push("DTEND:" + fin);
      } else {
        const lendemain = App.ajouterJours(bloc.echeance, 1).replace(/-/g, "");
        lignes.push("DTSTART;VALUE=DATE:" + dateCompacte);
        lignes.push("DTEND;VALUE=DATE:" + lendemain);
      }

      if (bloc.repete && REGLE_REP[bloc.repete]) {
        lignes.push("RRULE:" + REGLE_REP[bloc.repete]);
      }

      lignes.push("SUMMARY:" + echapperIcs(titre));
      lignes.push("DESCRIPTION:" + echapperIcs(descParts.join("\n")));
      if (bloc.tags && bloc.tags.length) {
        lignes.push("CATEGORIES:" + bloc.tags.map(echapperIcs).join(","));
      }
      lignes.push("STATUS:" + (bloc.fait ? "COMPLETED" : "NEEDS-ACTION"));

      if (bloc.heure && !bloc.fait) {
        lignes.push("BEGIN:VALARM");
        lignes.push("TRIGGER:-PT15M");
        lignes.push("ACTION:DISPLAY");
        lignes.push("DESCRIPTION:" + echapperIcs(titre));
        lignes.push("END:VALARM");
      }

      lignes.push("END:VEVENT");
    });

    lignes.push("END:VCALENDAR");
    App.telecharger("focusflow-calendrier-" + App.aujourdhui() + ".ics", lignes.join("\r\n") + "\r\n", "text/calendar;charset=utf-8");
    App.Toast.afficher(taches.length + " tâche" + (taches.length > 1 ? "s" : "") + " exportée" + (taches.length > 1 ? "s" : "") + " en .ics 📅");
  };

  function ouvrirSauvegarde() {
    const entree = App.el("input", { type: "file", accept: ".json,application/json", hidden: true, onchange: () => importer(entree.files[0]) });
    App.Feuille.ouvrir("Sauvegarde et export", [
      App.el("p", { class: "aide" }, "Tes données sont enregistrées dans ce navigateur. Fais une sauvegarde de temps en temps, ou pour les passer sur un autre appareil."),
      App.el("div", { class: "liste-actions" },
        App.el("button", { type: "button", class: "ligne-action", onclick: exporter },
          App.el("span", { class: "ligne-icone" }, "💾"), App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Exporter une sauvegarde"), App.el("small", null, "Un fichier .json avec toutes tes pages"))),
        App.el("button", { type: "button", class: "ligne-action", onclick: () => entree.click() },
          App.el("span", { class: "ligne-icone" }, "📥"), App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Importer une sauvegarde"), App.el("small", null, "Fusionner ou remplacer"))),
        App.el("button", { type: "button", class: "ligne-action", onclick: exporterTaches },
          App.el("span", { class: "ligne-icone" }, "📄"), App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Exporter les tâches (CSV)"), App.el("small", null, "Pour Excel ou pandas"))),

        App.el("button", { type: "button", class: "ligne-action", onclick: exporterStats },
          App.el("span", { class: "ligne-icone" }, "📊"), App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Exporter les statistiques (CSV)"), App.el("small", null, "Tâches terminées et pomodoros par jour"))),
        App.el("button", { type: "button", class: "ligne-action", onclick: () => App.exporterICS() },
          App.el("span", { class: "ligne-icone" }, "📅"), App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Exporter le calendrier (.ics)"), App.el("small", null, "Pour Google Calendar, Notion Calendar, Apple…")))),
      entree,
    ]);
  }


  /* ---------- Corbeille ---------- */

  function depuis(date) {
    const jours = Math.floor((Date.now() - date) / 864e5);
    if (jours >= 1) return "il y a " + pluriel(jours, "jour");
    const heures = Math.floor((Date.now() - date) / 36e5);
    return heures >= 1 ? "il y a " + heures + " h" : "à l'instant";
  }

  function restaurer(entree) {
    App.etat.corbeille = App.etat.corbeille.filter((e) => e.id !== entree.id);
    if (entree.kind === "page") {
      const page = entree.data;
      if (App.etat.pages.some((p) => p.id === page.id)) page.id = App.id();
      delete App.etat.supprimees[page.id];
      page.maj = Date.now();
      App.etat.pages.push(page);
      App.sauver();
      App.ouvrirPage(page.id);
      App.Toast.afficher("Page restaurée ✅");
    } else {
      const page = App.etat.pages.find((p) => p.id === entree.pageId) || App.page();
      const blocs = entree.data;
      page.blocs.splice(Math.min(entree.index, page.blocs.length), 0, ...blocs);
      App.sauver();
      App.ouvrirPage(page.id);
      App.Toast.afficher(pluriel(blocs.length, "bloc") + " restauré" + (blocs.length > 1 ? "s" : "") + " dans « " + (page.titre || "Sans titre") + " »");
    }
    App.Feuille.fermer();
  }

  function ouvrirCorbeille() {
    const liste = App.etat.corbeille;
    const contenu = [App.el("p", { class: "aide" }, "Les éléments supprimés sont gardés 30 jours.")];

    if (!liste.length) {
      contenu.push(App.el("p", { class: "vide-feuille" }, "La corbeille est vide 🧹"));
    } else {
      contenu.push(App.el("div", { class: "liste-corbeille" }, liste.map((e) => {
        const titre = e.kind === "page"
          ? e.data.icone + " Page « " + (e.data.titre || "Sans titre") + " »"
          : pluriel(e.data.length, "bloc") + " de « " + (e.pageTitre || "Sans titre") + " »";
        const apercu = e.kind === "page"
          ? pluriel(e.data.blocs.length, "bloc")
          : (e.data.map((b) => b.texte).find((t) => t.trim())
            || (e.data.some((b) => b.type === "image" && b.src) ? "🖼 Image" : "")).slice(0, 80);
        return App.el("div", { class: "ligne-corbeille" },
          App.el("div", { class: "corps" }, App.el("strong", null, titre), App.el("small", null, depuis(e.date) + (apercu ? " · " + apercu : ""))),
          App.el("button", { type: "button", class: "btn-secondaire", onclick: () => restaurer(e) }, "Restaurer"),
          App.el("button", { type: "button", class: "btn-icone", "aria-label": "Supprimer définitivement", title: "Supprimer définitivement", onclick: () => {
            App.etat.corbeille = App.etat.corbeille.filter((x) => x.id !== e.id);
            App.sauver();
            ouvrirCorbeille();
          } }, "×"));
      })));
      contenu.push(App.el("div", { class: "actions" },
        App.el("button", { type: "button", class: "btn-danger", onclick: async () => {
          if (await App.Confirmer("Vider la corbeille ? Cette action est définitive.", "Vider")) {
            App.etat.corbeille = [];
            App.sauver();
            ouvrirCorbeille();
          }
        } }, "Vider la corbeille")));
    }
    App.Feuille.ouvrir("Corbeille", contenu);
  }

  // Corbeille : mise en corbeille d'une page (appelée par pages.js)
  App.mettreEnCorbeille = function (page) {
    const id = App.id();
    App.etat.corbeille.unshift({ id: id, kind: "page", date: Date.now(), data: page });
    App.etat.supprimees[page.id] = Date.now();
    return id;
  };
  App.sortirDeCorbeille = function (idCorbeille, idPage) {
    App.etat.corbeille = App.etat.corbeille.filter((e) => e.id !== idCorbeille);
    delete App.etat.supprimees[idPage];
  };


  /* ---------- Statistiques ---------- */

  function serie(donnees, nbJours) {
    const resultat = [];
    for (let i = nbJours - 1; i >= 0; i--) {
      const jour = App.ajouterJours(App.aujourdhui(), -i);
      resultat.push({ jour: jour, valeur: donnees[jour] || 0 });
    }
    return resultat;
  }

  function graphique(points, classe) {
    const max = Math.max(1, ...points.map((p) => p.valeur));
    return App.el("div", { class: "barres " + classe, role: "img", "aria-label": "Graphique des 14 derniers jours" },
      points.map((p) => {
        const nom = new Date(p.jour + "T00:00:00").toLocaleDateString("fr-FR", { weekday: "narrow" });
        const aujourdhui = p.jour === App.aujourdhui();
        return App.el("div", { class: "barre-col" + (aujourdhui ? " auj" : ""), title: App.etiquetteDate(p.jour) + " : " + p.valeur },
          App.el("span", { class: "barre-valeur" }, p.valeur ? String(p.valeur) : ""),
          App.el("span", { class: "barre-haut" }, App.el("i", { style: "height:" + Math.round((p.valeur / max) * 100) + "%" })),
          App.el("span", { class: "barre-nom" }, nom));
      }));
  }

  function serieJours(faits) {
    let n = 0;
    let jour = App.aujourdhui();
    if (!faits[jour]) jour = App.ajouterJours(jour, -1); // la série n'est pas perdue tant que la journée n'est pas finie
    while (faits[jour]) { n++; jour = App.ajouterJours(jour, -1); }
    return n;
  }

  function ouvrirStats() {
    const taches = App.toutesLesTaches();
    const faites = taches.filter(({ bloc }) => bloc.fait).length;
    const retard = taches.filter(({ bloc }) => App.statutDate(bloc) === "retard").length;
    const { faits, pomodoros } = App.etat.stats;
    const total7 = (d) => serie(d, 7).reduce((n, p) => n + p.valeur, 0);

    const carte = (valeur, nom, classe) => App.el("div", { class: "carte-stat " + (classe || "") },
      App.el("strong", null, String(valeur)), App.el("span", null, nom));

    const tags = Object.entries(App.tousLesTags()).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const maxTag = tags.length ? tags[0][1] : 1;

    const pages = App.etat.pages
      .map((p) => ({ p: p, n: p.blocs.filter((b) => b.type === "tache").length, f: p.blocs.filter((b) => b.type === "tache" && b.fait).length }))
      .filter((x) => x.n > 0);

    App.Feuille.ouvrir("Statistiques", [
      App.el("div", { class: "cartes-stats" },
        carte(faites + " / " + taches.length, "tâches terminées"),
        carte(total7(faits), "terminées cette semaine"),
        carte(serieJours(faits) + " 🔥", "jours d'affilée"),
        carte(retard, "en retard", retard ? "alerte" : ""),
        carte(total7(pomodoros), "pomodoros cette semaine"),
        carte(App.etat.pages.length, "pages")),
      App.el("h3", { class: "titre-section" }, "Tâches terminées (14 jours)"),
      graphique(serie(faits, 14), "b-taches"),
      App.el("h3", { class: "titre-section" }, "Pomodoros (14 jours)"),
      graphique(serie(pomodoros, 14), "b-pomo"),
      pages.length ? App.el("h3", { class: "titre-section" }, "Avancement par page") : null,
      pages.map(({ p, n, f }) => App.el("div", { class: "ligne-avancement" },
        App.el("span", { class: "nom" }, p.icone + " " + (p.titre || "Sans titre")),
        App.el("span", { class: "rail" }, App.el("i", { style: "width:" + Math.round((f / n) * 100) + "%" })),
        App.el("span", { class: "chiffre" }, f + "/" + n))),
      tags.length ? App.el("h3", { class: "titre-section" }, "Tags les plus utilisés") : null,
      tags.map(([t, n]) => App.el("div", { class: "ligne-avancement" },
        App.el("span", { class: "nom" }, "#" + t),
        App.el("span", { class: "rail" }, App.el("i", { style: "width:" + Math.round((n / maxTag) * 100) + "%" })),
        App.el("span", { class: "chiffre" }, String(n)))),
      App.el("div", { class: "actions" },
        App.el("button", { type: "button", class: "btn-secondaire", onclick: exporterStats }, "Exporter en CSV")),
    ], { large: true });
  }


  /* ---------- Utilisé par le menu Paramètres ---------- */

  App.Donnees = { stats: ouvrirStats, corbeille: ouvrirCorbeille, sauvegarde: ouvrirSauvegarde };
})();
