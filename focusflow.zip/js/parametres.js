"use strict";

/* =====================================================
   parametres.js : le menu Paramètres
   Apparence, données, synchronisation, rappels, installation, aide
   ===================================================== */

App.Parametres = (function () {
  const THEMES = [["auto", "🌗", "Auto"], ["clair", "☀️", "Clair"], ["sombre", "🌙", "Sombre"]];

  const PALETTES = [["neutre", "Neutre"], ["ardoise", "Ardoise"], ["chaud", "Chaud"], ["noir", "Noir"]];
  const POLICES = [["systeme", "Système"], ["arrondie", "Arrondie"], ["serif", "Serif"], ["mono", "Mono"]];
  const AIDE_PALETTE = {
    neutre: "Gris doux, classique", ardoise: "Gris bleuté, plus tech", chaud: "Tons crème, agréable à lire",
    noir: "Noir profond en thème sombre (économise la batterie sur écran OLED)",
  };

  const SOUS_TITRE_THEME = {
    auto: "Suit le réglage de ton téléphone ou de ton ordinateur",
    clair: "Toujours clair", sombre: "Toujours sombre",
  };

  const RACCOURCIS = [
    ["/", "choisir le type d'un bloc"],
    ["Entrée", "nouveau bloc"],
    ["Tab · Maj+Tab", "décaler un bloc"],
    ["# · ## · - · [] · > · 1.", "titre, liste, tâche, citation… en début de ligne"],
    ["---", "séparateur (puis Entrée)"],
    ["Ctrl+K", "rechercher partout"],
    ["Ctrl+S", "synchroniser ou sauvegarder"],
    ["Ctrl+Z · Ctrl+Y", "annuler · rétablir"],
    ["Ctrl+B · I · U", "gras · italique · souligné"],
    ["Échap", "fermer un menu, quitter le focus"],
  ];

  // Une ligne cliquable : icône, titre, sous-titre, et un petit texte à droite
  function ligne(icone, titre, sousTitre, action, droite) {
    return App.el("button", { type: "button", class: "ligne-action", onclick: action },
      App.el("span", { class: "ligne-icone" }, icone),
      App.el("span", { class: "ligne-texte" }, App.el("strong", null, titre), sousTitre ? App.el("small", null, sousTitre) : null),
      droite ? App.el("span", { class: "ligne-droite" }, droite) : null);
  }

  function section(titre, ...contenu) {
    return App.el("section", { class: "param-section" }, App.el("h3", { class: "titre-section" }, titre), ...contenu);
  }

  function ouvrir() {
    document.body.classList.remove("menu-ouvert");
    App.Feuille.marquerParametres(true);

    /* ----- Apparence ----- */
    const themeActuel = App.etat.theme;
    const segment = App.el("div", { class: "segment", role: "radiogroup", "aria-label": "Thème" },
      THEMES.map(([cle, icone, nom]) => App.el("button", {
        type: "button", role: "radio", "aria-checked": String(themeActuel === cle), class: themeActuel === cle ? "actif" : "",
        onclick: () => { App.definirTheme(cle); ouvrir(); },
      }, icone + " " + nom)));

    // Petit sélecteur à plusieurs boutons pour un réglage (palette, police)
    const choix = (nom, liste, cle) => App.el("div", { class: "segment", role: "radiogroup", "aria-label": nom },
      liste.map(([valeur, libelle]) => App.el("button", {
        type: "button", role: "radio", "aria-checked": String(App.etat.reglages[cle] === valeur), class: App.etat.reglages[cle] === valeur ? "actif" : "",
        "data-valeur": valeur,
        onclick: () => {
          App.etat.reglages[cle] = valeur;
          App.sauver();
          App.appliquerApparence();
          ouvrir();
        },
      }, libelle)));

    const compact = App.el("input", {
      type: "checkbox", role: "switch", checked: App.etat.reglages.compact === true,
      onchange: () => {
        App.etat.reglages.compact = compact.checked;
        App.sauver();
        App.appliquerApparence();
      },
    });

    const animations = App.el("input", {
      type: "checkbox", role: "switch", checked: App.etat.reglages.animations !== false,
      onchange: () => {
        App.etat.reglages.animations = animations.checked;
        App.sauver();
        App.appliquerAnimations();
      },
    });

    /* ----- Données ----- */
    const nbCorbeille = App.etat.corbeille.length;
    const infosSync = App.Sync.infos();
    const rappelsActifs = App.Rappels.actifs();
    const pushActif = App.Push.actif();

    /* ----- Application ----- */
    let installation;
    if (App.Installation.dejaInstallee()) {
      installation = App.el("p", { class: "aide" }, "✅ L'appli est installée sur cet appareil.");
    } else if (App.Installation.disponible()) {
      installation = ligne("📲", "Installer l'appli", "L'ajouter à l'écran d'accueil, comme une vraie appli", async () => {
        await App.Installation.lancer();
        ouvrir();
      }, "Installer");
    } else if (location.protocol === "file:") {
      installation = App.el("p", { class: "aide" },
        "📲 En mode fichier local, FocusFlow fonctionne déjà 100 % hors ligne. Pour l'installer comme application sur ton écran d'accueil, ouvre ce fichier via une adresse https (ex. GitHub Pages) ou localhost, puis choisis « Installer l'application » dans le menu du navigateur.");
    } else {
      installation = App.el("p", { class: "aide" },
        "📲 Pour installer l'appli : ouvre le menu du navigateur (⋮ ou Partager) puis choisis « Installer l'application » ou « Sur l'écran d'accueil ».");
    }

    App.Feuille.ouvrir("Paramètres", [
      section("Apparence",
        segment,
        App.el("p", { class: "aide petit" }, SOUS_TITRE_THEME[themeActuel]),
        App.el("label", { class: "titre-champ" }, "Palette"),
        choix("Palette", PALETTES, "palette"),
        App.el("p", { class: "aide petit" }, AIDE_PALETTE[App.etat.reglages.palette]),
        App.el("label", { class: "titre-champ" }, "Police"),
        choix("Police", POLICES, "police"),
        App.el("label", { class: "ligne-interrupteur" },
          App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Mode compact"), App.el("small", null, "Des blocs plus serrés pour voir plus de contenu")),
          compact),
        App.el("label", { class: "ligne-interrupteur" },
          App.el("span", { class: "ligne-texte" }, App.el("strong", null, "Animations"), App.el("small", null, "Confettis, transitions, effets de fond")),
          animations)),

      section("Mes données",
        ligne("📊", "Statistiques", "Tâches terminées, séries, graphiques", () => App.Donnees.stats(), "›"),
        ligne("🗑", "Corbeille", nbCorbeille ? nbCorbeille + " élément" + (nbCorbeille > 1 ? "s" : "") + " récupérable" + (nbCorbeille > 1 ? "s" : "") : "Vide : les éléments supprimés restent 30 jours", () => App.Donnees.corbeille(), nbCorbeille ? App.el("span", { class: "badge" }, String(nbCorbeille)) : "›"),
        ligne("💾", "Sauvegarde et export", "Fichier JSON, CSV pour Excel ou pandas", () => App.Donnees.sauvegarde(), "›")),

      section("Sur tous mes appareils",
        ligne("☁️", "Synchronisation", infosSync.connecte ? "Connecté en tant que " + infosSync.nom : "Retrouve tes pages sur ton téléphone et ton ordinateur", () => App.Sync.ouvrir(),
          infosSync.connecte ? App.el("span", { class: "point-etat", "data-etat": infosSync.etat.code, title: infosSync.etat.message }) : "›"),
        infosSync.connecte ? ligne("📈", "Mon analyse", "Chiffres calculés en SQL par le serveur", () => App.Analyse.ouvrir(), "›") : null),

      section("Notifications",
        ligne("🔔", "Rappels des tâches", rappelsActifs ? "Activés : une notification à l'heure des tâches (appli ouverte)" : "Désactivés : seul un message dans l'appli s'affiche", async () => {
          if (rappelsActifs) App.Rappels.desactiver();
          else await App.Rappels.activer();
          ouvrir();
        }, rappelsActifs ? "Désactiver" : "Activer"),
        ligne("📲", "Rappels même appli fermée", infosSync.connecte
          ? (pushActif ? "Activés : le serveur t'envoie la notification" : "Le serveur t'envoie la notification à l'heure, téléphone verrouillé")
          : "Demande la synchronisation (ci-dessus) et une adresse https", async () => {
          if (pushActif) await App.Push.desactiver();
          else await App.Push.activer();
          ouvrir();
        }, pushActif ? "Désactiver" : "Activer")),

      section("Application", installation,
        ligne("👋", "Revoir la présentation", "Les astuces de bienvenue", () => App.Accueil.ouvrir(), "›")),

      section("Édition",
        App.el("div", { class: "deux-colonnes" },
          App.el("button", { type: "button", class: "btn-secondaire", onclick: () => { App.Feuille.fermer(); App.Histoire.annuler(); } }, "↶ Annuler"),
          App.el("button", { type: "button", class: "btn-secondaire", onclick: () => { App.Feuille.fermer(); App.Histoire.retablir(); } }, "↷ Rétablir"))),

      App.el("details", { class: "raccourcis" },
        App.el("summary", null, "⌨️ Raccourcis et astuces"),
        App.el("dl", null, RACCOURCIS.map(([touche, texte]) => [App.el("dt", null, touche), App.el("dd", null, texte)]))),

      App.el("p", { class: "aide petit" }, "FocusFlow · version 6.1 · synchro cloud FastAPI, export .ics & stockage IndexedDB."),
    ]);
  }

  // Les boutons ⚙️ (barre latérale et en-tête mobile)
  document.addEventListener("click", (e) => {
    if (e.target.closest('[data-action="parametres"]')) ouvrir();
  });

  return { ouvrir: ouvrir };
})();
