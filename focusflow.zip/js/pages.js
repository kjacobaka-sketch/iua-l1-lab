"use strict";

/* =====================================================
   pages.js : menu latéral, en-tête de page, progression
   ===================================================== */

(function () {
  const $ = (id) => document.getElementById(id);
  const titrePage = $("titre-page");
  const iconePage = $("icone-page");
  const btnFavori = $("btn-favori");
  const btnOptions = $("btn-options-page");
  const listeFavoris = $("liste-favoris");
  const listePages = $("liste-pages");
  const recherche = $("recherche");
  const zonePage = $("page");
  const recherchePage = $("recherche-page");
  const compteurRecherche = $("compteur-recherche");

  const COULEUR_THEME = {
    violet: "#6366f1", bleu: "#3b82f6", vert: "#10b981",
    orange: "#f97316", rose: "#ec4899", turquoise: "#14b8a6",
  };
  let dejaComplet = false;


  /* ---------- En-tête de la page ---------- */

  // Favori et options de la page
  btnFavori.addEventListener("click", () => App.basculerFavori());
  btnOptions.addEventListener("click", () => App.MenuPage.ouvrir());

  App.basculerFavori = function (id) {
    const page = id ? App.etat.pages.find((p) => p.id === id) : App.page();
    if (!page) return;
    page.favori = !page.favori;
    App.sauver();
    App.afficherEntete();
    App.afficherPages();
    App.Toast.afficher(page.favori ? "Ajoutée aux favoris ⭐" : "Retirée des favoris");
  };

  App.afficherEntete = function () {
    const page = App.page();
    document.body.dataset.couleur = page.couleur;
    iconePage.textContent = page.icone;
    titrePage.textContent = page.titre;
    document.title = (page.titre || "Sans titre") + " · FocusFlow";
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", COULEUR_THEME[page.couleur]);
    btnFavori.setAttribute("aria-pressed", String(!!page.favori));
    btnFavori.querySelector(".etoile").textContent = page.favori ? "★" : "☆";
    btnFavori.title = page.favori ? "Retirer des favoris" : "Mettre en favori";
  };

  // Un toucher sur l'icône en choisit une autre
  iconePage.addEventListener("click", () => {
    const page = App.page();
    const i = App.ICONES.indexOf(page.icone);
    page.icone = App.ICONES[(i + 1) % App.ICONES.length];
    App.sauver();
    iconePage.textContent = page.icone;
    iconePage.classList.remove("rebond");
    void iconePage.offsetWidth;
    iconePage.classList.add("rebond");
    App.afficherPages();
  });

  titrePage.addEventListener("input", () => {
    App.page().titre = titrePage.textContent;
    document.title = (App.page().titre || "Sans titre") + " · FocusFlow";
    App.sauver();
    App.afficherPages();
  });
  titrePage.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const premier = zonePage.querySelector(".champ");
      if (premier) premier.focus();
    }
  });


  /* ---------- Barre de progression des tâches ---------- */

  App.majProgres = function (animer) {
    const taches = App.page().blocs.filter((b) => b.type === "tache");
    const faits = taches.filter((b) => b.fait).length;
    const zone = $("progres");
    const pct = taches.length ? Math.round((faits / taches.length) * 100) : 0;
    const complet = taches.length > 0 && faits === taches.length;

    zone.hidden = taches.length === 0;
    $("progres-rempli").style.width = pct + "%";
    $("progres-texte").textContent = taches.length
      ? faits + " / " + taches.length + " tâche" + (taches.length > 1 ? "s" : "") + (complet ? " · bravo 🎉" : "")
      : "";
    zone.classList.toggle("complet", complet);

    if (complet && !dejaComplet && animer) App.confettis($("progres-rempli"), 30);
    dejaComplet = complet;
  };


  /* ---------- Liste des pages ---------- */

  App.afficherPages = function () {
    const q = App.simplifier(recherche.value);
    const courante = App.page().id;
    const pages = App.etat.pages.filter((p) =>
      !q || App.simplifier(p.titre).includes(q) || p.blocs.some((b) => App.simplifier(b.texte).includes(q))
    );

    const favoris = pages.filter((p) => p.favori);
    $("bloc-favoris").hidden = favoris.length === 0;
    listeFavoris.replaceChildren(...favoris.map((p) => ligne(p, courante)));

    if (pages.length === 0) {
      const vide = document.createElement("p");
      vide.className = "vide";
      vide.textContent = "Aucune page trouvée";
      listePages.replaceChildren(vide);
      return;
    }
    listePages.replaceChildren(...pages.map((p) => ligne(p, courante)));
  };

  // Une ligne du menu latéral
  function ligne(p, courante) {
    const ligne = document.createElement("div");
    ligne.className = "page-item" + (p.id === courante && !App.Vues.active() ? " actif" : "");

    const ouvrir = document.createElement("button");
    ouvrir.type = "button";
    ouvrir.className = "page-ouvrir";
    const point = document.createElement("span");
    point.className = "point";
    point.dataset.c = p.couleur;
    const icone = document.createElement("span");
    icone.className = "page-icone";
    icone.textContent = p.icone;
    const nom = document.createElement("span");
    nom.className = "page-nom";
    nom.textContent = p.titre || "Sans titre";
    ouvrir.append(point, icone, nom);
    ouvrir.addEventListener("click", () => App.ouvrirPage(p.id));

    const supprimer = document.createElement("button");
    supprimer.type = "button";
    supprimer.className = "page-supprimer";
    supprimer.textContent = "×";
    supprimer.setAttribute("aria-label", "Supprimer la page « " + (p.titre || "Sans titre") + " »");
    supprimer.addEventListener("click", () => App.supprimerPage(p.id));

    ligne.append(ouvrir, supprimer);
    return ligne;
  }

  App.ouvrirPage = function (id, animer) {
    const page = App.etat.pages.find((p) => p.id === id) || App.etat.pages[0];
    App.Vues.fermer();
    App.effacerRecherche();
    recherchePage.value = "";
    App.majCompteurRecherche(null);
    App.etat.courante = page.id;
    App.sauver();

    App.Toast.fermer();
    App.MenuTypes.fermer();
    App.MenuBloc.fermer();
    App.afficherEntete();
    App.afficherBlocs(null);
    App.majProgres(false);
    App.afficherPages();
    fermerLateral();
    window.scrollTo(0, 0);

    if (animer !== false && !App.mouvementReduit()) {
      zonePage.classList.remove("change");
      void zonePage.offsetWidth;
      zonePage.classList.add("change");
    }
  };

  App.creerPage = function () {
    const nombre = App.etat.pages.length;
    const page = App.nouvellePage(
      "",
      App.COULEURS_PAGE[nombre % App.COULEURS_PAGE.length],
      App.ICONES[nombre % App.ICONES.length]
    );
    App.etat.pages.push(page);
    recherche.value = "";
    App.ouvrirPage(page.id);
    titrePage.focus();
  };

  App.supprimerPage = function (id) {
    const pages = App.etat.pages;
    const i = pages.findIndex((p) => p.id === id);
    if (i === -1) return;
    const page = pages[i];
    const etaitCourante = App.page().id === id;

    pages.splice(i, 1);
    const idCorbeille = App.mettreEnCorbeille(page); // gardée 30 jours, et notée comme supprimée pour la synchronisation
    let remplacante = null;
    if (pages.length === 0) {
      remplacante = App.nouvellePage();
      pages.push(remplacante);
    }

    if (etaitCourante || remplacante) {
      App.ouvrirPage((pages[i] || pages[i - 1] || pages[0]).id);
    } else {
      App.sauver();
      App.afficherPages();
    }

    App.Toast.afficher("Page supprimée", {
      action: "Annuler",
      surAction: () => {
        App.sortirDeCorbeille(idCorbeille, page.id);
        page.maj = Date.now();
        if (remplacante) pages.splice(pages.indexOf(remplacante), 1);
        pages.splice(Math.min(i, pages.length), 0, page);
        App.ouvrirPage(page.id);
      },
    });
  };


  /* ---------- Menu latéral (tiroir sur mobile) ---------- */

  function ouvrirLateral() { document.body.classList.add("menu-ouvert"); }
  function fermerLateral() { document.body.classList.remove("menu-ouvert"); }

  $("ouvrir-menu").addEventListener("click", ouvrirLateral);
  $("voile").addEventListener("click", fermerLateral);
  $("nouvelle-page").addEventListener("click", () => App.Modeles.ouvrir());

  // Recherche dans la page
  recherchePage.addEventListener("input", () => App.rechercherDansPage(recherchePage.value));
  recherchePage.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      recherchePage.value = "";
      App.rechercherDansPage("");
      recherchePage.blur();
    }
  });
  App.majCompteurRecherche = function (n) {
    compteurRecherche.textContent = n === null ? "" : n + " résultat" + (n > 1 ? "s" : "");
  };
  recherche.addEventListener("input", App.afficherPages);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") fermerLateral();
  });
})();
