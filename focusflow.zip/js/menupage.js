"use strict";

/* =====================================================
   menupage.js : le menu « Options » de chaque page
   Couleur, icône, favori, dupliquer, partager, supprimer
   ===================================================== */

App.MenuPage = (function () {
  const NOMS_COULEURS = { violet: "Indigo", bleu: "Bleu", vert: "Vert", orange: "Orange", rose: "Rose", turquoise: "Turquoise" };

  /* ---------- Le texte de la page (pour partager ou exporter) ---------- */

  function texteDePage(page) {
    const lignes = [];
    let numero = 0;
    const titre = page.titre || "Sans titre";
    lignes.push("# " + page.icone + " " + titre, "");

    page.blocs.forEach((b) => {
      numero = b.type === "numerotee" ? numero + 1 : 0;
      const marge = "  ".repeat(b.niveau || 0);
      const t = b.texte || "";
      let l;
      switch (b.type) {
        case "titre": l = "## " + t; break;
        case "sous_titre": l = "### " + t; break;
        case "tache": {
          l = marge + "- [" + (b.fait ? "x" : " ") + "] " + t;
          if (b.echeance) l += " (échéance : " + b.echeance + (b.heure ? " " + b.heure : "") + ")";
          if (b.tags && b.tags.length) l += " " + b.tags.map((x) => "#" + x).join(" ");
          break;
        }
        case "liste": l = marge + "- " + t; break;
        case "numerotee": l = marge + numero + ". " + t; break;
        case "citation": l = "> " + t; break;
        case "image": l = "_[Image" + (t ? " : " + t : "") + "]_"; break;
        case "separateur": l = "---"; break;
        default: l = marge + t;
      }
      lignes.push(l);
    });
    return lignes.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
  }
  App.texteDePage = texteDePage;

  function nomFichier(page) {
    const base = (page.titre || "page").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-+|-+$/g, "").toLowerCase();
    return (base || "page") + ".md";
  }


  /* ---------- Actions ---------- */

  async function copier(texte) {
    try {
      await navigator.clipboard.writeText(texte);
      return true;
    } catch (erreur) {
      // plan B pour les navigateurs qui refusent l'API moderne
      try {
        const zone = App.el("textarea", { style: "position:fixed;opacity:0;top:0;left:0" });
        zone.value = texte;
        document.body.append(zone);
        zone.select();
        const ok = document.execCommand("copy");
        zone.remove();
        return ok;
      } catch (e2) { return false; }
    }
  }

  async function partager(page) {
    const texte = texteDePage(page);
    try {
      await navigator.share({ title: page.titre || "Sans titre", text: texte });
    } catch (erreur) {
      if (erreur && erreur.name === "AbortError") return;   // la personne a annulé : rien à dire
      if (await copier(texte)) App.Toast.afficher("Partage impossible ici : texte copié à la place");
      else App.Toast.afficher("Le partage n'est pas disponible sur cet appareil");
    }
  }

  function envoyerParMail(page) {
    let corps = texteDePage(page);
    if (corps.length > 1800) corps = corps.slice(0, 1800) + "\n…";
    window.location.href = "mailto:?subject=" + encodeURIComponent(page.titre || "Sans titre") + "&body=" + encodeURIComponent(corps);
  }

  function dupliquerPage(page) {
    const copie = JSON.parse(JSON.stringify(page));
    copie.id = App.id();
    copie.titre = (page.titre || "Sans titre") + " (copie)";
    copie.favori = false;
    copie.maj = Date.now();
    copie.blocs.forEach((b) => { b.id = App.id(); b.rappele = ""; });
    const pages = App.etat.pages;
    pages.splice(pages.indexOf(page) + 1, 0, copie);
    App.Feuille.fermer();
    App.ouvrirPage(copie.id);
    App.Toast.afficher("Page dupliquée");
  }


  /* ---------- Le menu ---------- */

  function ligne(icone, titre, sousTitre, action, danger) {
    return App.el("button", { type: "button", class: "ligne-action" + (danger ? " danger" : ""), onclick: action },
      App.el("span", { class: "ligne-icone" }, icone),
      App.el("span", { class: "ligne-texte" }, App.el("strong", null, titre), sousTitre ? App.el("small", null, sousTitre) : null),
      App.el("span", { class: "ligne-droite" }, "›"));
  }

  function section(titre, ...contenu) {
    return App.el("section", { class: "param-section" }, App.el("h3", { class: "titre-section" }, titre), ...contenu);
  }

  /* ---------- Lien de partage en lecture seule (demande le serveur) ---------- */

  async function lienDePartage(page) {
    if (!App.Sync.connecte()) {
      App.Toast.afficher("Pour créer un lien, connecte d'abord la synchronisation (Paramètres)");
      return;
    }
    if (location.protocol === "file:" && !App.Sync.adresse().startsWith("http")) {
      App.Toast.afficher("Renseigne l'adresse du serveur dans la synchronisation");
      return;
    }
    App.Feuille.ouvrir("Lien de partage", [App.el("p", { class: "aide" }, "⏳ Création du lien…")]);
    try {
      await App.Sync.synchroniser(false);          // la version du serveur doit contenir la page à jour
      const r = await App.Sync.appel("POST", "/partages", { page_id: page.id });
      if (r.statut !== 200) throw new Error((r.donnees && r.donnees.detail) || "Erreur " + r.statut);
      const adresse = App.Sync.adresse() + r.donnees.chemin;
      const champ = App.el("input", { type: "text", readonly: true, value: adresse, "aria-label": "Lien de partage", onfocus: () => champ.select() });
      App.Feuille.ouvrir("Lien de partage", [
        App.el("p", { class: "aide" }, "Toute personne qui a ce lien peut LIRE la page « " + (page.titre || "Sans titre") + " » (sans compte, sans pouvoir la modifier). Le lien montre toujours la dernière version synchronisée."),
        App.el("div", { class: "champ-form" }, champ),
        App.el("div", { class: "actions" },
          App.el("button", { type: "button", class: "btn-primaire", onclick: async () => {
            if (typeof navigator.share === "function") {
              try { await navigator.share({ title: page.titre || "Sans titre", url: adresse }); return; } catch (e) { if (e && e.name === "AbortError") return; }
            }
            App.Toast.afficher((await copier(adresse)) ? "Lien copié ✓" : "Copie impossible : sélectionne le lien");
          } }, typeof navigator.share === "function" ? "📤 Envoyer le lien" : "📋 Copier le lien"),
          App.el("button", { type: "button", class: "btn-danger", onclick: async () => {
            if (!(await App.Confirmer("Désactiver ce lien ? Les personnes qui l'ont ne pourront plus voir la page.", "Désactiver"))) return;
            const d = await App.Sync.appel("DELETE", "/partages/" + r.donnees.jeton);
            App.Toast.afficher(d.statut === 200 ? "Lien désactivé" : "Impossible de désactiver pour l'instant");
            if (d.statut === 200) App.Feuille.fermer();
          } }, "Désactiver le lien")),
      ]);
    } catch (erreur) {
      App.Feuille.ouvrir("Lien de partage", [App.el("p", { class: "erreur-form" }, erreur instanceof TypeError ? "Serveur injoignable (hors ligne ?)" : erreur.message)]);
    }
  }

  function ouvrir() {
    if (App.Vues.active()) return;   // les vues (Aujourd'hui…) ne sont pas des pages
    const page = App.page();
    const taches = page.blocs.filter((b) => b.type === "tache");
    const faites = taches.filter((b) => b.fait).length;

    const resume = App.el("div", { class: "resume-page" },
      App.el("span", { class: "resume-icone" }, page.icone),
      App.el("div", null,
        App.el("strong", null, page.titre || "Sans titre"),
        App.el("small", null, taches.length ? faites + " / " + taches.length + " tâche" + (taches.length > 1 ? "s" : "") + " terminée" + (faites > 1 ? "s" : "") : "Aucune tâche")));

    const couleurs = App.el("div", { class: "couleurs", role: "group", "aria-label": "Couleur de la page" },
      App.COULEURS_PAGE.map((c) => App.el("button", {
        type: "button", class: "pastille" + (page.couleur === c ? " choisie" : ""), "data-c": c,
        title: NOMS_COULEURS[c], "aria-label": "Couleur " + NOMS_COULEURS[c],
        onclick: () => {
          page.couleur = c;
          App.sauver();
          App.afficherEntete();
          App.afficherPages();
          ouvrir();
        },
      })));

    const icones = App.el("div", { class: "icones", role: "group", "aria-label": "Icône de la page" },
      App.ICONES.map((i) => App.el("button", {
        type: "button", class: "choix-icone" + (page.icone === i ? " choisie" : ""), "aria-label": "Icône " + i,
        onclick: () => {
          page.icone = i;
          App.sauver();
          App.afficherEntete();
          App.afficherPages();
          ouvrir();
        },
      }, i)));

    const peutPartager = typeof navigator.share === "function";

    App.Feuille.ouvrir("Options de la page", [
      resume,

      section("Apparence",
        App.el("div", { class: "champ-form" }, App.el("label", null, "Couleur"), couleurs),
        App.el("div", { class: "champ-form" }, App.el("label", null, "Icône"), icones)),

      section("Organiser",
        ligne(page.favori ? "★" : "☆", page.favori ? "Retirer des favoris" : "Mettre en favori", "Les favoris restent en haut du menu des pages", () => {
          App.basculerFavori();
          ouvrir();
        }),
        ligne("⧉", "Dupliquer la page", "Crée une copie avec tous les blocs", () => dupliquerPage(page))),

      section("Partager",
        peutPartager ? ligne("📤", "Partager…", "Messages, WhatsApp, e-mail… (menu de ton appareil)", () => partager(page)) : null,
        ligne("🔗", "Lien de partage (lecture seule)", App.Sync.connecte() ? "Une page web que tu peux désactiver à tout moment" : "Demande la synchronisation (Paramètres)", () => lienDePartage(page)),
        ligne("📋", "Copier le texte", "Pour le coller où tu veux", async () => {
          App.Toast.afficher((await copier(texteDePage(page))) ? "Texte copié ✓" : "Copie impossible ici");
        }),
        ligne("✉️", "Envoyer par e-mail", "Ouvre ton application de messagerie", () => envoyerParMail(page)),
        ligne("⬇️", "Télécharger (.md)", "Un fichier texte lisible partout", () => {
          App.telecharger(nomFichier(page), texteDePage(page), "text/markdown;charset=utf-8");
          App.Toast.afficher("Fichier téléchargé");
        }),
        ligne("🖨️", "Imprimer ou enregistrer en PDF", null, () => {
          App.Feuille.fermer();
          setTimeout(() => window.print(), 250);
        }),
        App.el("p", { class: "aide petit" }, "Le partage envoie une copie du texte. Pour retrouver tes pages sur plusieurs appareils, utilise plutôt la synchronisation (Paramètres).")),

      section("Zone sensible",
        ligne("🗑", "Supprimer la page", "Elle reste 30 jours dans la corbeille", () => {
          App.Feuille.fermer();
          App.supprimerPage(page.id);
        }, true)),
    ]);
  }

  return { ouvrir: ouvrir };
})();
