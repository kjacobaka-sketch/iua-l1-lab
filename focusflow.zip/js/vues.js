"use strict";

/* =====================================================
   vues.js : « Aujourd'hui », « En retard », « À venir » et tags
   Des listes de tâches qui rassemblent toutes les pages.
   ===================================================== */

App.Vues = (function () {
  const boutons = document.getElementById("vues");
  const zone = document.getElementById("vue-page");
  const pagePrincipale = document.getElementById("page");
  let vue = null;      // { type: "aujourdhui" | "retard" | "avenir" | "tag", tag }
  let minuteur = null;

  const TITRES = {
    aujourdhui: { icone: "📅", nom: "Aujourd'hui" },
    retard: { icone: "⚠️", nom: "En retard" },
    avenir: { icone: "🗓", nom: "À venir" },
  };

  function filtrer(v) {
    let liste = App.toutesLesTaches();
    if (v.type === "tag") {
      liste = liste.filter(({ bloc }) => bloc.tags.includes(v.tag));
    } else if (v.type === "aujourdhui") {
      liste = liste.filter(({ bloc }) => App.statutDate(bloc) === "aujourdhui");
    } else {
      liste = liste.filter(({ bloc }) => App.statutDate(bloc) === v.type);
    }
    // Les tâches faites à la fin, puis par date
    return liste.sort((a, b) =>
      (a.bloc.fait - b.bloc.fait) || (a.bloc.echeance || "9999").localeCompare(b.bloc.echeance || "9999"));
  }

  const compter = (v) => filtrer(v).filter(({ bloc }) => !bloc.fait).length;
  const memeVue = (a, b) => a && b && a.type === b.type && a.tag === b.tag;


  /* ---------- Boutons du menu latéral ---------- */

  function afficherBoutons() {
    const un = (v, icone, nom) => {
      const n = (v.type === "tableau" || v.type === "calendrier") ? 0 : compter(v);
      return App.el("button", {
        type: "button",
        class: "vue-item" + (memeVue(vue, v) ? " actif" : "") + (v.type === "retard" && n ? " alerte" : ""),
        onclick: () => ouvrir(v),
      }, App.el("span", { class: "vue-icone" }, icone), App.el("span", { class: "vue-nom" }, nom), n ? App.el("span", { class: "vue-compte" }, String(n)) : null);
    };

    const tags = Object.keys(App.tousLesTags()).sort();
    boutons.replaceChildren(
      un({ type: "aujourdhui" }, "📅", "Aujourd'hui"),
      un({ type: "retard" }, "⚠️", "En retard"),
      un({ type: "avenir" }, "🗓", "À venir"),
      un({ type: "tableau" }, "▦", "Tableau"),
      un({ type: "calendrier" }, "🗓️", "Calendrier"),
      ...tags.map((t) => un({ type: "tag", tag: t }, "#", t))
    );
  }


  /* ---------- Page de la vue ---------- */

  // Une ligne de tâche (case, texte, page d'origine, date, tags). Réutilisée par le calendrier.
  function ligneTache(page, bloc, rafraichir) {
    rafraichir = rafraichir || afficherVue;
    const case_ = App.el("button", {
        type: "button", class: "case", role: "checkbox", "aria-checked": String(!!bloc.fait), "aria-label": "Tâche terminée",
        onclick: () => {
          App.basculerTache(bloc, rafraichir);
          case_.setAttribute("aria-checked", String(bloc.fait));
          ligne.classList.toggle("fait", bloc.fait);
          if (bloc.fait) App.confettis(case_, 14);
        },
      });
      case_.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

      const texte = App.el("button", {
        type: "button", class: "vue-texte", title: "Ouvrir la page",
        onclick: () => {
          App.ouvrirPage(page.id);
          setTimeout(() => App.focaliser(bloc.id, "fin"), 60);
        },
      }, bloc.texte || "Tâche sans titre");

      const meta = App.el("div", { class: "meta" },
        App.el("span", { class: "chip page-chip" }, page.icone + " " + (page.titre || "Sans titre")),
        bloc.echeance ? App.el("span", { class: "chip date " + App.statutDate(bloc) }, "📅 " + App.etiquetteDate(bloc.echeance, bloc.heure) + (bloc.repete ? " 🔁" : "")) : null,
        bloc.tags.map((t) => App.el("button", { type: "button", class: "chip tag", onclick: () => ouvrir({ type: "tag", tag: t }) }, "#" + t)));

      const ligne = App.el("div", { class: "vue-ligne" + (bloc.fait ? " fait" : "") },
        case_,
        App.el("div", { class: "corps" }, texte, meta),
        App.el("button", { type: "button", class: "detail visible", "aria-label": "Date, rappel et tags", onclick: () => App.ouvrirDetails(bloc.id) }, "📅"));
    return ligne;
  }


  function entete(icone, nom, sousTitre) {
    return [
      App.el("div", { class: "bandeau", "aria-hidden": "true" }),
      App.el("div", { class: "entete" },
        App.el("div", { class: "icone-page statique", "aria-hidden": "true" }, icone),
        App.el("h1", { class: "titre-vue" }, nom),
        App.el("p", { class: "sous-titre-vue" }, sousTitre)),
    ];
  }

  function afficherVue() {
    if (!vue) return;
    if (vue.type === "tableau" || vue.type === "calendrier") {
      const r = App.VuesPlus[vue.type]();
      zone.replaceChildren(...entete(r.icone, r.nom, r.sousTitre), r.contenu);
      return;
    }
    const titre = vue.type === "tag" ? { icone: "🏷", nom: "#" + vue.tag } : TITRES[vue.type];
    const liste = filtrer(vue);
    const restantes = liste.filter(({ bloc }) => !bloc.fait).length;

    const lignes = liste.map(({ page, bloc }) => ligneTache(page, bloc));

    zone.replaceChildren(
      App.el("div", { class: "bandeau", "aria-hidden": "true" }),
      App.el("div", { class: "entete" },
        App.el("div", { class: "icone-page statique", "aria-hidden": "true" }, titre.icone),
        App.el("h1", { class: "titre-vue" }, titre.nom),
        App.el("p", { class: "sous-titre-vue" }, restantes
          ? restantes + " tâche" + (restantes > 1 ? "s" : "") + " à faire"
          : (liste.length ? "Tout est fait 🎉" : "Rien ici pour le moment"))),
      lignes.length ? App.el("div", { class: "vue-liste" }, lignes)
        : App.el("p", { class: "vue-vide" },
          vue.type === "tag" ? "Aucune tâche avec ce tag."
            : "Ajoute une date limite à une tâche avec le bouton 📅 pour la retrouver ici."));
  }

  function ouvrir(v) {
    vue = v;
    document.body.classList.add("en-vue");
    document.body.classList.remove("menu-ouvert");
    pagePrincipale.hidden = true;
    zone.hidden = false;
    document.body.dataset.couleur = "violet";
    App.Toast.fermer();
    afficherVue();
    afficherBoutons();
    if (App.afficherPages) App.afficherPages();
    window.scrollTo(0, 0);
    if (!App.mouvementReduit()) {
      zone.classList.remove("change");
      void zone.offsetWidth;
      zone.classList.add("change");
    }
  }

  function fermer() {
    if (!vue) return;
    vue = null;
    document.body.classList.remove("en-vue");
    zone.hidden = true;
    pagePrincipale.hidden = false;
    afficherBoutons();
  }

  // Mise à jour après chaque changement (avec un petit délai pour laisser jouer les animations)
  App.ecouteurs.push(() => {
    clearTimeout(minuteur);
    minuteur = setTimeout(() => {
      afficherBoutons();
      if (vue) afficherVue();
    }, 450);
  });

  return { ouvrir: ouvrir, fermer: fermer, afficherBoutons: afficherBoutons, active: () => !!vue, ligneTache: ligneTache, rafraichir: () => { if (vue) afficherVue(); } };
})();
