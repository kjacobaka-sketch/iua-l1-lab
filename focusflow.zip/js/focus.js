"use strict";

/* =====================================================
   focus.js : mode concentration et minuteur Pomodoro
   Travail, puis pause, en alternance. Chaque travail terminé compte dans les statistiques.
   ===================================================== */

(function () {
  const $ = (id) => document.getElementById(id);
  const panneau = $("pomodoro");
  const affichage = $("pomo-temps");
  const libelle = $("pomo-mode");
  const boutonDemarrer = $("pomo-demarrer");
  const choix = $("pomo-duree");
  const compte = $("pomo-compte");
  const titreOriginal = document.title;

  const PRESETS = { "25-5": [25, 5], "50-10": [50, 10], "15-3": [15, 3] };
  const CLE = "mes-blocs-pomodoro";

  let preset = "25-5";
  try {
    const sauve = localStorage.getItem(CLE);
    if (sauve && PRESETS[sauve]) preset = sauve;
  } catch (erreur) { /* stockage indisponible */ }
  choix.value = preset;

  let mode = "travail";    // "travail" ou "pause"
  let enCours = false;
  let fin = 0;             // heure de fin (ms) quand le minuteur tourne
  let restant = PRESETS[preset][0] * 60000;
  let intervalle = null;

  const duree = (m) => PRESETS[preset][m === "travail" ? 0 : 1] * 60000;
  const mmss = (ms) => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
  };

  function afficher() {
    affichage.textContent = mmss(restant);
    libelle.textContent = mode === "travail" ? "🎯 Travail" : "☕ Pause";
    panneau.dataset.mode = mode;
    boutonDemarrer.textContent = enCours ? "⏸ Pause" : "▶ Démarrer";
    compte.textContent = (App.etat.stats.pomodoros[App.aujourdhui()] || 0) + " aujourd'hui";
    panneau.hidden = !(enCours || document.body.classList.contains("focus"));
    document.title = enCours ? "(" + mmss(restant) + ") " + titreOriginal : titreOriginal;
    // Le titre de la page est géré ailleurs : on le restaure à l'arrêt
    if (!enCours && App.afficherEntete) App.afficherEntete();
  }

  function bip() {
    try {
      const Contexte = window.AudioContext || window.webkitAudioContext;
      const ctx = new Contexte();
      [0, 0.28, 0.56].forEach((retard) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, ctx.currentTime + retard);
        g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + retard + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + retard + 0.22);
        o.connect(g).connect(ctx.destination);
        o.start(ctx.currentTime + retard);
        o.stop(ctx.currentTime + retard + 0.25);
      });
      setTimeout(() => ctx.close(), 1500);
    } catch (erreur) { /* pas de son : tant pis */ }
  }

  function terminer() {
    arreter();
    const etaitTravail = mode === "travail";
    if (etaitTravail) {
      App.compter("pomodoros", 1);
      App.sauver();
    }
    mode = etaitTravail ? "pause" : "travail";
    restant = duree(mode);
    bip();
    const message = etaitTravail ? "Bravo ! Pause de " + PRESETS[preset][1] + " min ☕" : "La pause est finie : au travail 🎯";
    App.Toast.afficher(message, { duree: 8000 });
    if (App.etat.reglages.rappels && "Notification" in window && Notification.permission === "granted" && "serviceWorker" in navigator) {
      navigator.serviceWorker.getRegistration().then((r) => r && r.showNotification("Pomodoro", { body: message, icon: "icons/icon-192.png", tag: "pomodoro" })).catch(() => {});
    }
    afficher();
  }

  function tic() {
    restant = fin - Date.now();
    if (restant <= 0) { terminer(); return; }
    afficher();
  }

  function demarrer() {
    if (enCours) return;
    enCours = true;
    fin = Date.now() + restant;
    intervalle = setInterval(tic, 250);
    afficher();
  }

  function arreter() {
    enCours = false;
    clearInterval(intervalle);
    intervalle = null;
  }

  function pause() {
    if (!enCours) return;
    restant = fin - Date.now();
    arreter();
    afficher();
  }

  boutonDemarrer.addEventListener("click", () => (enCours ? pause() : demarrer()));

  $("pomo-reset").addEventListener("click", () => {
    arreter();
    restant = duree(mode);
    afficher();
  });

  $("pomo-passer").addEventListener("click", () => {
    arreter();
    mode = mode === "travail" ? "pause" : "travail";
    restant = duree(mode);
    afficher();
  });

  choix.addEventListener("change", () => {
    preset = choix.value;
    try { localStorage.setItem(CLE, preset); } catch (erreur) { /* ignoré */ }
    arreter();
    restant = duree(mode);
    afficher();
  });


  /* ---------- Mode focus : on cache tout sauf la page ---------- */

  function basculerFocus(actif) {
    const veut = typeof actif === "boolean" ? actif : !document.body.classList.contains("focus");
    document.body.classList.toggle("focus", veut);
    document.body.classList.remove("menu-ouvert");
    $("btn-focus").setAttribute("aria-pressed", String(veut));
    $("btn-focus").textContent = veut ? "✕ Quitter le focus" : "🎯 Focus";
    afficher();
  }

  $("btn-focus").addEventListener("click", () => basculerFocus());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && document.body.classList.contains("focus") && !document.querySelector("dialog[open]") && $("menu-bloc").hidden && $("menu-types").hidden) {
      basculerFocus(false);
    }
  });

  // Si on change de page pendant un focus, on reste en focus. En vue (Aujourd'hui…), on le quitte.
  afficher();
  App.Pomodoro = { rafraichir: afficher };
})();
