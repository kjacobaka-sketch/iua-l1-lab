"use strict";

/* =====================================================
   ui.js : outils d'interface (création d'éléments, fenêtres, dates)
   ===================================================== */

// Crée un élément en une ligne : App.el("button", { class: "x", onclick: f }, "Texte")
App.el = function (balise, props, ...enfants) {
  const e = document.createElement(balise);
  Object.keys(props || {}).forEach((k) => {
    const v = props[k];
    if (v === false || v == null) return;
    if (k === "class") e.className = v;
    else if (k === "texte") e.textContent = v;
    else if (k === "value" || k === "checked" || k === "disabled" || k === "hidden") e[k] = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  });
  enfants.flat().forEach((c) => {
    if (c == null || c === false) return;
    e.append(c.nodeType ? c : document.createTextNode(c));
  });
  return e;
};


/* ---------- Fenêtre (feuille) ---------- */

App.Feuille = (function () {
  const d = document.getElementById("feuille");
  const titre = document.getElementById("feuille-titre");
  const corps = document.getElementById("feuille-corps");
  const retour = document.getElementById("feuille-retour");
  let surFermeture = null;
  let depuisParametres = false;   // vrai quand la fenêtre a été ouverte depuis les paramètres

  function ouvrir(texteTitre, contenu, options) {
    options = options || {};
    titre.textContent = texteTitre;
    // Les listes imbriquées sont aplaties, et les valeurs vides (null) ignorées
    corps.replaceChildren(...[contenu].flat(Infinity).filter((n) => n != null && n !== false));
    d.classList.toggle("large", !!options.large);
    surFermeture = options.surFermeture || null;
    retour.hidden = !(options.retour !== undefined ? options.retour : depuisParametres && texteTitre !== "Paramètres");
    if (!d.open) d.showModal();
    corps.scrollTop = 0;
  }

  function fermer() { if (d.open) d.close(); }

  // Un toucher à côté de la fenêtre la ferme
  d.addEventListener("click", (e) => { if (e.target === d) fermer(); });
  retour.addEventListener("click", () => { if (App.Parametres) App.Parametres.ouvrir(); });
  document.getElementById("feuille-fermer").addEventListener("click", fermer);
  d.addEventListener("close", () => {
    depuisParametres = false;
    const f = surFermeture;
    surFermeture = null;
    if (f) f();
  });

  return { ouvrir: ouvrir, fermer: fermer, ouverte: () => d.open, marquerParametres: (v) => { depuisParametres = v; } };
})();


/* ---------- Petites questions (remplacent confirm() et prompt()) ----------
   Ces boîtes du navigateur sont bloquées dans certains aperçus ; les nôtres marchent partout.
   App.Confirmer("Question ?", "Supprimer")  → promesse : true ou false
   App.Demander("Titre", "Question", "valeur de départ") → promesse : texte, ou null si annulé */

App.Invite = (function () {
  const d = document.getElementById("invite");
  const form = document.getElementById("invite-form");
  const titre = document.getElementById("invite-titre");
  const texte = document.getElementById("invite-texte");
  const champ = document.getElementById("invite-champ");
  const oui = document.getElementById("invite-oui");
  const non = document.getElementById("invite-non");
  let fin = null;

  function terminer(valeur) {
    const f = fin;
    fin = null;
    if (d.open) d.close();
    if (f) f(valeur);
  }

  form.addEventListener("submit", (e) => { e.preventDefault(); terminer(champ.hidden ? true : champ.value); });
  non.addEventListener("click", () => terminer(champ.hidden ? false : null));
  d.addEventListener("cancel", (e) => { e.preventDefault(); terminer(champ.hidden ? false : null); });
  d.addEventListener("click", (e) => { if (e.target === d) terminer(champ.hidden ? false : null); });

  function ouvrir(options) {
    if (fin) terminer(null);
    titre.textContent = options.titre;
    texte.textContent = options.texte || "";
    texte.hidden = !options.texte;
    champ.hidden = !options.champ;
    champ.value = options.valeur || "";
    champ.placeholder = options.exemple || "";
    oui.textContent = options.oui || "OK";
    oui.className = options.danger ? "btn-danger" : "btn-primaire";
    return new Promise((resolve) => {
      fin = resolve;
      d.showModal();
      (options.champ ? champ : oui).focus();
    });
  }
  return { ouvrir: ouvrir };
})();

App.Confirmer = (question, libelle, danger) =>
  App.Invite.ouvrir({ titre: question, oui: libelle || "Confirmer", danger: danger !== false });
App.Demander = (titre, texte, valeur, exemple) =>
  App.Invite.ouvrir({ titre: titre, texte: texte, champ: true, valeur: valeur, exemple: exemple, oui: "Valider" });


/* ---------- Dates ---------- */

const dateDe = (iso) => new Date(iso + "T00:00:00");

App.ajouterJours = function (iso, n) {
  const d = dateDe(iso);
  d.setDate(d.getDate() + n);
  return App.iso(d);
};

App.ajouterMois = function (iso, n) {
  const d = dateDe(iso);
  const jour = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth() + n);
  const dernier = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  d.setDate(Math.min(jour, dernier));
  return App.iso(d);
};

// Écart en jours entre une date et aujourd'hui (négatif = passé)
App.ecartJours = function (iso) {
  return Math.round((dateDe(iso) - dateDe(App.aujourdhui())) / 864e5);
};

App.etiquetteDate = function (iso, heure) {
  const ecart = App.ecartJours(iso);
  let texte;
  if (ecart === 0) texte = "Aujourd'hui";
  else if (ecart === 1) texte = "Demain";
  else if (ecart === -1) texte = "Hier";
  else {
    const options = { weekday: "short", day: "numeric", month: "short" };
    if (dateDe(iso).getFullYear() !== new Date().getFullYear()) options.year = "numeric";
    texte = dateDe(iso).toLocaleDateString("fr-FR", options);
  }
  return heure ? texte + " " + heure : texte;
};

// "retard", "aujourdhui", "avenir" ou "" (pas de date, ou déjà fait)
App.statutDate = function (bloc) {
  if (bloc.type !== "tache" || !bloc.echeance || bloc.fait) return "";
  const ecart = App.ecartJours(bloc.echeance);
  return ecart < 0 ? "retard" : ecart === 0 ? "aujourdhui" : "avenir";
};

// Prochaine date d'une tâche qui se répète (jamais dans le passé)
App.prochaineEcheance = function (iso, repete) {
  const pas = (d) => (repete === "jour" ? App.ajouterJours(d, 1) : repete === "semaine" ? App.ajouterJours(d, 7) : App.ajouterMois(d, 1));
  let suivante = pas(iso);
  for (let i = 0; i < 400 && App.ecartJours(suivante) < 0; i++) suivante = pas(suivante);
  return suivante;
};

// Toutes les tâches de toutes les pages, avec leur page
App.toutesLesTaches = function () {
  const liste = [];
  App.etat.pages.forEach((page) => {
    page.blocs.forEach((bloc) => { if (bloc.type === "tache") liste.push({ page: page, bloc: bloc }); });
  });
  return liste;
};

// Télécharge un texte comme fichier
App.telecharger = function (nom, contenu, type) {
  const blob = new Blob([contenu], { type: type || "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const lien = App.el("a", { href: url, download: nom });
  document.body.append(lien);
  lien.click();
  lien.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
};
