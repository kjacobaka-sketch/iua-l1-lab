"use strict";

/* =====================================================
   modeles.js : « Nouvelle page » propose des modèles
   Chaque modèle est une petite liste : [type, texte, niveau]
   ===================================================== */

App.Modeles = (function () {
  const MODELES = [
    { cle: "vierge", icone: "📝", nom: "Page vierge", aide: "Une page vide pour commencer", couleur: null, titre: "", blocs: [["paragraphe", ""]] },
    {
      cle: "cours", icone: "📚", nom: "Semaine de cours", aide: "Un jour après l'autre, avec ses tâches", couleur: "bleu", titre: "Ma semaine de cours",
      blocs: [["paragraphe", "Note ici ce qu'il y a à faire pour chaque cours."],
        ...["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"].flatMap((j) => [["sous_titre", j], ["tache", ""]]),
        ["sous_titre", "Week-end"], ["tache", ""]],
    },
    {
      cle: "projet", icone: "🚀", nom: "Projet", aide: "Objectif, étapes, idées et ressources", couleur: "violet", titre: "Mon projet",
      blocs: [["sous_titre", "Objectif"], ["paragraphe", ""],
        ["sous_titre", "Étapes"], ["tache", "Étape 1"], ["tache", "Étape 2"], ["tache", "Étape 3"],
        ["sous_titre", "Idées"], ["liste", ""],
        ["sous_titre", "Ressources"], ["liste", ""]],
    },
    {
      cle: "examen", icone: "🎓", nom: "Révisions d'examen", aide: "Un plan de révision avec sous-tâches", couleur: "orange", titre: "Révisions",
      blocs: [["sous_titre", "Matière 1"],
        ["tache", "Relire le cours", 0], ["tache", "Chapitre 1", 1], ["tache", "Chapitre 2", 1],
        ["tache", "Refaire les exercices"], ["tache", "Faire un ancien sujet"],
        ["sous_titre", "Matière 2"], ["tache", "Relire le cours"], ["tache", "Refaire les exercices"],
        ["sous_titre", "Questions à poser"], ["liste", ""]],
    },
    {
      cle: "objectifs", icone: "🎯", nom: "Objectifs du mois", aide: "3 objectifs découpés en petites étapes", couleur: "rose", titre: "Mes objectifs",
      blocs: [["citation", "Un objectif sans date n'est qu'un souhait."],
        ["tache", "Objectif 1"], ["tache", "Première étape", 1], ["tache", "Deuxième étape", 1],
        ["tache", "Objectif 2"], ["tache", "Première étape", 1],
        ["tache", "Objectif 3"], ["tache", "Première étape", 1]],
    },
    {
      cle: "journal", icone: "🌅", nom: "Journal du jour", aide: "Priorités, notes et ce que j'ai appris", couleur: "turquoise", titre: "Journal",
      blocs: [["sous_titre", "Trois priorités"], ["tache", ""], ["tache", ""], ["tache", ""],
        ["sous_titre", "Notes"], ["paragraphe", ""],
        ["sous_titre", "Ce que j'ai appris"], ["liste", ""]],
    },
    {
      cle: "courses", icone: "🛒", nom: "Liste de courses", aide: "Des cases à cocher en magasin", couleur: "vert", titre: "Courses",
      blocs: [["tache", ""], ["tache", ""], ["tache", ""], ["tache", ""], ["tache", ""]],
    },
  ];

  function creer(modele) {
    const nombre = App.etat.pages.length;
    const page = App.nouvellePage(
      modele.titre,
      modele.couleur || App.COULEURS_PAGE[nombre % App.COULEURS_PAGE.length],
      modele.icone === "📝" ? App.ICONES[nombre % App.ICONES.length] : modele.icone
    );
    page.blocs = modele.blocs.map(([type, texte, niveau]) => {
      const b = App.nouveauBloc(type, texte);
      b.niveau = niveau || 0;
      return b;
    });
    App.etat.pages.push(page);
    App.Feuille.fermer();
    App.ouvrirPage(page.id);
    // page vierge : on écrit le titre ; modèle : on commence par le premier champ à remplir
    if (modele.cle === "vierge") document.getElementById("titre-page").focus();
    App.Toast.afficher("Page créée à partir du modèle « " + modele.nom + " »");
  }

  function ouvrir() {
    App.Feuille.ouvrir("Nouvelle page", [
      App.el("p", { class: "aide" }, "Pars d'un modèle ou d'une page vide. Tu pourras tout modifier ensuite."),
      App.el("div", { class: "modeles" }, MODELES.map((m) => App.el("button", {
        type: "button", class: "modele", "data-modele": m.cle, onclick: () => creer(m),
      },
        App.el("span", { class: "modele-icone", "aria-hidden": "true" }, m.icone),
        App.el("span", { class: "ligne-texte" }, App.el("strong", null, m.nom), App.el("small", null, m.aide))))),
    ]);
  }

  return { ouvrir: ouvrir, liste: MODELES };
})();
