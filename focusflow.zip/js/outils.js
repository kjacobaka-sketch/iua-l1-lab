"use strict";

/* =====================================================
   outils.js : petits outils (recherche, messages, confettis, thème)
   ===================================================== */

// Minuscules et sans accents : "Écrire" et "ecrire" se valent pour la recherche
App.simplifier = function (texte) {
  return String(texte || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
};

App.mouvementReduit = function () {
  if (App.etat && App.etat.reglages && App.etat.reglages.animations === false) return true;
  return !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
};


/* ---------- Message en bas d'écran (avec bouton Annuler) ---------- */

App.Toast = (function () {
  const el = document.getElementById("toast");
  let minuteur = null;

  function fermer() {
    clearTimeout(minuteur);
    el.classList.remove("visible");
  }

  function afficher(message, options) {
    options = options || {};
    clearTimeout(minuteur);

    const texte = document.createElement("span");
    texte.textContent = message;
    el.replaceChildren(texte);

    if (options.action) {
      const bouton = document.createElement("button");
      bouton.type = "button";
      bouton.textContent = options.action;
      bouton.addEventListener("click", () => {
        fermer();
        if (options.surAction) options.surAction();
      });
      el.append(bouton);
    }

    el.classList.remove("visible");
    void el.offsetWidth; // relance l'animation
    el.classList.add("visible");
    minuteur = setTimeout(fermer, options.duree || 5000);
  }

  return { afficher: afficher, fermer: fermer };
})();


/* ---------- Confettis (cochage d'une tâche, page terminée) ---------- */

App.confettis = function (element, nombre) {
  if (App.mouvementReduit() || !element) return;
  const total = nombre || 14;
  const rect = element.getBoundingClientRect();
  const cx = rect.left + Math.min(rect.width, 40) / 2;
  const cy = rect.top + rect.height / 2;
  const couleurs = ["#7c5cff", "#4ea1ff", "#3ecf8e", "#f7c948", "#ff6b9d", "#ff7a1a"];

  for (let i = 0; i < total; i++) {
    const p = document.createElement("span");
    p.className = "confetti";
    p.style.left = cx + "px";
    p.style.top = cy + "px";
    p.style.background = couleurs[i % couleurs.length];
    document.body.append(p);

    if (!p.animate) { p.remove(); continue; }

    const angle = (Math.PI * 2 * i) / total + Math.random() * 0.6;
    const distance = 30 + Math.random() * (total > 14 ? 90 : 40);
    const dx = Math.cos(angle) * distance;
    const dy = Math.sin(angle) * distance + 20;
    const animation = p.animate(
      [
        { transform: "translate(-50%, -50%) scale(1) rotate(0deg)", opacity: 1 },
        { transform: "translate(calc(-50% + " + dx + "px), calc(-50% + " + dy + "px)) scale(.4) rotate(" + Math.round(Math.random() * 360) + "deg)", opacity: 0 },
      ],
      { duration: 600 + Math.random() * 300, easing: "cubic-bezier(.2,.8,.3,1)" }
    );
    animation.onfinish = () => p.remove();
  }
};


/* ---------- Thème : auto, clair, sombre ---------- */

App.appliquerTheme = function () {
  const theme = App.etat.theme;
  const racine = document.documentElement;
  if (theme === "auto") racine.removeAttribute("data-theme");
  else racine.dataset.theme = theme;

  const bouton = document.getElementById("theme");
  if (bouton) {
    const libelles = { auto: "🌗 Thème : auto", clair: "☀️ Thème : clair", sombre: "🌙 Thème : sombre" };
    bouton.textContent = libelles[theme];
  }
};

App.definirTheme = function (theme) {
  App.etat.theme = ["auto", "clair", "sombre"].includes(theme) ? theme : "auto";
  App.sauver();
  App.appliquerTheme();
};

App.appliquerAnimations = function () {
  document.body.classList.toggle("sans-animations", App.etat.reglages.animations === false);
};

// Palette de couleurs, police et densité (réglages propres à cet appareil)
App.appliquerApparence = function () {
  const r = App.etat.reglages;
  const racine = document.documentElement;
  racine.dataset.palette = r.palette;
  racine.dataset.police = r.police;
  document.body.classList.toggle("compact", r.compact === true);
};

App.changerTheme = function () {
  const ordre = ["auto", "clair", "sombre"];
  App.etat.theme = ordre[(ordre.indexOf(App.etat.theme) + 1) % ordre.length];
  App.sauver();
  App.appliquerTheme();
};
