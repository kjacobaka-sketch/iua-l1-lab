"use strict";

/* =====================================================
   taches.js : dates limites, tags, répétition, rappels
   ===================================================== */

/* ---------- Sous-tâches ----------
   Une tâche décalée sous une autre est sa sous-tâche. La tâche parente affiche
   « 2/4 », se coche d'un coup avec toutes ses sous-tâches, et se coche toute seule
   quand la dernière sous-tâche est faite. */

function sousTaches(page, i) {
  const bl = page.blocs;
  const liste = [];
  for (let j = i + 1; j < bl.length && bl[j].niveau > bl[i].niveau; j++) {
    if (bl[j].type === "tache") liste.push(bl[j]);
  }
  return liste;
}

// La tâche parente directe (le bloc juste au-dessus, moins décalé), s'il s'agit d'une tâche
function parentDe(page, i) {
  for (let j = i - 1; j >= 0; j--) {
    if (page.blocs[j].niveau < page.blocs[i].niveau) return page.blocs[j].type === "tache" ? page.blocs[j] : null;
  }
  return null;
}

// { faits, total } pour une tâche qui a des sous-tâches, sinon null
App.progression = function (bloc) {
  const lieu = trouverBloc(bloc.id);
  if (!lieu) return null;
  const enfants = sousTaches(lieu.page, lieu.page.blocs.indexOf(bloc));
  return enfants.length ? { faits: enfants.filter((b) => b.fait).length, total: enfants.length } : null;
};

function terminer(bloc, etat) {
  if (!!bloc.fait === etat) return false;
  bloc.fait = etat;
  bloc.encours = false;
  bloc.faitLe = etat ? Date.now() : 0;
  App.compter("faits", etat ? 1 : -1);
  return true;
}


/* ---------- Cocher / décocher (aussi utilisé par les vues) ---------- */

// Coche ou décoche une tâche. Si elle se répète, elle revient avec la date suivante.
// Renvoie true quand d'autres tâches ont changé en même temps (sous-tâches, tâche parente).
App.basculerTache = function (bloc, surRecurrence) {
  const lieu = trouverBloc(bloc.id);
  let autres = false;
  terminer(bloc, !bloc.fait);

  if (lieu) {
    const i = lieu.page.blocs.indexOf(bloc);
    // Cocher la tâche parente coche toutes ses sous-tâches
    if (bloc.fait) sousTaches(lieu.page, i).forEach((s) => { if (terminer(s, true)) autres = true; });
    // Cocher la dernière sous-tâche coche le parent ; décocher une sous-tâche décoche le parent
    const parent = parentDe(lieu.page, i);
    if (parent) {
      autres = true;   // la progression « 1/2 » de la tâche parente doit se mettre à jour
      const freres = sousTaches(lieu.page, lieu.page.blocs.indexOf(parent));
      const tout = freres.every((s) => s.fait);
      terminer(parent, tout);
    }
  }
  App.sauver();

  if (bloc.fait && bloc.repete && bloc.echeance) {
    setTimeout(() => {
      if (!bloc.fait) return; // décochée entre-temps
      bloc.echeance = App.prochaineEcheance(bloc.echeance, bloc.repete);
      // la tâche revient : elle reste comptée dans les statistiques du jour où elle a été faite
      bloc.fait = false;
      bloc.faitLe = 0;
      bloc.rappele = "";
      // ... et ses sous-tâches reviennent avec elle
      const l = trouverBloc(bloc.id);
      if (l) sousTaches(l.page, l.page.blocs.indexOf(bloc)).forEach((s) => { s.fait = false; s.faitLe = 0; });
      App.sauver();
      if (surRecurrence) surRecurrence();
      App.Toast.afficher("Prochaine fois : " + App.etiquetteDate(bloc.echeance));
    }, 700);
  }
  return autres;
};


/* ---------- Pastilles sous une tâche (progression, date, tags) ---------- */

App.creerMeta = function (bloc) {
  if (bloc.type !== "tache") return null;
  const pastilles = [];
  const prog = App.progression(bloc);
  if (prog) {
    const pourcent = Math.round(prog.faits / prog.total * 100);
    pastilles.push(App.el("span", { class: "chip progression" + (prog.faits === prog.total ? " complet" : ""), title: pourcent + " % des sous-tâches faites" },
      App.el("span", { class: "mini-barre", "aria-hidden": "true" }, App.el("i", { style: "width:" + pourcent + "%" })),
      prog.faits + "/" + prog.total));
  }
  if (bloc.encours && !bloc.fait) pastilles.push(App.el("span", { class: "chip encours" }, "⏳ En cours"));
  if (bloc.echeance) {
    pastilles.push(App.el("button", {
      type: "button",
      class: "chip date " + App.statutDate(bloc),
      title: "Modifier la date",
      onclick: () => App.ouvrirDetails(bloc.id),
    }, "📅 " + App.etiquetteDate(bloc.echeance, bloc.heure) + (bloc.repete ? " 🔁" : "")));
  }
  bloc.tags.forEach((tag) => {
    pastilles.push(App.el("button", {
      type: "button", class: "chip tag", title: "Voir toutes les tâches #" + tag,
      onclick: () => App.Vues.ouvrir({ type: "tag", tag: tag }),
    }, "#" + tag));
  });
  return pastilles.length ? App.el("div", { class: "meta" }, pastilles) : null;
};


/* ---------- Fenêtre « Date, rappel, tags » ---------- */

function trouverBloc(id) {
  for (const page of App.etat.pages) {
    const bloc = page.blocs.find((b) => b.id === id);
    if (bloc) return { page: page, bloc: bloc };
  }
  return null;
}

App.tousLesTags = function () {
  const compte = {};
  App.toutesLesTaches().forEach(({ bloc }) => bloc.tags.forEach((t) => { compte[t] = (compte[t] || 0) + 1; }));
  return compte;
};

App.ouvrirDetails = function (id) {
  const trouve = trouverBloc(id);
  if (!trouve) return;
  const { page, bloc } = trouve;

  const date = App.el("input", { type: "date", value: bloc.echeance, "aria-label": "Date limite" });
  const heure = App.el("input", { type: "time", value: bloc.heure, "aria-label": "Heure du rappel" });
  const repete = App.el("select", { "aria-label": "Répétition" },
    Object.keys(App.REPETITIONS).map((cle) => App.el("option", { value: cle, selected: cle === bloc.repete }, App.REPETITIONS[cle])));
  const tags = App.el("input", {
    type: "text", value: bloc.tags.join(", "), placeholder: "cours, urgent, perso", list: "liste-tags", autocomplete: "off", "aria-label": "Tags",
  });
  const suggestions = App.el("datalist", { id: "liste-tags" },
    Object.keys(App.tousLesTags()).map((t) => App.el("option", { value: t })));

  const rapide = (texte, jours) => App.el("button", {
    type: "button", class: "btn-rapide", onclick: () => { date.value = App.ajouterJours(App.aujourdhui(), jours); },
  }, texte);

  // État des rappels
  const etatRappels = App.el("p", { class: "aide" });
  const boutonRappels = App.el("button", { type: "button", class: "btn-secondaire", onclick: async () => {
    await App.Rappels.activer();
    majRappels();
  } }, "🔔 Activer les rappels");
  function majRappels() {
    const actifs = App.Rappels.actifs();
    etatRappels.textContent = actifs
      ? "Les rappels sont activés : une notification s'affiche à l'heure choisie (8 h par défaut), tant que l'appli est ouverte."
      : "Les rappels ne sont pas activés. Un message s'affichera quand même dans l'appli à l'heure choisie.";
    boutonRappels.hidden = actifs;
  }
  majRappels();

  const enregistrer = () => {
    bloc.echeance = date.value || "";
    bloc.heure = date.value ? heure.value : "";
    bloc.repete = date.value ? repete.value : "";
    bloc.tags = [...new Set(tags.value.split(/[,;\n]/).map(App.nettoyerTag).filter(Boolean))].slice(0, 8);
    bloc.rappele = "";
    App.Feuille.fermer();
    if (page.id === App.page().id) App.afficherBlocs(null, null, id);
    else App.sauver();
  };

  App.Feuille.ouvrir("Détails de la tâche", [
    App.el("p", { class: "feuille-sous-titre" }, bloc.texte || "Tâche sans titre"),
    App.el("div", { class: "champ-form" },
      App.el("label", null, "Date limite"),
      date,
      App.el("div", { class: "rapides" }, rapide("Aujourd'hui", 0), rapide("Demain", 1), rapide("Dans 1 semaine", 7))),
    App.el("div", { class: "deux-colonnes" },
      App.el("div", { class: "champ-form" }, App.el("label", null, "Heure du rappel"), heure),
      App.el("div", { class: "champ-form" }, App.el("label", null, "Répéter"), repete)),
    App.el("div", { class: "champ-form" }, App.el("label", null, "Tags (séparés par des virgules)"), tags, suggestions),
    App.el("div", { class: "champ-form" }, etatRappels, boutonRappels),
    App.el("div", { class: "actions" },
      App.el("button", { type: "button", class: "btn-primaire", onclick: enregistrer }, "Enregistrer"),
      App.el("button", { type: "button", class: "btn-secondaire", onclick: () => { date.value = ""; heure.value = ""; repete.value = ""; } }, "Effacer la date"),
      App.el("button", { type: "button", class: "btn-secondaire", onclick: () => App.Feuille.fermer() }, "Annuler")),
  ]);
};


/* ---------- Rappels ---------- */

App.Rappels = (function () {
  const gere = "Notification" in window;

  const actifs = () => gere && Notification.permission === "granted" && !!App.etat.reglages.rappels;

  async function activer() {
    if (!gere) { App.Toast.afficher("Ce navigateur ne gère pas les notifications"); return false; }
    let permission = Notification.permission;
    if (permission === "default") permission = await Notification.requestPermission();
    App.etat.reglages.rappels = permission === "granted";
    App.sauver();
    App.Toast.afficher(permission === "granted" ? "Rappels activés 🔔"
      : "Notifications bloquées : autorise-les dans les réglages du site");
    return permission === "granted";
  }

  function desactiver() {
    App.etat.reglages.rappels = false;
    App.sauver();
  }

  function notifier(bloc, page) {
    const texte = bloc.texte || "Tâche sans titre";
    App.Toast.afficher("⏰ Rappel : " + texte, {
      action: "Voir", duree: 9000, surAction: () => App.ouvrirPage(page.id),
    });
    if (!actifs()) return;
    const titre = "⏰ " + texte;
    const options = { body: page.titre || "Sans titre", icon: "icons/icon-192.png", tag: bloc.id };
    const direct = () => { try { new Notification(titre, options); } catch (erreur) { /* Android exige le service worker */ } };
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.getRegistration()
        .then((r) => (r ? r.showNotification(titre, options) : direct()))
        .catch(direct);
    } else {
      direct();
    }
  }

  // Cherche les tâches dont l'heure est arrivée (et pas encore signalées)
  function verifier() {
    const maintenant = Date.now();
    let modifie = false;
    App.toutesLesTaches().forEach(({ page, bloc }) => {
      if (bloc.fait || !bloc.echeance) return;
      const heure = bloc.heure || "08:00";
      const cle = bloc.echeance + "T" + heure;
      if (bloc.rappele === cle) return;
      const [h, m] = heure.split(":").map(Number);
      const prevu = new Date(bloc.echeance + "T00:00:00");
      prevu.setHours(h, m, 0, 0);
      const ecart = maintenant - prevu.getTime();
      if (ecart >= 0 && ecart < 12 * 3600e3) { // on ne rappelle pas ce qui date de plus de 12 h
        bloc.rappele = cle;
        modifie = true;
        notifier(bloc, page);
      }
    });
    if (modifie) App.sauver();
  }

  setInterval(verifier, 30000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) verifier(); });
  setTimeout(verifier, 2500);

  return { activer: activer, desactiver: desactiver, actifs: actifs, verifier: verifier };
})();
