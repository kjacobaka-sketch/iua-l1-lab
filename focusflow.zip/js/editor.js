"use strict";

/* =====================================================
   editor.js : l'éditeur de blocs
   Affichage, clavier, mise en forme, blocs repliables, glisser-déposer
   ===================================================== */

(function () {
  const conteneur = document.getElementById("blocs");
  let dernierId = null;       // dernier bloc dans lequel on a écrit
  let filtreRecherche = "";   // recherche dans la page

  // Raccourcis Markdown : on tape le début, le bloc change de type
  const RACCOURCIS = [
    [/^#[ \u00a0]/, "titre"],
    [/^##[ \u00a0]/, "sous_titre"],
    [/^(\[\]|\[[ \u00a0]\])[ \u00a0]/, "tache"],
    [/^[-*][ \u00a0]/, "liste"],
    [/^1\.[ \u00a0]/, "numerotee"],
    [/^>[ \u00a0]/, "citation"],
  ];

  const blocs = () => App.page().blocs;
  const index = (id) => blocs().findIndex((b) => b.id === id);
  const lire = (zone) => zone.textContent.replace(/\u00a0/g, " ");

  // Fin (exclue) du groupe formé par un bloc et tous les blocs décalés sous lui
  function finSousArbre(i) {
    const bl = blocs();
    let j = i + 1;
    while (j < bl.length && bl[j].niveau > bl[i].niveau) j++;
    return j;
  }

  function changerType(bloc, type) {
    bloc.type = type;
    if (type === "tache") bloc.fait = !!bloc.fait;
    else delete bloc.fait;
    if (type === "separateur") { bloc.texte = ""; bloc.html = ""; }
    if (type === "image") { bloc.src = bloc.src || ""; bloc.html = ""; }
    else delete bloc.src;
    if (type !== "tache") delete bloc.encours;
  }

  // Un bloc image sans photo ouvre aussitôt le sélecteur de fichier
  function apresType(bloc) {
    if (bloc.type === "image" && !bloc.src) setTimeout(() => App.choisirImage(bloc.id), 60);
  }

  // Insère après un bloc (et après ses blocs cachés s'il est replié)
  function insererApres(id, bloc) {
    const bl = blocs();
    const i = index(id);
    if (i === -1) bl.push(bloc);
    else bl.splice(bl[i].replie ? finSousArbre(i) : i + 1, 0, bloc);
  }

  // Bloc visible voisin (les blocs repliés ne sont pas dans la page)
  function voisin(id, delta) {
    const lignes = [...conteneur.querySelectorAll(".bloc")];
    const i = lignes.findIndex((l) => l.dataset.id === id);
    const ligne = lignes[i + delta];
    return ligne ? blocs().find((b) => b.id === ligne.dataset.id) : undefined;
  }


  /* ---------- Affichage ---------- */

  // Construit la page. enregistrer = false : on redessine seulement (recherche).
  function rendu(idFocus, position, idAnime, enregistrer) {
    const bl = blocs();
    const compteurs = {};
    const lignes = [];
    let masque = null; // niveau du bloc replié qui cache les blocs suivants

    bl.forEach((bloc, i) => {
      let numero = 0;
      if (bloc.type === "numerotee") {
        compteurs[bloc.niveau] = (compteurs[bloc.niveau] || 0) + 1;
        numero = compteurs[bloc.niveau];
        Object.keys(compteurs).forEach((n) => { if (+n > bloc.niveau) delete compteurs[n]; });
      } else {
        Object.keys(compteurs).forEach((n) => { if (+n >= bloc.niveau) delete compteurs[n]; });
      }

      if (masque !== null && !filtreRecherche) {
        if (bloc.niveau > masque) return;
        masque = null;
      }
      const aEnfants = !!bl[i + 1] && bl[i + 1].niveau > bloc.niveau;
      lignes.push(creerLigne(bloc, numero, bloc.id === idAnime, aEnfants));
      if (bloc.replie && aEnfants) masque = bloc.niveau;
    });

    conteneur.replaceChildren(...lignes);
    if (enregistrer) App.sauver();
    App.majProgres(false);
    appliquerRecherche();
    if (idFocus) focaliser(idFocus, position);
  }

  function afficher(idFocus, position, idAnime) { rendu(idFocus, position, idAnime, true); }
  App.afficherBlocs = afficher;

  function creerLigne(bloc, numero, anime, aEnfants) {
    const ligne = document.createElement("div");
    ligne.className = "bloc bloc-" + bloc.type;
    ligne.dataset.id = bloc.id;
    ligne.dataset.niveau = bloc.niveau;
    ligne.style.setProperty("--niveau", bloc.niveau);
    if (bloc.couleur) ligne.dataset.teinte = bloc.couleur;
    if (bloc.fait) ligne.classList.add("fait");
    if (anime && !App.mouvementReduit()) ligne.classList.add("entree");

    // Poignée : glisser pour déplacer, toucher pour ouvrir les options
    const poignee = document.createElement("button");
    poignee.type = "button";
    poignee.className = "poignee";
    poignee.innerHTML = '<svg viewBox="0 0 10 16" aria-hidden="true"><circle cx="2.5" cy="3" r="1.5"/><circle cx="7.5" cy="3" r="1.5"/><circle cx="2.5" cy="8" r="1.5"/><circle cx="7.5" cy="8" r="1.5"/><circle cx="2.5" cy="13" r="1.5"/><circle cx="7.5" cy="13" r="1.5"/></svg>';
    poignee.setAttribute("aria-label", "Options du bloc (glisser pour déplacer)");
    poignee.addEventListener("pointerdown", (e) => glisser(e, bloc.id, ligne, poignee));
    ligne.append(poignee);

    // Flèche pour replier les blocs décalés sous celui-ci
    const zoneRepli = document.createElement("span");
    zoneRepli.className = "repli-zone";
    if (aEnfants) {
      const fleche = document.createElement("button");
      fleche.type = "button";
      fleche.className = "repli" + (bloc.replie ? " replie" : "");
      fleche.setAttribute("aria-expanded", String(!bloc.replie));
      fleche.setAttribute("aria-label", bloc.replie ? "Déplier" : "Replier");
      fleche.innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5l3 3 3-3"/></svg>';
      fleche.addEventListener("click", () => App.basculerRepli(bloc.id));
      zoneRepli.append(fleche);
    }
    ligne.append(zoneRepli);

    const contenu = document.createElement("div");
    contenu.className = "contenu";

    // Marque à gauche selon le type
    if (bloc.type === "tache") {
      const caseACocher = document.createElement("button");
      caseACocher.type = "button";
      caseACocher.className = "case";
      caseACocher.setAttribute("role", "checkbox");
      caseACocher.setAttribute("aria-checked", String(!!bloc.fait));
      caseACocher.setAttribute("aria-label", "Tâche terminée");
      caseACocher.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
      caseACocher.addEventListener("click", () => cocher(bloc, ligne, caseACocher));
      contenu.append(caseACocher);
    } else if (bloc.type === "liste") {
      const puce = document.createElement("span");
      puce.className = "puce";
      puce.textContent = "•";
      contenu.append(puce);
    } else if (bloc.type === "numerotee") {
      const num = document.createElement("span");
      num.className = "numero";
      num.textContent = numero + ".";
      contenu.append(num);
    }

    if (bloc.type === "separateur") {
      const sep = document.createElement("div");
      sep.className = "sep champ";
      sep.tabIndex = 0;
      sep.setAttribute("aria-label", "Séparateur");
      sep.append(document.createElement("hr"));
      sep.addEventListener("focus", () => { dernierId = bloc.id; ligne.classList.add("actif"); });
      sep.addEventListener("blur", () => ligne.classList.remove("actif"));
      sep.addEventListener("keydown", (e) => gererSeparateur(e, bloc));
      contenu.append(sep);
    } else if (bloc.type === "image") {
      // Une photo, puis sa légende (modifiable comme un texte)
      const corps = document.createElement("div");
      corps.className = "corps";
      corps.append(creerFigure(bloc), creerZone(bloc, ligne));
      contenu.append(corps);
    } else {
      // Le texte, puis (pour les tâches) la date et les tags en dessous
      const corps = document.createElement("div");
      corps.className = "corps";
      corps.append(creerZone(bloc, ligne));
      const meta = App.creerMeta ? App.creerMeta(bloc) : null;
      if (meta) corps.append(meta);
      contenu.append(corps);

      if (bloc.type === "tache") {
        const detail = document.createElement("button");
        detail.type = "button";
        detail.className = "detail";
        detail.textContent = "📅";
        detail.setAttribute("aria-label", "Date, rappel et tags");
        detail.addEventListener("click", () => App.ouvrirDetails(bloc.id));
        contenu.append(detail);
      }
    }

    ligne.append(contenu);
    return ligne;
  }

  // La photo d'un bloc image (ou un bouton pour en choisir une)
  function creerFigure(bloc) {
    const figure = document.createElement("div");
    figure.className = "figure";
    if (bloc.src) {
      const bouton = document.createElement("button");
      bouton.type = "button";
      bouton.className = "figure-image";
      bouton.setAttribute("aria-label", "Agrandir l'image");
      const img = document.createElement("img");
      img.alt = bloc.texte || "Image";
      img.loading = "lazy";
      if (App.ImagesDB && App.ImagesDB.estRef(bloc.src)) {
        img.dataset.idbRef = bloc.src;
        const url = App.ImagesDB.obtenirSync(bloc.src);
        if (url) img.src = url;
        else App.ImagesDB.obtenir(bloc.src).then((data) => { if (data && img.isConnected) img.src = data; });
      } else {
        img.src = bloc.src;
      }
      bouton.append(img);
      bouton.addEventListener("click", () => App.agrandirImage(bloc));
      figure.append(bouton);
    } else {
      const choisir = document.createElement("button");
      choisir.type = "button";
      choisir.className = "figure-vide";
      choisir.innerHTML = '<span aria-hidden="true">🖼</span> Choisir une image';
      choisir.addEventListener("click", () => App.choisirImage(bloc.id));
      figure.append(choisir);
    }
    return figure;
  }

  // Coche ou décoche une tâche (et relance les tâches qui se répètent)
  function cocher(bloc, ligne, bouton) {
    const autres = App.basculerTache(bloc, () => afficher(null, null, bloc.id));
    ligne.classList.toggle("fait", bloc.fait);
    bouton.setAttribute("aria-checked", String(bloc.fait));
    App.majProgres(true);
    if (bloc.fait) App.confettis(bouton, 14);
    // d'autres tâches ont changé (sous-tâches ou tâche parente) : on redessine après l'animation
    if (autres) setTimeout(() => afficher(null, null, null), 320);
  }

  function creerZone(bloc, ligne) {
    const zone = document.createElement("div");
    zone.className = "texte champ";
    zone.contentEditable = "true";
    zone.setAttribute("role", "textbox");
    zone.setAttribute("aria-label", App.TYPES[bloc.type].nom);
    zone.dataset.placeholder = App.TYPES[bloc.type].placeholder;
    if (bloc.html) zone.innerHTML = bloc.html; // déjà nettoyé par App.assainir
    else zone.textContent = bloc.texte;        // textContent : jamais de HTML injecté

    zone.addEventListener("focus", () => { dernierId = bloc.id; ligne.classList.add("actif"); });
    zone.addEventListener("blur", () => ligne.classList.remove("actif"));

    // Un lien s'ouvre d'un toucher, sauf si on était déjà en train d'écrire dans ce bloc
    zone.addEventListener("pointerdown", () => { zone._etaitActif = document.activeElement === zone; });
    zone.addEventListener("click", (e) => {
      const lien = e.target.closest && e.target.closest("a");
      if (lien && (!zone._etaitActif || e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        window.open(lien.href, "_blank", "noopener,noreferrer");
      }
    });

    zone.addEventListener("input", () => {
      bloc.texte = lire(zone);
      bloc.html = zone.querySelector("b,i,u,s,code,a") ? App.assainir(zone.innerHTML) : "";
      if (bloc.texte === "") { zone.innerHTML = ""; bloc.html = ""; } // retire le <br> laissé par le navigateur

      // Raccourcis Markdown ("- " devient une liste, etc.)
      if (bloc.type === "paragraphe") {
        for (const [regle, type] of RACCOURCIS) {
          if (regle.test(bloc.texte)) {
            bloc.texte = bloc.texte.replace(regle, "");
            bloc.html = "";
            changerType(bloc, type);
            afficher(bloc.id, "fin");
            return;
          }
        }
      }

      // Menu "/" : s'ouvre quand le bloc contient seulement "/mot"
      const slash = /^\/([^\s]*)$/.exec(bloc.texte);
      if (slash) {
        App.MenuTypes.ouvrir(ligne, slash[1], (type) => {
          bloc.texte = "";
          bloc.html = "";
          changerType(bloc, type);
          afficher(bloc.id, "fin");
          apresType(bloc);
        }, "slash");
      } else if (App.MenuTypes.ouvert() && App.MenuTypes.origine() === "slash") {
        App.MenuTypes.fermer();
      }

      App.sauver();
    });

    zone.addEventListener("keydown", (e) => gererTouche(e, bloc, zone));

    // Collage en texte brut. Plusieurs lignes collées = plusieurs blocs.
    zone.addEventListener("paste", (e) => {
      e.preventDefault();
      const brut = (e.clipboardData || window.clipboardData).getData("text/plain").replace(/\r/g, "");
      const lignes = brut.split("\n");
      document.execCommand("insertText", false, lignes[0]);
      if (lignes.length > 1) {
        bloc.texte = lire(zone);
        bloc.html = zone.querySelector("b,i,u,s,code,a") ? App.assainir(zone.innerHTML) : "";
        const type = App.TYPES_LISTE.includes(bloc.type) ? bloc.type : "paragraphe";
        let precedent = bloc.id;
        lignes.slice(1).filter((l) => l.trim() !== "").forEach((l) => {
          const nouveau = App.nouveauBloc(type, l.trim());
          nouveau.niveau = bloc.niveau;
          insererApres(precedent, nouveau);
          precedent = nouveau.id;
        });
        afficher(precedent, "fin");
      }
    });

    return zone;
  }


  /* ---------- Curseur ---------- */

  // Positions de début et de fin de la sélection, comptées en caractères
  function positionCurseur(zone) {
    const sel = window.getSelection();
    const longueur = zone.textContent.length;
    if (!sel || sel.rangeCount === 0 || !zone.contains(sel.anchorNode)) {
      return { debut: longueur, fin: longueur, longueur: longueur };
    }
    const r = sel.getRangeAt(0);
    const avantDebut = document.createRange();
    avantDebut.selectNodeContents(zone);
    avantDebut.setEnd(r.startContainer, r.startOffset);
    const avantFin = document.createRange();
    avantFin.selectNodeContents(zone);
    avantFin.setEnd(r.endContainer, r.endOffset);
    return { debut: avantDebut.toString().length, fin: avantFin.toString().length, longueur: longueur };
  }

  // Place le curseur à un nombre de caractères du début (le texte peut contenir du gras, des liens…)
  function placerCurseur(champ, n) {
    const parcours = document.createTreeWalker(champ, NodeFilter.SHOW_TEXT);
    let reste = n;
    let noeud = parcours.nextNode();
    const plage = document.createRange();
    while (noeud) {
      if (reste <= noeud.textContent.length) {
        plage.setStart(noeud, reste);
        plage.collapse(true);
        return plage;
      }
      reste -= noeud.textContent.length;
      noeud = parcours.nextNode();
    }
    plage.selectNodeContents(champ);
    plage.collapse(false);
    return plage;
  }

  function focaliser(id, position) {
    const champ = conteneur.querySelector('.bloc[data-id="' + id + '"] .champ');
    if (!champ) return;
    champ.focus({ preventScroll: false });
    if (champ.classList.contains("sep")) return;

    let plage;
    if (position === "debut") {
      plage = document.createRange();
      plage.selectNodeContents(champ);
      plage.collapse(true);
    } else if (typeof position === "number") {
      plage = placerCurseur(champ, position);
    } else {
      plage = document.createRange();
      plage.selectNodeContents(champ);
      plage.collapse(false);
    }
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(plage);
  }
  App.focaliser = focaliser;

  App.curseurActuel = function () {
    const actif = document.activeElement;
    if (actif && actif.classList && actif.classList.contains("texte") && conteneur.contains(actif)) {
      return { id: actif.closest(".bloc").dataset.id, pos: positionCurseur(actif).debut };
    }
    return null;
  };


  /* ---------- Clavier ---------- */

  function gererTouche(e, bloc, zone) {
    const menu = App.MenuTypes;

    // Navigation dans le menu "/"
    if (menu.ouvert() && menu.origine() === "slash") {
      if (e.key === "ArrowDown") { e.preventDefault(); menu.bouger(1); return; }
      if (e.key === "ArrowUp") { e.preventDefault(); menu.bouger(-1); return; }
      if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); menu.valider(); return; }
      if (e.key === "Escape") { e.preventDefault(); menu.fermer(); return; }
    }

    const pos = positionCurseur(zone);

    // Entrée : nouveau bloc (coupe le texte à l'endroit du curseur)
    if (e.key === "Enter") {
      e.preventDefault();

      // "---" puis Entrée : séparateur
      if (bloc.texte.trim() === "---") {
        bloc.html = "";
        changerType(bloc, "separateur");
        const suite = App.nouveauBloc("paragraphe");
        insererApres(bloc.id, suite);
        afficher(suite.id, "debut", bloc.id);
        return;
      }

      // Entrée sur une liste ou une tâche vide : on en sort (comme Notion)
      const vide = bloc.texte === "";
      if (vide && (App.TYPES_LISTE.includes(bloc.type) || bloc.type === "citation")) {
        if (bloc.niveau > 0) bloc.niveau--;
        else changerType(bloc, "paragraphe");
        afficher(bloc.id, "fin");
        return;
      }

      // Découpe le contenu DOM à l'endroit du curseur pour préserver gras, italique, liens, etc.
      const sel = window.getSelection();
      let r;
      if (sel && sel.rangeCount > 0 && zone.contains(sel.anchorNode)) {
        r = sel.getRangeAt(0).cloneRange();
      } else {
        r = document.createRange();
        r.selectNodeContents(zone);
        r.collapse(false);
      }
      if (!r.collapsed) r.deleteContents();
      const plageApres = document.createRange();
      plageApres.setStart(r.endContainer, r.endOffset);
      plageApres.setEnd(zone, zone.childNodes.length);
      const fragApres = plageApres.extractContents();
      const contApres = document.createElement("div");
      contApres.append(fragApres);

      const avant = lire(zone);
      const apres = lire(contApres);
      bloc.texte = avant;
      bloc.html = avant && zone.querySelector("b,i,u,s,code,a") ? App.assainir(zone.innerHTML) : "";

      const type = App.TYPES_LISTE.includes(bloc.type) ? bloc.type : "paragraphe";
      const nouveau = App.nouveauBloc(type, apres);
      nouveau.html = apres && contApres.querySelector("b,i,u,s,code,a") ? App.assainir(contApres.innerHTML) : "";
      nouveau.niveau = bloc.niveau;
      insererApres(bloc.id, nouveau);
      afficher(nouveau.id, "debut", nouveau.id);
      return;
    }

    // Tab / Maj+Tab : décaler le bloc
    if (e.key === "Tab") {
      e.preventDefault();
      if (App.indenter(bloc.id, e.shiftKey ? -1 : 1)) afficher(bloc.id, pos.debut);
      return;
    }

    // Retour arrière au début d'un bloc
    if (e.key === "Backspace" && pos.debut === 0 && pos.fin === 0) {
      if (bloc.type === "image") { e.preventDefault(); return; }   // l'image se supprime par le menu du bloc
      const avantLui = voisin(bloc.id, -1);
      if (avantLui && avantLui.type === "image") {
        e.preventDefault();
        if (bloc.texte === "" && bloc.type === "paragraphe") blocs().splice(index(bloc.id), 1);
        afficher(avantLui.id, "fin");
        return;
      }
      if (bloc.niveau > 0) {
        e.preventDefault();
        if (App.indenter(bloc.id, -1)) afficher(bloc.id, 0);
        return;
      }
      if (bloc.type !== "paragraphe") {
        e.preventDefault();
        changerType(bloc, "paragraphe");
        afficher(bloc.id, 0);
        return;
      }
      const precedent = voisin(bloc.id, -1);
      if (precedent) {
        e.preventDefault();
        if (precedent.type === "separateur") {
          blocs().splice(index(precedent.id), 1);
          afficher(bloc.id, 0);
        } else {
          const longueur = precedent.texte.length;
          if (precedent.html || bloc.html) {
            const fusion = document.createElement("div");
            if (precedent.html) fusion.innerHTML = precedent.html;
            else fusion.textContent = precedent.texte;
            const suite = document.createElement("div");
            if (bloc.html) suite.innerHTML = bloc.html;
            else suite.textContent = bloc.texte;
            while (suite.firstChild) fusion.append(suite.firstChild);
            precedent.texte += bloc.texte;
            precedent.html = precedent.texte && fusion.querySelector("b,i,u,s,code,a") ? App.assainir(fusion.innerHTML) : "";
          } else {
            precedent.texte += bloc.texte;
          }
          blocs().splice(index(bloc.id), 1);
          afficher(precedent.id, longueur);
        }
      }
      return;
    }

    // Flèches : passer d'un bloc à l'autre
    if (e.key === "ArrowUp" && pos.debut === 0 && pos.fin === 0 && !e.shiftKey) {
      const v = voisin(bloc.id, -1);
      if (v) { e.preventDefault(); focaliser(v.id, "fin"); }
    }
    if (e.key === "ArrowDown" && pos.debut === pos.longueur && pos.fin === pos.longueur && !e.shiftKey) {
      const v = voisin(bloc.id, 1);
      if (v) { e.preventDefault(); focaliser(v.id, "debut"); }
    }
  }

  function gererSeparateur(e, bloc) {
    if (e.key === "Backspace" || e.key === "Delete") {
      e.preventDefault();
      App.supprimerBloc(bloc.id);
    } else if (e.key === "Enter") {
      e.preventDefault();
      const suite = App.nouveauBloc("paragraphe");
      insererApres(bloc.id, suite);
      afficher(suite.id, "fin", suite.id);
    } else if (e.key === "ArrowUp" || e.key === "ArrowDown") {
      const v = voisin(bloc.id, e.key === "ArrowUp" ? -1 : 1);
      if (v) { e.preventDefault(); focaliser(v.id, e.key === "ArrowUp" ? "fin" : "debut"); }
    }
  }


  /* ---------- Actions sur les blocs (aussi utilisées par les menus) ---------- */

  // Ajoute un bloc du type donné sous le bloc en cours
  App.ajouterBloc = function (type) {
    const courant = blocs().find((b) => b.id === dernierId);

    // Un paragraphe vide est simplement transformé, pour ne pas empiler des blocs vides
    if (courant && courant.type === "paragraphe" && courant.texte === "" && type !== "separateur") {
      changerType(courant, type);
      afficher(courant.id, "fin", courant.id);
      apresType(courant);
      return;
    }

    const nouveau = App.nouveauBloc(type);
    if (courant && App.TYPES_LISTE.includes(type)) nouveau.niveau = courant.niveau;
    if (courant) insererApres(courant.id, nouveau);
    else blocs().push(nouveau);

    if (type === "separateur") {
      const suite = App.nouveauBloc("paragraphe");
      insererApres(nouveau.id, suite);
      afficher(suite.id, "fin", nouveau.id);
    } else {
      afficher(nouveau.id, "fin", nouveau.id);
      apresType(nouveau);
    }
  };

  App.convertir = function (id, type) {
    const bloc = blocs()[index(id)];
    if (!bloc) return;
    if (type === "separateur") bloc.html = "";
    changerType(bloc, type);
    afficher(null, null, id);
    apresType(bloc);
  };

  // Décale un bloc, avec tous les blocs qui lui sont rattachés (delta = 1 ou -1)
  App.indenter = function (id, delta) {
    const bl = blocs();
    const i = index(id);
    const bloc = bl[i];
    if (!bloc) return false;
    const maximum = i === 0 ? 0 : Math.min(3, bl[i - 1].niveau + 1);
    const niveau = Math.max(0, Math.min(maximum, bloc.niveau + delta));
    if (niveau === bloc.niveau) return false;
    const d = niveau - bloc.niveau;
    const fin = finSousArbre(i);
    for (let j = i + 1; j < fin; j++) {
      if (bl[j].niveau + d > 3 || bl[j].niveau + d < 0) return false;
    }
    for (let j = i; j < fin; j++) bl[j].niveau += d;
    return true;
  };

  App.decaler = function (id, delta) {
    if (App.indenter(id, delta)) afficher(null, null, id);
  };

  // Monte ou descend un bloc avec ses blocs rattachés
  App.deplacer = function (id, delta) {
    const bl = blocs();
    const i = index(id);
    if (i === -1) return;
    const fin = finSousArbre(i);
    let cible;
    if (delta < 0) {
      cible = i - 1;
      while (cible > 0 && bl[cible].niveau > bl[i].niveau) cible--;
      if (cible < 0) return;
    } else {
      if (fin >= bl.length) return;
      cible = finSousArbre(fin);
    }
    const groupe = bl.splice(i, fin - i);
    bl.splice(delta < 0 ? cible : cible - groupe.length, 0, ...groupe);
    afficher(null, null, id);
  };

  App.dupliquer = function (id) {
    const i = index(id);
    if (i === -1) return;
    const copie = JSON.parse(JSON.stringify(blocs()[i]));
    copie.id = App.id();
    copie.replie = false;
    copie.rappele = "";
    blocs().splice(i + 1, 0, copie);
    afficher(null, null, copie.id);
  };

  App.colorer = function (id, couleur) {
    const bloc = blocs()[index(id)];
    if (!bloc) return;
    bloc.couleur = couleur || "";
    afficher(null, null, id);
  };

  App.basculerRepli = function (id) {
    const bloc = blocs()[index(id)];
    if (!bloc) return;
    bloc.replie = !bloc.replie;
    afficher();
  };

  // Supprime un bloc (et ses blocs repliés), l'envoie à la corbeille, propose d'annuler
  App.supprimerBloc = function (id) {
    const bl = blocs();
    const i = index(id);
    if (i === -1) return;
    const fin = bl[i].replie ? finSousArbre(i) : i + 1;
    const supprimes = bl.slice(i, fin);
    const etaitSeul = supprimes.length === bl.length;
    const page = App.page();
    const ligne = conteneur.querySelector('.bloc[data-id="' + id + '"]');
    const idCorbeille = App.id();

    const terminer = () => {
      bl.splice(i, fin - i);
      if (bl.length === 0) bl.push(App.nouveauBloc("paragraphe"));
      if (supprimes.some((b) => b.texte.trim() !== "" || b.type === "separateur" || (b.type === "image" && !!b.src))) {
        App.etat.corbeille.unshift({
          id: idCorbeille, kind: "bloc", date: Date.now(),
          pageId: page.id, pageTitre: page.titre, index: i, data: supprimes,
        });
      }
      afficher((bl[i - 1] || bl[0]).id, "fin");
      App.Toast.afficher(supprimes.length > 1 ? supprimes.length + " blocs supprimés" : "Bloc supprimé", {
        action: "Annuler",
        surAction: () => {
          App.etat.corbeille = App.etat.corbeille.filter((e) => e.id !== idCorbeille);
          if (etaitSeul) bl.splice(0, bl.length);
          bl.splice(Math.min(i, bl.length), 0, ...supprimes);
          afficher(supprimes[0].id, "fin", supprimes[0].id);
        },
      });
    };

    if (ligne && !App.mouvementReduit()) {
      ligne.classList.add("sortie");
      setTimeout(terminer, 180);
    } else {
      terminer();
    }
  };


  /* ---------- Recherche dans la page ---------- */

  function appliquerRecherche() {
    const q = App.simplifier(filtreRecherche);
    conteneur.classList.toggle("en-recherche", !!q);
    let trouves = 0;
    conteneur.querySelectorAll(".bloc").forEach((ligne) => {
      const bloc = blocs().find((b) => b.id === ligne.dataset.id);
      const ok = !q || (bloc && App.simplifier(bloc.texte + " " + (bloc.tags || []).join(" ")).includes(q));
      ligne.classList.toggle("masque-recherche", !ok);
      ligne.classList.toggle("trouve", !!q && ok);
      if (q && ok) trouves++;
    });
    if (App.majCompteurRecherche) App.majCompteurRecherche(q ? trouves : null);
  }

  App.rechercherDansPage = function (q) {
    const avait = !!filtreRecherche;
    filtreRecherche = q;
    if (avait !== !!q) rendu(null, null, null, false); // les blocs repliés réapparaissent pendant la recherche
    else appliquerRecherche();
  };
  App.effacerRecherche = function () { filtreRecherche = ""; };


  /* ---------- Glisser-déposer (souris et doigt) ---------- */

  function glisser(e, id, ligne, poignee) {
    if (e.button) return; // clic droit ou autre : on ignore
    e.preventDefault();
    poignee.setPointerCapture(e.pointerId);

    const departY = e.clientY;
    const departDefilement = window.scrollY;
    let bouge = false;
    let cible = null; // bloc devant lequel on insère (null = à la fin)

    const autres = () => [...conteneur.querySelectorAll(".bloc")].filter((l) => l !== ligne);
    const nettoyer = () => {
      conteneur.querySelectorAll(".cible-avant").forEach((l) => l.classList.remove("cible-avant"));
      conteneur.classList.remove("cible-fin");
      ligne.classList.remove("deplace");
      ligne.style.transform = "";
      document.body.classList.remove("glisse");
    };

    function surMouvement(ev) {
      const dy = ev.clientY - departY + (window.scrollY - departDefilement);
      if (!bouge && Math.abs(dy) > 6) {
        bouge = true;
        ligne.classList.add("deplace");
        document.body.classList.add("glisse");
        App.MenuBloc.fermer();
      }
      if (!bouge) return;

      ligne.style.transform = "translateY(" + dy + "px) scale(1.02)";
      const r = ligne.getBoundingClientRect();
      const centre = r.top + r.height / 2;

      cible = null;
      for (const l of autres()) {
        const rr = l.getBoundingClientRect();
        if (centre < rr.top + rr.height / 2) { cible = l; break; }
      }
      conteneur.querySelectorAll(".cible-avant").forEach((l) => l.classList.remove("cible-avant"));
      conteneur.classList.remove("cible-fin");
      if (cible) cible.classList.add("cible-avant");
      else conteneur.classList.add("cible-fin");

      // Défilement automatique près des bords de l'écran
      if (ev.clientY < 90) window.scrollBy(0, -14);
      else if (ev.clientY > window.innerHeight - 130) window.scrollBy(0, 14);
    }

    function terminer(annule) {
      poignee.removeEventListener("pointermove", surMouvement);
      poignee.removeEventListener("pointerup", surFin);
      poignee.removeEventListener("pointercancel", surAnnulation);
      const idCible = cible ? cible.dataset.id : null;
      nettoyer();

      if (annule) return;
      if (!bouge) {
        App.MenuBloc.ouvrir(id, poignee); // simple toucher : menu du bloc
        return;
      }
      const bl = blocs();
      const i = index(id);
      const fin = finSousArbre(i);
      const groupe = bl.slice(i, fin);
      if (idCible && groupe.some((b) => b.id === idCible)) return; // déposé sur ses propres blocs rattachés
      bl.splice(i, fin - i);
      const j = idCible ? bl.findIndex((b) => b.id === idCible) : -1;
      if (j === -1) bl.push(...groupe);
      else bl.splice(j, 0, ...groupe);
      afficher(null, null, id);
    }
    const surFin = () => terminer(false);
    const surAnnulation = () => terminer(true);

    poignee.addEventListener("pointermove", surMouvement);
    poignee.addEventListener("pointerup", surFin);
    poignee.addEventListener("pointercancel", surAnnulation);
  }


  /* ---------- Barre de mise en forme (sur le texte sélectionné) ---------- */

  const barreFormat = document.getElementById("format");

  function zoneSelectionnee() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    const noeud = sel.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement);
    const zone = noeud && noeud.closest(".texte");
    return zone && conteneur.contains(zone) && zone.contains(sel.focusNode) ? zone : null;
  }

  document.addEventListener("selectionchange", () => {
    if (!zoneSelectionnee()) { barreFormat.hidden = true; return; }
    const r = window.getSelection().getRangeAt(0).getBoundingClientRect();
    if (!r.width && !r.height) { barreFormat.hidden = true; return; }
    barreFormat.hidden = false;
    const largeur = barreFormat.offsetWidth;
    const gauche = Math.max(8, Math.min(r.left + r.width / 2 - largeur / 2, window.innerWidth - largeur - 8));
    barreFormat.style.left = gauche + "px";
    barreFormat.style.top = Math.min(r.bottom + 10, window.innerHeight - 60) + "px";
  });

  barreFormat.addEventListener("mousedown", (e) => e.preventDefault()); // garde la sélection
  barreFormat.addEventListener("click", async (e) => {
    const bouton = e.target.closest("[data-format]");
    if (!bouton || !zoneSelectionnee()) return;
    const format = bouton.dataset.format;
    const sel = window.getSelection();

    if (format === "code") {
      const texte = sel.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      document.execCommand("insertHTML", false, "<code>" + texte + "</code>");
    } else if (format === "link") {
      const plage = sel.getRangeAt(0).cloneRange();
      const saisie = await App.Demander("Ajouter un lien", "Adresse du lien (par exemple https://exemple.com)", "", "https://");
      sel.removeAllRanges();
      sel.addRange(plage);
      if (saisie && saisie.trim()) {
        const url = /^(https?:|mailto:)/i.test(saisie.trim()) ? saisie.trim() : "https://" + saisie.trim();
        document.execCommand("createLink", false, url);
      }
    } else {
      document.execCommand(format);
    }
  });


  /* ---------- Barre du bas et bouton "Ajouter un bloc" ---------- */

  document.querySelectorAll(".barre [data-type]").forEach((bouton) => {
    bouton.addEventListener("mousedown", (e) => e.preventDefault()); // garde le curseur dans le bloc
    bouton.addEventListener("click", () => App.ajouterBloc(bouton.dataset.type));
  });

  const boutonPlus = document.getElementById("plus-types");
  boutonPlus.addEventListener("mousedown", (e) => e.preventDefault());
  boutonPlus.addEventListener("click", () => {
    App.MenuTypes.ouvrir(boutonPlus, "", (type) => App.ajouterBloc(type), "inserer");
  });

  document.getElementById("ajouter-fin").addEventListener("click", () => {
    const bl = blocs();
    const dernier = bl[bl.length - 1];
    if (dernier.type === "paragraphe" && dernier.texte === "") {
      focaliser(dernier.id, "fin");
    } else {
      const nouveau = App.nouveauBloc("paragraphe");
      bl.push(nouveau);
      afficher(nouveau.id, "fin", nouveau.id);
    }
  });
})();
