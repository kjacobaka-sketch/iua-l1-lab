"use strict";

/* =====================================================
   vuesplus.js : la vue « Tableau » (Kanban) et la vue « Calendrier »
   Elles rassemblent les tâches de toutes les pages, comme « Aujourd'hui ».
   ===================================================== */

App.VuesPlus = (function () {
  const MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  const JOURS = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"];

  /* ---------- Tableau : À faire / En cours / Terminé ---------- */

  const COLONNES = [
    { cle: "afaire", titre: "À faire", icone: "📋" },
    { cle: "encours", titre: "En cours", icone: "⏳" },
    { cle: "fait", titre: "Terminé", icone: "✅" },
  ];
  const MAX_TERMINEES = 30;

  const statutDe = (bloc) => (bloc.fait ? "fait" : bloc.encours ? "encours" : "afaire");

  // Change le statut d'une tâche : à faire, en cours ou fait
  function definirStatut(bloc, statut) {
    if (statutDe(bloc) === statut) return;
    if (statut === "fait") {
      App.basculerTache(bloc, App.Vues.rafraichir);   // coche (et gère sous-tâches, répétition, statistiques)
    } else {
      if (bloc.fait) App.basculerTache(bloc, App.Vues.rafraichir);
      bloc.encours = statut === "encours";
      App.sauver();
    }
    App.Vues.rafraichir();
  }

  function carte(page, bloc) {
    const statut = statutDe(bloc);
    const segment = COLONNES.map((c) => App.el("button", {
      type: "button",
      class: "etat" + (statut === c.cle ? " actif" : ""),
      "aria-pressed": String(statut === c.cle),
      title: c.titre,
      onclick: () => definirStatut(bloc, c.cle),
    }, c.icone));

    const prog = App.progression(bloc);
    return App.el("article", { class: "carte-tache" + (bloc.fait ? " fait" : ""), "data-statut": statut },
      App.el("button", {
        type: "button", class: "carte-texte", title: "Ouvrir la page",
        onclick: () => { App.ouvrirPage(page.id); setTimeout(() => App.focaliser(bloc.id, "fin"), 60); },
      }, bloc.texte || "Tâche sans titre"),
      App.el("div", { class: "meta" },
        App.el("span", { class: "chip page-chip" }, page.icone + " " + (page.titre || "Sans titre")),
        prog ? App.el("span", { class: "chip progression" }, prog.faits + "/" + prog.total) : null,
        bloc.echeance ? App.el("span", { class: "chip date " + App.statutDate(bloc) }, "📅 " + App.etiquetteDate(bloc.echeance, bloc.heure)) : null),
      App.el("div", { class: "etats", role: "group", "aria-label": "Statut de la tâche" }, segment));
  }

  function tableau() {
    const toutes = App.toutesLesTaches();
    const parColonne = { afaire: [], encours: [], fait: [] };
    toutes.forEach((t) => parColonne[statutDe(t.bloc)].push(t));
    const parDate = (a, b) => (a.bloc.echeance || "9999").localeCompare(b.bloc.echeance || "9999");
    parColonne.afaire.sort(parDate);
    parColonne.encours.sort(parDate);
    parColonne.fait.sort((a, b) => (b.bloc.faitLe || 0) - (a.bloc.faitLe || 0));

    const colonnes = COLONNES.map((c) => {
      const liste = parColonne[c.cle];
      const visibles = c.cle === "fait" ? liste.slice(0, MAX_TERMINEES) : liste;
      return App.el("section", { class: "colonne", "data-colonne": c.cle, "aria-label": c.titre },
        App.el("h2", { class: "colonne-titre" }, c.icone + " " + c.titre, App.el("span", { class: "colonne-compte" }, String(liste.length))),
        visibles.length ? visibles.map((t) => carte(t.page, t.bloc)) : App.el("p", { class: "colonne-vide" }, c.cle === "afaire" ? "Rien à faire 🎉" : c.cle === "encours" ? "Appuie sur ⏳ pour commencer une tâche" : "Rien de terminé pour l'instant"),
        liste.length > visibles.length ? App.el("p", { class: "colonne-vide" }, "… et " + (liste.length - visibles.length) + " autres") : null);
    });

    const total = toutes.length;
    return {
      icone: "▦",
      nom: "Tableau",
      sousTitre: total ? parColonne.afaire.length + " à faire · " + parColonne.encours.length + " en cours · " + parColonne.fait.length + (parColonne.fait.length > 1 ? " terminées" : " terminée") : "Aucune tâche pour le moment",
      contenu: App.el("div", { class: "tableau" }, colonnes),
    };
  }


  /* ---------- Calendrier ---------- */

  let affiche = null;      // { annee, mois } du mois affiché
  let jourChoisi = null;   // « AAAA-MM-JJ »

  function aujourdhui() { return App.aujourdhui(); }

  function calendrier() {
    if (!affiche) {
      const d = new Date();
      affiche = { annee: d.getFullYear(), mois: d.getMonth() };
      jourChoisi = aujourdhui();
    }
    const { annee, mois } = affiche;
    const toutes = App.toutesLesTaches().filter((t) => t.bloc.echeance);
    const parJour = {};
    toutes.forEach((t) => { (parJour[t.bloc.echeance] = parJour[t.bloc.echeance] || []).push(t); });
    const sansDate = App.toutesLesTaches().filter((t) => !t.bloc.echeance && !t.bloc.fait).length;

    // Grille : la semaine commence le lundi
    const premier = new Date(annee, mois, 1);
    const decalage = (premier.getDay() + 6) % 7;
    const nbJours = new Date(annee, mois + 1, 0).getDate();
    const cases = [];
    for (let i = 0; i < decalage; i++) cases.push(App.el("span", { class: "jour vide", "aria-hidden": "true" }));
    for (let n = 1; n <= nbJours; n++) {
      const iso = App.iso(new Date(annee, mois, n));
      const taches = parJour[iso] || [];
      const restantes = taches.filter((t) => !t.bloc.fait).length;
      const classes = ["jour"];
      if (iso === aujourdhui()) classes.push("aujourdhui");
      if (iso === jourChoisi) classes.push("choisi");
      if (taches.length) classes.push(restantes ? (iso < aujourdhui() ? "en-retard" : "avec") : "toutes-faites");
      cases.push(App.el("button", {
        type: "button", class: classes.join(" "), "data-jour": iso,
        "aria-label": n + " " + MOIS[mois] + (taches.length ? ", " + taches.length + " tâche" + (taches.length > 1 ? "s" : "") : ""),
        "aria-pressed": String(iso === jourChoisi),
        onclick: () => { jourChoisi = iso; App.Vues.rafraichir(); },
      }, App.el("span", { class: "jour-num" }, String(n)), taches.length ? App.el("span", { class: "jour-points" }, taches.slice(0, 3).map(() => App.el("i")), taches.length > 3 ? "+" : "") : null));
    }

    const aller = (delta) => {
      const d = new Date(annee, mois + delta, 1);
      affiche = { annee: d.getFullYear(), mois: d.getMonth() };
      App.Vues.rafraichir();
    };

    const entete = App.el("div", { class: "cal-entete" },
      App.el("button", { type: "button", class: "btn-page", "aria-label": "Mois précédent", onclick: () => aller(-1) }, "‹"),
      App.el("h2", { class: "cal-titre" }, MOIS[mois] + " " + annee),
      App.el("button", { type: "button", class: "btn-page", "aria-label": "Mois suivant", onclick: () => aller(1) }, "›"),
      App.el("button", { type: "button", class: "btn-page", onclick: () => { const d = new Date(); affiche = { annee: d.getFullYear(), mois: d.getMonth() }; jourChoisi = aujourdhui(); App.Vues.rafraichir(); } }, "Aujourd'hui"),
      App.el("button", { type: "button", class: "btn-page", title: "Exporter les tâches datées au format .ics", onclick: () => App.exporterICS && App.exporterICS() }, "📅 .ics"));

    // Les tâches du jour choisi
    const duJour = (parJour[jourChoisi] || []).slice().sort((a, b) => (a.bloc.fait - b.bloc.fait) || (a.bloc.heure || "99").localeCompare(b.bloc.heure || "99"));
    const [aa, mm, jj] = jourChoisi.split("-").map(Number);
    const titreJour = App.el("h3", { class: "cal-jour-titre" }, jj + " " + MOIS[mm - 1] + (jourChoisi === aujourdhui() ? " · aujourd'hui" : ""));
    const liste = duJour.length
      ? App.el("div", { class: "vue-liste" }, duJour.map((t) => App.Vues.ligneTache(t.page, t.bloc)))
      : App.el("p", { class: "vue-vide" }, "Aucune tâche ce jour-là.");

    return {
      icone: "🗓️",
      nom: "Calendrier",
      sousTitre: sansDate ? sansDate + " tâche" + (sansDate > 1 ? "s" : "") + " sans date (ajoute-en une avec 📅)" : "Toutes tes tâches ont une date",
      contenu: App.el("div", { class: "calendrier" },
        entete,
        App.el("div", { class: "cal-semaine", "aria-hidden": "true" }, JOURS.map((j) => App.el("span", null, j))),
        App.el("div", { class: "cal-grille" }, cases),
        titreJour,
        liste),
    };
  }

  return { tableau: tableau, calendrier: calendrier };
})();
