"use strict";

/* =====================================================
   recherche.js : recherche dans tous les blocs de toutes les pages
   Taper dans « Rechercher » filtre les pages (par leur nom) et liste
   aussi les blocs qui contiennent le texte. Ctrl+K (ou Cmd+K) y va directement.
   ===================================================== */

(function () {
  const champ = document.getElementById("recherche");
  const zone = document.getElementById("resultats-recherche");
  const MAX = 30;

  function extrait(texte, q) {
    const brut = texte.replace(/\s+/g, " ").trim();
    const i = App.simplifier(brut).indexOf(q);
    if (i < 0) return [brut.slice(0, 90)];
    const debut = Math.max(0, i - 24);
    const fin = Math.min(brut.length, i + q.length + 50);
    return [(debut > 0 ? "…" : "") + brut.slice(debut, i), brut.slice(i, i + q.length), brut.slice(i + q.length, fin) + (fin < brut.length ? "…" : "")];
  }

  function chercher() {
    const q = App.simplifier(champ.value.trim());
    if (q.length < 2) { zone.hidden = true; zone.replaceChildren(); return; }

    const trouves = [];
    let total = 0;
    App.etat.pages.forEach((page) => {
      page.blocs.forEach((bloc) => {
        if (bloc.type === "separateur" || !bloc.texte) return;
        if (App.simplifier(bloc.texte).includes(q)) {
          total++;
          if (trouves.length < MAX) trouves.push({ page: page, bloc: bloc });
        }
      });
    });

    zone.hidden = false;
    if (!trouves.length) {
      zone.replaceChildren(App.el("p", { class: "section-titre" }, "Dans les blocs"), App.el("p", { class: "vide" }, "Aucun bloc ne contient « " + champ.value.trim() + " »"));
      return;
    }
    zone.replaceChildren(
      App.el("p", { class: "section-titre" }, "Dans les blocs · " + total),
      ...trouves.map(({ page, bloc }) => {
        const [avant, milieu, apres] = extrait(bloc.texte, q);
        return App.el("button", {
          type: "button", class: "resultat", "data-bloc": bloc.id,
          onclick: () => {
            App.ouvrirPage(page.id);
            chercher();      // la recherche a été vidée en ouvrant la page : on masque les résultats
            document.body.classList.remove("menu-ouvert");
            setTimeout(() => App.focaliser(bloc.id, "fin"), 80);
          },
        },
          App.el("span", { class: "resultat-page" }, page.icone + " " + (page.titre || "Sans titre")),
          App.el("span", { class: "resultat-texte" }, avant, milieu !== undefined ? App.el("mark", null, milieu) : null, apres || ""));
      }),
      total > MAX ? App.el("p", { class: "vide" }, "… et " + (total - MAX) + " autres") : null);
  }

  champ.addEventListener("input", chercher);
  // les résultats suivent aussi les modifications (une tâche renommée, une page supprimée…)
  let minuteur = null;
  App.ecouteurs.push(() => { clearTimeout(minuteur); minuteur = setTimeout(chercher, 400); });

  // Ctrl+K / Cmd+K : aller à la recherche
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      document.body.classList.add("menu-ouvert");
      champ.focus();
      champ.select();
    }
  });
})();
