import os
import sys
import tempfile
from pathlib import Path

import pytest

# Un serveur de test isolé : base temporaire, pas de boucle de rappels en arrière-plan
os.environ["MES_BLOCS_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["MES_BLOCS_SANS_RAPPELS"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient  # noqa: E402

from serveur import main  # noqa: E402


@pytest.fixture()
def client():
    main._essais.clear()
    with TestClient(main.app) as c:
        yield c


@pytest.fixture()
def utilisateur(client):
    """Un compte neuf, avec son en-tête d'authentification."""
    nom = "u" + os.urandom(4).hex()
    r = client.post("/api/inscription", json={"nom": nom, "mot_de_passe": "motdepasse1"})
    assert r.status_code == 200
    return {"nom": nom, "H": {"Authorization": "Bearer " + r.json()["token"]}}


def tache(id_, texte, **champs):
    return {"id": id_, "type": "tache", "texte": texte, "fait": False, "niveau": 0, "tags": [], **champs}


@pytest.fixture()
def envoyer(client, utilisateur):
    """Envoie des données au serveur (version suivante automatiquement)."""
    etat = {"v": 0}

    def _envoyer(donnees):
        r = client.put("/api/donnees", headers=utilisateur["H"], json={"base_version": etat["v"], "donnees": donnees})
        assert r.status_code == 200, r.text
        etat["v"] = r.json()["version"]
        return r

    return _envoyer
