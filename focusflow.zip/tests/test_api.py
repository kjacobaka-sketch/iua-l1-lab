"""Comptes, sécurité et synchronisation."""


def test_sante(client):
    assert client.get("/api/sante").json() == {"ok": True}


def test_authentification_requise(client):
    assert client.get("/api/donnees").status_code == 401
    assert client.get("/api/donnees", headers={"Authorization": "Bearer xxx"}).status_code == 401
    assert client.get("/api/analyse").status_code == 401
    assert client.get("/api/export.csv").status_code == 401


def test_validation_inscription(client):
    assert client.post("/api/inscription", json={"nom": "jacob", "mot_de_passe": "abc"}).status_code == 422
    assert client.post("/api/inscription", json={"nom": "a b<>", "mot_de_passe": "motdepasse1"}).status_code == 422


def test_nom_deja_pris_insensible_a_la_casse(client):
    assert client.post("/api/inscription", json={"nom": "Jacob", "mot_de_passe": "motdepasse1"}).status_code == 200
    assert client.post("/api/inscription", json={"nom": "jacob", "mot_de_passe": "autremotdepasse"}).status_code == 409


def test_connexion(client):
    client.post("/api/inscription", json={"nom": "Koffi", "mot_de_passe": "motdepasse1"})
    assert client.post("/api/connexion", json={"nom": "koffi", "mot_de_passe": "motdepasse1"}).status_code == 200
    assert client.post("/api/connexion", json={"nom": "koffi", "mot_de_passe": "mauvaismdp1"}).status_code == 401
    inconnu = client.post("/api/connexion", json={"nom": "inconnu", "mot_de_passe": "mauvaismdp1"})
    assert inconnu.json()["detail"] == "Nom ou mot de passe incorrect"   # ne révèle pas si le nom existe


def test_limite_d_essais(client):
    codes = [client.post("/api/connexion", json={"nom": "jacob", "mot_de_passe": "faux-faux-faux"}).status_code for _ in range(10)]
    assert 429 in codes


def test_synchronisation_et_conflit(client, utilisateur):
    H = utilisateur["H"]
    assert client.get("/api/donnees", headers=H).json() == {"version": 0, "donnees": None}
    donnees = {"pages": [{"id": "p1", "titre": "Test é à ç", "blocs": []}], "stats": {}}
    r = client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": donnees})
    assert r.json()["version"] == 1
    assert client.get("/api/donnees", headers=H).json()["donnees"] == donnees

    perime = client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": donnees})
    assert perime.status_code == 409 and perime.json()["donnees"] == donnees
    assert client.put("/api/donnees", headers=H, json={"base_version": 1, "donnees": {"pages": []}}).json()["version"] == 2


def test_donnees_invalides_ou_trop_grosses(client, utilisateur):
    H = utilisateur["H"]
    assert client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": {"x": 1}}).status_code == 422
    gros = {"pages": ["x" * 1000] * 6000}
    assert client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": gros}).status_code == 413


def test_isolation_entre_utilisateurs(client, utilisateur, envoyer):
    envoyer({"pages": [{"id": "p1", "titre": "Secret", "blocs": []}]})
    autre = client.post("/api/inscription", json={"nom": "autre", "mot_de_passe": "motdepasse1"}).json()["token"]
    assert client.get("/api/donnees", headers={"Authorization": "Bearer " + autre}).json()["donnees"] is None


def test_deconnexion_invalide_le_jeton(client, utilisateur):
    H = utilisateur["H"]
    assert client.post("/api/deconnexion", headers=H).status_code == 200
    assert client.get("/api/donnees", headers=H).status_code == 401


def test_suppression_du_compte(client):
    jeton = client.post("/api/inscription", json={"nom": "ephemere", "mot_de_passe": "motdepasse1"}).json()["token"]
    H = {"Authorization": "Bearer " + jeton}
    client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": {"pages": []}})
    assert client.delete("/api/compte", headers=H).status_code == 200
    assert client.post("/api/connexion", json={"nom": "ephemere", "mot_de_passe": "motdepasse1"}).status_code == 401


def test_fichiers_servis(client):
    assert "FocusFlow" in client.get("/").text
    assert client.get("/js/store.js").status_code == 200
    assert client.head("/sw.js").status_code == 200
    for interdit in ("/serveur/main.py", "/serveur/donnees.db", "/js/../serveur/main.py", "/tests/conftest.py"):
        assert client.get(interdit).status_code == 404
