"""Liens de partage : lecture seule, révocables, contenu échappé."""
from conftest import tache

PAGE = {"id": "p1", "titre": "Ma <b>page</b>", "icone": "📚", "couleur": "bleu", "blocs": [
    {"id": "t", "type": "titre", "texte": "Titre"},
    tache("a", "<script>alert(1)</script> à faire", echeance="2026-12-01"),
    tache("b", "Fini", fait=True),
    {"id": "l1", "type": "liste", "texte": "un"}, {"id": "l2", "type": "liste", "texte": "deux"},
    {"id": "i", "type": "image", "texte": "ok", "src": "javascript:alert(1)"},
]}


def test_creer_lire_revoquer(client, utilisateur, envoyer):
    H = utilisateur["H"]
    envoyer({"pages": [PAGE, {"id": "p2", "titre": "Privée", "blocs": []}]})
    r = client.post("/api/partages", headers=H, json={"page_id": "p1"})
    assert r.status_code == 200
    jeton, chemin = r.json()["jeton"], r.json()["chemin"]
    assert len(jeton) >= 20 and chemin == "/p/" + jeton
    assert client.post("/api/partages", headers=H, json={"page_id": "p1"}).json()["jeton"] == jeton   # un seul lien par page

    publique = client.get(chemin)                                        # sans aucun en-tête d'authentification
    assert publique.status_code == 200
    assert "<script>alert" not in publique.text and "&lt;script&gt;" in publique.text
    assert "javascript:alert" not in publique.text                       # une fausse « image » n'est pas affichée
    assert "Privée" not in publique.text                                 # seule la page choisie est visible
    assert "default-src 'none'" in publique.headers["content-security-policy"]
    assert "noindex" in publique.headers["x-robots-tag"]

    assert [p["titre"] for p in client.get("/api/partages", headers=H).json()["partages"]] == ["Ma <b>page</b>"]
    assert client.delete("/api/partages/" + jeton, headers=H).status_code == 200
    assert client.get(chemin).status_code == 404


def test_le_lien_suit_les_mises_a_jour_et_la_suppression(client, utilisateur, envoyer):
    envoyer({"pages": [PAGE]})
    chemin = client.post("/api/partages", headers=utilisateur["H"], json={"page_id": "p1"}).json()["chemin"]
    modif = dict(PAGE, blocs=[{"id": "t", "type": "titre", "texte": "Nouvelle version"}])
    envoyer({"pages": [modif]})
    assert "Nouvelle version" in client.get(chemin).text
    envoyer({"pages": []})
    assert client.get(chemin).status_code == 404


def test_page_non_synchronisee_ou_d_un_autre(client, utilisateur, envoyer):
    H = utilisateur["H"]
    assert client.post("/api/partages", headers=H, json={"page_id": "p1"}).status_code == 404
    envoyer({"pages": [PAGE]})
    jeton = client.post("/api/partages", headers=H, json={"page_id": "p1"}).json()["jeton"]
    autre = client.post("/api/inscription", json={"nom": "intrus", "mot_de_passe": "motdepasse1"}).json()["token"]
    HA = {"Authorization": "Bearer " + autre}
    client.delete("/api/partages/" + jeton, headers=HA)                  # n'a aucun effet sur le lien d'un autre
    assert client.get("/p/" + jeton).status_code == 200
    assert client.get("/p/inexistant").status_code == 404


def test_supprimer_le_compte_supprime_les_liens(client):
    jeton = client.post("/api/inscription", json={"nom": "partant", "mot_de_passe": "motdepasse1"}).json()["token"]
    H = {"Authorization": "Bearer " + jeton}
    client.put("/api/donnees", headers=H, json={"base_version": 0, "donnees": {"pages": [PAGE]}})
    chemin = client.post("/api/partages", headers=H, json={"page_id": "p1"}).json()["chemin"]
    client.delete("/api/compte", headers=H)
    assert client.get(chemin).status_code == 404
