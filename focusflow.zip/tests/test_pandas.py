"""Le script pandas lit la base du serveur et l'export CSV."""
import io
import sys
from pathlib import Path

import pytest

pd = pytest.importorskip("pandas")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "analyse"))
import analyse_pandas as ap  # noqa: E402

from conftest import tache  # noqa: E402
from test_analyse import DONNEES  # noqa: E402
from serveur import main  # noqa: E402


def test_lecture_sqlite_et_rapport(client, utilisateur, envoyer):
    envoyer(DONNEES)
    df = ap.depuis_sqlite(main.BASE, utilisateur["nom"])
    assert len(df) == 4
    r = ap.rapport(ap.preparer(df))
    assert (r["total"], r["faites"], r["taux"]) == (4, 2, 50.0)
    assert r["delai_median_h"] == 14.0
    assert r["par_jour"]["mardi"] == 2
    assert len(r["en_retard"]) == 1


def test_lecture_csv_du_serveur(client, utilisateur, envoyer):
    envoyer(DONNEES)
    csv_serveur = client.get("/api/export.csv", headers=utilisateur["H"]).text
    df = ap.depuis_csv(io.StringIO(csv_serveur))
    assert len(df) == 4 and set(df["page_titre"]) == {"Cours", "Perso"}
    assert ap.rapport(ap.preparer(df))["faites"] == 2


def test_donnees_demo_et_graphiques(tmp_path):
    pytest.importorskip("matplotlib")
    r = ap.rapport(ap.preparer(ap.donnees_demo()))
    assert r["total"] == 240 and 0 < r["taux"] < 100
    ap.graphiques(r, tmp_path)
    assert (tmp_path / "analyse.png").stat().st_size > 10_000
