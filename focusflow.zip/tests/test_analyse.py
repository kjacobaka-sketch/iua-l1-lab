"""Les tâches sont aplaties dans une table SQL puis analysées."""
import time
from datetime import datetime, timezone

from conftest import tache


def ms(annee, mois, jour, heure=12):
    return int(datetime(annee, mois, jour, heure, tzinfo=timezone.utc).timestamp() * 1000)


DONNEES = {
    "pages": [
        {"id": "p1", "titre": "Cours", "blocs": [
            tache("a", "Réviser SQL", fait=True, creeLe=ms(2026, 11, 2), faitLe=ms(2026, 11, 3), tags=["sql", "examen"]),   # mardi 3 nov
            tache("b", "Faire le TP", echeance="2020-01-01", tags=["sql"]),                                             # en retard
            tache("c", "Relire", encours=True, echeance="2999-01-01"),
            {"id": "x", "type": "paragraphe", "texte": "pas une tâche"},
        ]},
        {"id": "p2", "titre": "Perso", "blocs": [tache("d", "=SOMME(A1)", fait=True, creeLe=ms(2026, 11, 3, 10), faitLe=ms(2026, 11, 3, 14))]},
    ],
    "stats": {"faits": {"2026-11-03": 2, "2026-11-04": 1}, "pomodoros": {"2026-11-03": 3}},
}


def test_resume_sql(client, utilisateur, envoyer):
    envoyer(DONNEES)
    r = client.get("/api/analyse", headers=utilisateur["H"]).json()
    g = r["global"]
    assert (g["total"], g["faites"], g["en_cours"], g["en_retard"], g["sans_date"]) == (4, 2, 1, 1, 0)
    assert g["taux_reussite"] == 50.0
    par_page = {p["page"]: p for p in r["par_page"]}
    assert par_page["Cours"]["total"] == 3 and par_page["Cours"]["faites"] == 1
    assert par_page["Perso"]["taux"] == 100.0
    semaine = {j["jour"]: j["faites"] for j in r["par_jour_semaine"]}
    assert semaine["mar"] == 2 and sum(semaine.values()) == 2         # les deux tâches ont été faites un mardi
    assert r["delai_moyen_heures"] == 14.0                            # (24 h + 4 h) / 2
    assert [j["jour"] for j in r["derniers_jours"]] == ["2026-11-03", "2026-11-04"]
    assert {t["tag"]: t["nombre"] for t in r["tags"]} == {"sql": 2, "examen": 1}
    assert r["jours_actifs"] == 2


def test_la_table_suit_les_modifications(client, utilisateur, envoyer):
    envoyer(DONNEES)
    envoyer({"pages": [{"id": "p1", "titre": "Cours", "blocs": [tache("z", "Seule")]}]})
    g = client.get("/api/analyse", headers=utilisateur["H"]).json()["global"]
    assert g["total"] == 1 and g["faites"] == 0


def test_analyse_isolee_par_utilisateur(client, utilisateur, envoyer):
    envoyer(DONNEES)
    autre = client.post("/api/inscription", json={"nom": "vide", "mot_de_passe": "motdepasse1"}).json()["token"]
    r = client.get("/api/analyse", headers={"Authorization": "Bearer " + autre}).json()
    assert r["global"]["total"] == 0 and r["global"]["taux_reussite"] == 0.0 and r["par_page"] == []


def test_export_csv(client, utilisateur, envoyer):
    envoyer(DONNEES)
    r = client.get("/api/export.csv", headers=utilisateur["H"])
    assert r.headers["content-type"].startswith("text/csv")
    lignes = r.text.lstrip("﻿").splitlines()
    assert lignes[0].startswith("page_titre;texte;fait")
    assert len(lignes) == 5
    assert any("'=SOMME(A1)" in l for l in lignes)       # une « formule » est neutralisée pour Excel
