"""Rappels push : sélection des tâches dues, une seule notification, nettoyage des abonnements morts."""
from datetime import datetime, timezone

from conftest import tache
from serveur import main, rappels

ABO = {"endpoint": "https://push.example/abc123456", "keys": {"p256dh": "A" * 20, "auth": "B" * 20}, "decalage": 0}


def lancer(maintenant, envoyer):
    with main.connexion() as base:
        return rappels.verifier_rappels(base, maintenant, envoyer)


def test_cle_publique(client):
    cle = client.get("/api/push/cle").json()["cle"]
    assert len(cle) == 87            # 65 octets en base64url sans « = »
    assert client.get("/api/push/cle").json()["cle"] == cle           # stable d'un appel à l'autre


def test_abonnement_validation(client, utilisateur):
    H = utilisateur["H"]
    assert client.post("/api/push/abonner", json=ABO).status_code == 401
    assert client.post("/api/push/abonner", headers=H, json=dict(ABO, endpoint="http://pas-https.example/x" * 2)).status_code == 422
    assert client.post("/api/push/abonner", headers=H, json=ABO).status_code == 200
    assert client.post("/api/push/desabonner", headers=H, json={"endpoint": ABO["endpoint"]}).status_code == 200


def test_rappel_envoye_une_seule_fois(client, utilisateur, envoyer):
    H = utilisateur["H"]
    envoyer({"pages": [{"id": "p1", "titre": "Cours", "blocs": [
        tache("a", "TP de maths", echeance="2026-11-20", heure="14:00"),
        tache("b", "Plus tard", echeance="2026-11-21", heure="14:00"),
        tache("c", "Déjà fait", echeance="2026-11-20", heure="14:00", fait=True),
    ]}]})
    client.post("/api/push/abonner", headers=H, json=dict(ABO, decalage=0))
    envoyes = []
    faux = lambda base, abo, message: envoyes.append(message) or True

    assert lancer(datetime(2026, 11, 20, 13, 59, tzinfo=timezone.utc), faux) == 0      # pas encore l'heure
    assert lancer(datetime(2026, 11, 20, 14, 1, tzinfo=timezone.utc), faux) == 1
    assert envoyes[0]["titre"] == "⏰ TP de maths" and envoyes[0]["corps"] == "Cours"
    assert lancer(datetime(2026, 11, 20, 14, 5, tzinfo=timezone.utc), faux) == 0       # déjà rappelée
    assert lancer(datetime(2026, 11, 21, 14, 1, tzinfo=timezone.utc), faux) == 1       # « Plus tard » sonne le lendemain


def test_fuseau_horaire_et_heure_par_defaut(client, utilisateur, envoyer):
    H = utilisateur["H"]
    envoyer({"pages": [{"id": "p1", "titre": "P", "blocs": [tache("a", "Sans heure", echeance="2026-11-20")]}]})
    # Paris en hiver : getTimezoneOffset() = -60, donc 8 h locales = 7 h UTC
    client.post("/api/push/abonner", headers=H, json=dict(ABO, decalage=-60))
    faux = lambda base, abo, message: True
    assert lancer(datetime(2026, 11, 20, 6, 59, tzinfo=timezone.utc), faux) == 0
    assert lancer(datetime(2026, 11, 20, 7, 0, tzinfo=timezone.utc), faux) == 1


def test_tache_trop_ancienne_ignoree(client, utilisateur, envoyer):
    envoyer({"pages": [{"id": "p1", "titre": "P", "blocs": [tache("a", "Vieille", echeance="2026-11-01", heure="08:00")]}]})
    client.post("/api/push/abonner", headers=utilisateur["H"], json=ABO)
    assert lancer(datetime(2026, 11, 20, 12, 0, tzinfo=timezone.utc), lambda *a: True) == 0


def test_abonnement_mort_supprime(client, utilisateur, envoyer):
    envoyer({"pages": [{"id": "p1", "titre": "P", "blocs": [tache("a", "T", echeance="2026-11-20", heure="10:00")]}]})
    client.post("/api/push/abonner", headers=utilisateur["H"], json=ABO)
    assert lancer(datetime(2026, 11, 20, 10, 1, tzinfo=timezone.utc), lambda *a: False) == 0   # 410 Gone
    with main.connexion() as base:
        assert base.execute("SELECT COUNT(*) FROM push_abos").fetchone()[0] == 0


def test_une_erreur_d_envoi_ne_bloque_pas(client, utilisateur, envoyer):
    envoyer({"pages": [{"id": "p1", "titre": "P", "blocs": [tache("a", "T", echeance="2026-11-20", heure="10:00")]}]})
    client.post("/api/push/abonner", headers=utilisateur["H"], json=ABO)

    def casse(*a):
        raise RuntimeError("réseau")

    assert lancer(datetime(2026, 11, 20, 10, 1, tzinfo=timezone.utc), casse) == 0


def test_envoi_reel_chiffre_vers_un_faux_service_push(client):
    """Vrai envoi Web Push (chiffrement + signature VAPID) vers un serveur local qui joue le rôle du service push."""
    import base64
    import http.server
    import threading

    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    recu = {}

    class Faux(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            recu["entetes"] = dict(self.headers)
            recu["corps"] = self.rfile.read(int(self.headers["Content-Length"]))
            self.send_response(201)
            self.end_headers()

        def log_message(self, *a):
            pass

    serveur = http.server.HTTPServer(("127.0.0.1", 0), Faux)
    threading.Thread(target=serveur.handle_request, daemon=True).start()

    cle = ec.generate_private_key(ec.SECP256R1())          # ce que ferait le navigateur
    publique = cle.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
    abo = {"endpoint": "http://127.0.0.1:%d/push" % serveur.server_port, "p256dh": b64(publique), "auth": b64(b"0123456789abcdef")}

    with main.connexion() as base:
        assert rappels.envoyer_push(base, abo, {"titre": "⏰ Test", "corps": "Page"}) is True
    entetes = {k.lower(): v for k, v in recu["entetes"].items()}
    assert entetes["content-encoding"] == "aes128gcm"
    assert entetes["authorization"].lower().startswith(("vapid ", "webpush "))
    assert b"Test" not in recu["corps"]                      # le message voyage chiffré
    serveur.server_close()
