"""
Analyse de tes tâches FocusFlow avec pandas.

Deux sources possibles :
  - la base SQLite du serveur (table « taches », remplie à chaque synchronisation) ;
  - un fichier CSV exporté depuis l'appli (Paramètres → Sauvegarde et export).

Exemples :
    python analyse/analyse_pandas.py --demo                       # données fictives, pour essayer
    python analyse/analyse_pandas.py --db serveur/donnees.db --utilisateur jacob
    python analyse/analyse_pandas.py --csv focusflow-taches.csv --graphiques rapport/

Installation :  pip install pandas matplotlib
"""

import argparse
import random
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]


# ------------------------------------------------------------------ chargement

def depuis_sqlite(chemin: Path, utilisateur: str) -> pd.DataFrame:
    with sqlite3.connect(chemin) as base:
        return pd.read_sql_query(
            """SELECT t.page_titre, t.texte, t.fait, t.encours, t.echeance, t.heure, t.niveau,
                      t.tags, t.repete, t.cree_le, t.fait_le
               FROM taches t JOIN utilisateurs u ON u.id = t.user_id WHERE u.nom = ? COLLATE NOCASE""",
            base, params=(utilisateur,))


def depuis_csv(chemin: Path) -> pd.DataFrame:
    return pd.read_csv(chemin, sep=";", encoding="utf-8-sig")


def donnees_demo(n: int = 240, graine: int = 7) -> pd.DataFrame:
    """Des tâches fictives sur 90 jours, pour essayer le script sans compte."""
    hasard = random.Random(graine)
    pages = {"Cours": 0.55, "Projet": 0.7, "Perso": 0.45, "Sport": 0.35}
    debut = datetime(2026, 8, 24)
    lignes = []
    for i in range(n):
        page = hasard.choice(list(pages))
        cree = debut + timedelta(days=hasard.randint(0, 85), hours=hasard.randint(7, 22))
        fait = hasard.random() < pages[page]
        # des délais variés (de 2 h à 5 jours) : les graphiques ont ainsi du relief
        delai = timedelta(hours=hasard.choice([2, 5, 20, 26, 48, 72, 120]) + hasard.random() * 6)
        lignes.append({
            "page_titre": page, "texte": f"Tâche {i}", "fait": int(fait), "encours": 0,
            "echeance": (cree + timedelta(days=hasard.randint(1, 7))).strftime("%Y-%m-%d"), "heure": "",
            "niveau": 0, "tags": hasard.choice(["", "sql", "python", "examen", "sql python"]), "repete": "",
            "cree_le": int(cree.timestamp() * 1000), "fait_le": int((cree + delai).timestamp() * 1000) if fait else None,
        })
    return pd.DataFrame(lignes)


# ------------------------------------------------------------------ calculs

def preparer(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["fait"] = df["fait"].astype(int)
    df["cree"] = pd.to_datetime(df["cree_le"], unit="ms", errors="coerce")
    df["termine"] = pd.to_datetime(df["fait_le"], unit="ms", errors="coerce")
    df["delai_h"] = (df["termine"] - df["cree"]).dt.total_seconds() / 3600
    df["echeance"] = pd.to_datetime(df["echeance"], errors="coerce")
    return df


def rapport(df: pd.DataFrame) -> dict:
    faites = df[df["fait"] == 1]
    r = {
        "total": len(df),
        "faites": int(df["fait"].sum()),
        "taux": round(100 * df["fait"].mean(), 1) if len(df) else 0.0,
        "delai_median_h": round(faites["delai_h"].median(), 1) if faites["delai_h"].notna().any() else None,
    }
    r["par_page"] = (df.groupby("page_titre")["fait"].agg(total="count", faites="sum")
                     .assign(taux=lambda d: (100 * d["faites"] / d["total"]).round(1))
                     .sort_values("total", ascending=False))
    r["par_jour"] = (faites.groupby(faites["termine"].dt.dayofweek).size()
                     .reindex(range(7), fill_value=0).rename(index=dict(enumerate(JOURS))))
    r["par_semaine"] = (faites.set_index("termine").resample("W-MON")["fait"].sum()
                        .rename("terminees"))
    r["par_heure"] = faites.groupby(faites["termine"].dt.hour).size().reindex(range(24), fill_value=0)
    tags = df.assign(tag=df["tags"].fillna("").str.split()).explode("tag")
    tags = tags[tags["tag"].notna() & (tags["tag"] != "")]
    r["tags"] = tags.groupby("tag")["fait"].agg(total="count", faites="sum").sort_values("total", ascending=False)
    maintenant = pd.Timestamp.now().normalize()
    r["en_retard"] = df[(df["fait"] == 0) & (df["echeance"] < maintenant)]
    return r


def afficher(r: dict) -> None:
    print(f"\n=== {r['total']} tâches : {r['faites']} terminées ({r['taux']} %) ===")
    if r["delai_median_h"] is not None:
        print(f"Délai médian entre la création et la fin : {r['delai_median_h']} h")
    print("\n--- Par page ---\n", r["par_page"].to_string())
    print("\n--- Tâches terminées par jour de la semaine ---\n", r["par_jour"].to_string())
    if len(r["tags"]):
        print("\n--- Par tag ---\n", r["tags"].to_string())
    print(f"\n--- En retard : {len(r['en_retard'])} tâche(s) ---")
    if len(r["en_retard"]):
        print(r["en_retard"][["page_titre", "texte", "echeance"]].head(10).to_string(index=False))


def graphiques(r: dict, dossier: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    dossier.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5))
    r["par_page"]["taux"].sort_values().plot.barh(ax=axes[0, 0], color="#6366f1", title="Taux de réussite par page (%)")
    r["par_jour"].plot.bar(ax=axes[0, 1], color="#6366f1", title="Tâches terminées par jour de la semaine", rot=30)
    if len(r["par_semaine"]):
        r["par_semaine"].plot(ax=axes[1, 0], marker="o", color="#6366f1", title="Tâches terminées par semaine")
    r["par_heure"].plot.bar(ax=axes[1, 1], color="#6366f1", title="À quelle heure je termine mes tâches")
    for ax in axes.flat:
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_xlabel("")
    fig.tight_layout()
    sortie = dossier / "analyse.png"
    fig.savefig(sortie, dpi=140)
    print(f"\nGraphiques enregistrés : {sortie}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyse de tes tâches FocusFlow avec pandas")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--db", type=Path, help="base SQLite du serveur (serveur/donnees.db)")
    source.add_argument("--csv", type=Path, help="CSV exporté depuis l'appli ou /api/export.csv")
    source.add_argument("--demo", action="store_true", help="données fictives pour essayer")
    parser.add_argument("--utilisateur", help="nom du compte (obligatoire avec --db)")
    parser.add_argument("--graphiques", type=Path, help="dossier où enregistrer analyse.png")
    args = parser.parse_args()

    if args.db:
        if not args.utilisateur:
            parser.error("--utilisateur est obligatoire avec --db")
        df = depuis_sqlite(args.db, args.utilisateur)
    elif args.csv:
        df = depuis_csv(args.csv)
    else:
        df = donnees_demo()
    if df.empty:
        print("Aucune tâche à analyser.")
        return 1
    r = rapport(preparer(df))
    afficher(r)
    if args.graphiques:
        graphiques(r, args.graphiques)
    return 0


if __name__ == "__main__":
    sys.exit(main())
