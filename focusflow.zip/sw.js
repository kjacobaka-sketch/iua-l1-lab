"use strict";

/* =====================================================
   sw.js : service worker (fait marcher l'appli hors ligne)
   Quand tu modifies un fichier, change le numéro de VERSION
   pour que le téléphone récupère la nouvelle version.
   ===================================================== */

const VERSION = "v10";
const CACHE = "focusflow-" + VERSION;

const FICHIERS = [
  "./",
  "index.html",
  "style.css",
  "blocs.css",
  "extras.css",
  "design.css",
  "app.js",
  "js/store.js",
  "js/outils.js",
  "js/ui.js",
  "js/histoire.js",
  "js/editor.js",
  "js/menus.js",
  "js/taches.js",
  "js/vues.js",
  "js/donnees.js",
  "js/focus.js",
  "js/pages.js",
  "js/menupage.js",
  "js/recherche.js",
  "js/modeles.js",
  "js/vuesplus.js",
  "js/images.js",
  "js/accueil.js",
  "js/push.js",
  "js/analyse.js",
  "js/sync.js",
  "js/parametres.js",
  "manifest.json",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-180.png",
  "icons/icon-96.png",
  "icons/icon-48.png",
  "icons/icon-maskable-512.png",
];

// Installation : on met tous les fichiers en cache
self.addEventListener("install", (evenement) => {
  evenement.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(FICHIERS)));
  self.skipWaiting();
});

// Activation : on supprime les anciens caches
self.addEventListener("activate", (evenement) => {
  evenement.waitUntil(
    caches.keys()
      .then((cles) => Promise.all(cles.filter((c) => c !== CACHE).map((c) => caches.delete(c))))
      .then(() => self.clients.claim())
  );
});

// Chaque requête : le réseau d'abord (pour avoir la dernière version), le cache si pas de réseau.
// Les appels à l'API de synchronisation ne sont jamais mis en cache.
self.addEventListener("fetch", (evenement) => {
  const requete = evenement.request;
  if (requete.method !== "GET" || !requete.url.startsWith(self.location.origin)) return;
  const chemin = new URL(requete.url).pathname;
  if (chemin.startsWith("/api/") || chemin.startsWith("/p/")) return;

  evenement.respondWith(
    fetch(requete)
      .then((reponse) => {
        if (reponse.ok) {
          const copie = reponse.clone();
          caches.open(CACHE).then((cache) => cache.put(requete, copie));
        }
        return reponse;
      })
      .catch(() => caches.match(requete).then((trouve) => trouve || caches.match("index.html")))
  );
});

// Notification « push » envoyée par le serveur (rappel d'une tâche, même appli fermée)
self.addEventListener("push", (evenement) => {
  let message = { titre: "FocusFlow", corps: "", tag: "focusflow" };
  try { Object.assign(message, evenement.data ? evenement.data.json() : {}); } catch (erreur) { /* message illisible : on affiche le défaut */ }
  evenement.waitUntil(self.registration.showNotification(message.titre, {
    body: message.corps, tag: message.tag, icon: "icons/icon-192.png", badge: "icons/icon-96.png",
  }));
});

// Un toucher sur une notification (rappel, fin de pomodoro) ramène sur l'appli
self.addEventListener("notificationclick", (evenement) => {
  evenement.notification.close();
  evenement.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((fenetres) => {
      if (fenetres.length) return fenetres[0].focus();
      return self.clients.openWindow("./");
    })
  );
});
