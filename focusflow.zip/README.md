# FocusFlow

![Tests](https://github.com/TON-COMPTE/focusflow/actions/workflows/ci.yml/badge.svg)

Un gestionnaire de tâches par blocs, façon Notion : il marche dans le navigateur, s'installe sur un téléphone (PWA) et se synchronise entre appareils grâce à un serveur **FastAPI + SQLite**. Les tâches sont analysées en **SQL** et avec **pandas**, et le serveur envoie des **rappels push** et des **liens de partage** en lecture seule.

Projet personnel d'un étudiant en génie informatique, pensé comme un projet de **data engineering** : modélisation (document JSON → table SQL), API, tests automatiques, conteneur Docker, intégration continue.

| Appli | Tableau (Kanban) |
|---|---|
| ![Page](captures/1-page.png) | ![Tableau](captures/2-tableau.png) |

| Analyse calculée en SQL | Page partagée (lecture seule) |
|---|---|
| ![Analyse](captures/4-analyse.png) | ![Partage](captures/5-partage-mobile.png) |

## Lancer l'appli

**Le plus simple (sans serveur)** : ouvre le dossier dans VS Code, installe l'extension *Live Server*, clic droit sur `index.html` → *Open with Live Server*.
Tout marche, sauf la synchronisation.

**Avec le serveur de synchronisation** (depuis le dossier qui contient `index.html`) :

```
pip install -r serveur/requirements.txt
python -m uvicorn serveur.main:app --port 8000
```

Ouvre ensuite `http://localhost:8000`. Le serveur sert l'appli **et** l'API. Dans l'appli : menu → **Synchronisation** → *Créer un compte*. Laisse l'adresse du serveur vide.
Sous Windows, si `python` ne marche pas, utilise `py` à la place. La documentation interactive de l'API est sur `http://localhost:8000/api/docs`.

**Avec Docker** :

```
docker build -t focusflow .
docker run -p 8000:8000 -v focusflow-data:/data focusflow
```

**Lancer les tests** :

```
pip install -r requirements-dev.txt
python -m pytest
```

## Ce que fait l'appli

| | |
|---|---|
| **Blocs** | texte, titres, tâches, listes, citations, séparateurs. Menu `/`, raccourcis `# `, `- `, `[] `, `> `, `1. `, `---` |
| **Mise en forme** | sélectionne du texte : gras, italique, souligné, barré, code, lien |
| **Organisation** | pages avec icône et couleur, blocs repliables, glisser-déposer, Tab pour décaler |
| **Tâches** | date limite, heure de rappel, répétition (jour, semaine, mois), tags |
| **Vues** | Aujourd'hui, En retard, À venir, et une vue par tag (toutes pages confondues) |
| **Recherche** | des pages (menu), et dans la page ouverte |
| **Recherche globale** | cherche dans tous les blocs de toutes les pages (Ctrl+K) |
| **Modèles de pages** | semaine de cours, projet, révisions, objectifs, journal, courses |
| **Sous-tâches** | une tâche décalée sous une autre : progression « 2/4 », cases liées |
| **Tableau** (Kanban) | À faire / En cours / Terminé pour toutes les tâches |
| **Calendrier** | grille du mois, tâches du jour choisi |
| **Blocs image** | photos réduites automatiquement, légende modifiable, téléchargement |
| **Apparence** | 4 palettes (neutre, ardoise, chaud, noir), 4 polices, mode compact |
| **Raccourcis du téléphone** | appui long sur l'icône : « Nouvelle tâche » et « Aujourd'hui » |
| **Options de la page** (⋯) | couleur, icône, favori (⭐ en haut du menu), dupliquer, partager (menu du téléphone, copier, e-mail, fichier .md, PDF), supprimer |
| **Paramètres** (⚙️) | un seul menu : thème Auto/Clair/Sombre, couleur de la page, animations, statistiques, corbeille, export, synchronisation, rappels, installation, raccourcis |
| **Sécurité des données** | Ctrl+Z / Ctrl+Y, corbeille de 30 jours, export/import JSON |
| **Analyse** | statistiques, export CSV (tâches et historique) pour Excel ou pandas |
| **Concentration** | mode focus et minuteur Pomodoro (compté dans les statistiques) |
| **Synchronisation** | comptes, fusion page par page (la modification la plus récente gagne) |
| **Mon analyse** | taux de réussite, retards, délai moyen, jour de la semaine le plus productif… calculés **en SQL** par le serveur |
| **Rappels push** | la notification arrive même appli fermée (Web Push + clés VAPID) |
| **Lien de partage** | une page web **en lecture seule**, sans compte, que tu peux désactiver à tout moment |
| **Calendrier (.ics)** | exporte les tâches datées vers Google Agenda, Outlook, Apple Calendrier |
| **Images** | stockées dans IndexedDB (pas de limite de 5 Mo du `localStorage`) |

## Côté données : du JSON à l'analyse

Chaque utilisateur a **un document JSON** (ses pages et ses blocs), ce qui rend la synchronisation simple. Mais un document ne s'interroge pas facilement. À chaque synchronisation, le serveur **aplatit** les tâches dans une vraie table SQL, dans la même transaction que l'écriture :

```
utilisateurs ─┬─ donnees   (le document JSON + numéro de version)
              ├─ taches    (une ligne par tâche : page, texte, fait, échéance, tags, cree_le, fait_le…)
              ├─ jours     (tâches terminées et pomodoros par jour)
              ├─ partages  (liens de lecture seule)
              ├─ push_abos / rappels_envoyes
              └─ sessions
```

- `GET /api/analyse` : tous les chiffres viennent de requêtes SQL (`GROUP BY`, `strftime`, requête récursive pour compter les tags) : voir `serveur/analyse.py`.
- `GET /api/export.csv` : la table `taches` en CSV (protégé contre l'injection de formules Excel).
- `analyse/analyse_pandas.py` : la même analyse avec **pandas** + graphiques **matplotlib**, depuis la base ou un CSV.

```
python analyse/analyse_pandas.py --demo --graphiques rapport/          # essayer avec des données fictives
python analyse/analyse_pandas.py --db serveur/donnees.db --utilisateur ton_nom
```

![pandas](captures/6-pandas.png)

## Rappels push et liens de partage

**Rappels push** (`serveur/rappels.py`) : l'appli s'abonne au service push du navigateur et envoie l'abonnement au serveur. Chaque minute, le serveur cherche les tâches arrivées à échéance (en tenant compte du fuseau horaire de l'appareil), envoie une notification chiffrée et note l'envoi pour ne **jamais envoyer deux fois**. Sans heure précise, une tâche sonne à 8 h. Les clés VAPID sont créées au premier démarrage ; avec un hébergeur sans disque persistant, génère-les une fois (`python serveur/generer_cles_vapid.py`) et mets-les dans `MES_BLOCS_VAPID_PEM`.

**Liens de partage** (`serveur/partage.py`) : le serveur fabrique une page HTML à partir de la dernière version synchronisée d'**une seule page**. Le jeton est aléatoire (128 bits), le texte est entièrement échappé, une politique CSP interdit tout script, la page n'est pas indexée par les moteurs de recherche, et le lien se révoque d'un clic.

## Où sont mes données ?

Dans le navigateur de chaque appareil (`localStorage`). Sans compte, rien ne quitte ton appareil. Avec un compte, une copie est envoyée au serveur que tu as choisi. **Fais une sauvegarde de temps en temps** (menu → Données → Exporter).

## Synchronisation : comment ça marche

- À chaque modification, l'appli attend 3 secondes puis : télécharge la version du serveur, la **fusionne** avec la tienne, et renvoie le résultat.
- Fusion : pour chaque page, la version modifiée en dernier l'emporte. Une page supprimée reste supprimée (elle est dans la corbeille). Les statistiques gardent le maximum par jour.
- Si deux appareils modifient **la même page** en même temps, la plus récente gagne : l'autre modification de cette page est perdue. Elles ne se mélangent pas bloc par bloc.
- Hors ligne, tu continues à travailler. La synchro reprend au retour du réseau.

## Mettre en ligne (pour l'utiliser sur ton téléphone)

- **Appli seule (sans synchro)** : dépose le dossier sur Netlify Drop (`app.netlify.com/drop`) ou GitHub Pages. Tu obtiens un lien **https**, nécessaire pour installer l'appli sur l'écran d'accueil et l'utiliser hors ligne.
- **Avec synchro** : il faut héberger `serveur/` quelque part en **https** (Render, Railway, Fly.io, un VPS…). Commande de démarrage : `uvicorn serveur.main:app --host 0.0.0.0 --port $PORT`.
  - La base `serveur/donnees.db` doit être sur un **disque persistant**. Sur une offre gratuite sans disque, la base peut être effacée à un redémarrage : tes appareils gardent leurs données et les renverront à la prochaine synchro.
  - Si l'appli et le serveur sont sur deux adresses différentes, saisis l'adresse du serveur dans la fenêtre Synchronisation, et limite l'accès avec la variable `MES_BLOCS_ORIGINES=https://ton-site.netlify.app`.
  - Autres réglages : `MES_BLOCS_DB` (chemin de la base), `MES_BLOCS_VAPID_PEM` (clé des rappels push), `MES_BLOCS_ORIGINES`.
  - Un fichier `render.yaml` et un `Dockerfile` sont fournis : sur Render, « New + » → « Blueprint » → ton dépôt.
  - **Rappels push et offre gratuite** : un serveur mis en veille (Render gratuit : après 15 min d'inactivité) ne peut pas envoyer les rappels à l'heure. Pour des rappels fiables il faut un serveur toujours allumé.

## Limites à connaître

- **Rappels** : sans serveur, ils s'affichent **quand l'appli est ouverte**. Les rappels push (Paramètres → « Rappels même appli fermée ») demandent la synchronisation, une adresse **https** et un serveur toujours allumé. Sur iPhone, l'appli doit d'abord être ajoutée à l'écran d'accueil.
- **Partage** : lecture seule uniquement (pas d'édition à plusieurs). Le lien montre la dernière version **synchronisée** de la page.
- **Mots de passe** : le serveur ne garde qu'un hachage (scrypt), mais il n'y a pas de récupération de mot de passe : si tu l'oublies, crée un nouveau compte.
- Testé sur Chromium (ordinateur et simulation de téléphone). À essayer sur ton vrai téléphone, surtout le glisser-déposer au doigt.

## Structure

```
index.html          page unique
style.css           couleurs, mise en page, menu latéral
blocs.css           blocs, barre du bas, menus
extras.css          vues, fenêtres, statistiques, pomodoro, focus
design.css          refonte visuelle (couleurs, formes, animations) : chargé en dernier
app.js              démarrage, installation, hors ligne
sw.js               service worker (change VERSION à chaque mise à jour)
manifest.json       description de l'appli installable
js/store.js         données, fusion, sauvegarde
js/histoire.js      annuler / rétablir
js/editor.js        l'éditeur de blocs
js/taches.js        dates, tags, rappels
js/vues.js          Aujourd'hui, En retard, À venir, tags
js/donnees.js       export/import, CSV, corbeille, statistiques
js/focus.js         focus et Pomodoro
js/sync.js          synchronisation (côté appli)
js/parametres.js    le menu ⚙️ Paramètres
js/menupage.js      le menu ⋯ Options de chaque page (favori, partage…)
js/recherche.js     recherche dans tous les blocs
js/modeles.js       modèles de pages (« Nouvelle page »)
js/vuesplus.js      vues Tableau (Kanban) et Calendrier
js/images.js        blocs image (réduction et affichage)
js/accueil.js       écran de bienvenue et raccourcis de l'écran d'accueil
js/push.js          abonnement aux rappels push
js/analyse.js       écran « Mon analyse » (chiffres du serveur)
serveur/main.py     API FastAPI : comptes, synchronisation, routes
serveur/analyse.py  aplatissement JSON → table SQL, requêtes d'analyse, export CSV
serveur/rappels.py  rappels push (VAPID, boucle d'envoi)
serveur/partage.py  page HTML de lecture seule
analyse/            script pandas + matplotlib
tests/              tests pytest (comptes, sync, analyse, partage, push, pandas)
Dockerfile, render.yaml, .github/workflows/ci.yml   conteneur, déploiement, tests automatiques
captures/           images de ce README
```

Quand tu modifies un fichier de l'appli, change `VERSION` dans `sw.js` (par exemple `v3` en `v4`), sinon un téléphone peut garder l'ancienne version en mémoire.

## Nom et icône

L'appli s'appelle **FocusFlow**. L'icône (des blocs lumineux sur fond nuit) est dans le dossier `icons/` en plusieurs tailles : 512 et 192 pixels pour Android, 180 pour iPhone, une version « adaptative » pour Android, 96 pour le logo du menu et 48 pour l'onglet. Tes données existantes sont conservées : la clé de stockage interne n'a pas changé.
