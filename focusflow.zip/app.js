"use strict";

/* =====================================================
   app.js : démarrage de l'appli
   (les autres fichiers sont dans le dossier js/)
   ===================================================== */

// Thème (clair, sombre ou automatique) et animations
App.appliquerTheme();
App.appliquerAnimations();
App.appliquerApparence();

// Affiche la dernière page ouverte
App.ouvrirPage(App.etat.courante, false);
App.Vues.afficherBoutons();
App.Histoire.majBoutons();


/* ---------- Clavier du téléphone ----------
   Sur certains téléphones, le clavier cache la barre du bas.
   On la remonte de la hauteur du clavier. */
if (window.visualViewport) {
  const ajuster = () => {
    const decalage = window.innerHeight - window.visualViewport.height - window.visualViewport.offsetTop;
    document.documentElement.style.setProperty("--clavier", Math.max(0, Math.round(decalage)) + "px");
  };
  window.visualViewport.addEventListener("resize", ajuster);
  window.visualViewport.addEventListener("scroll", ajuster);
}


/* ---------- Installation sur l'écran d'accueil ----------
   Le navigateur nous prévient quand l'appli est installable ;
   le bouton se trouve dans Paramètres. */
App.Installation = (function () {
  let invitation = null;

  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    invitation = e;
  });
  window.addEventListener("appinstalled", () => {
    invitation = null;
    App.Toast.afficher("Appli installée 🎉");
  });

  return {
    disponible: () => !!invitation,
    dejaInstallee: () => !!(window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true,
    lancer: async () => {
      if (!invitation) return;
      invitation.prompt();
      await invitation.userChoice;
      invitation = null;
    },
  };
})();


/* ---------- Raccourcis et mode hors ligne ---------- */
(function () {
  // Ctrl+S / Cmd+S : synchronisation manuelle ou confirmation de sauvegarde locale
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === "s") {
      e.preventDefault();
      App.sauver();
      if (App.Sync && App.Sync.connecte()) App.Sync.synchroniser(true);
      else App.Toast.afficher("Sauvegardé localement ✓");
    }
  });

  // Enregistre sw.js uniquement s'il est réellement présent à côté du fichier
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", async () => {
      try {
        const rep = await fetch("sw.js", { method: "HEAD", cache: "no-store" });
        const type = (rep.headers.get("content-type") || "").toLowerCase();
        if (rep.ok && (type.includes("javascript") || type.includes("ecmascript"))) {
          await navigator.serviceWorker.register("sw.js");
        }
      } catch (erreur) {
        // Fichier unique autonome : aucun sw.js externe requis
      }
    });
  }
})();
